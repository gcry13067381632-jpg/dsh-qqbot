/**
 * qqbot-settings — host 半边: ①im-qqbot settings 命名空间经同源路由暴露给设置面板;
 * ②表情包图库管理 API(列表/缩略图/批量/导入), 与 dsh-qqbot 共享同进程 store 单例。
 * 仅 web profile 装配; 同源 fence 抄 modsearch。
 */
import { readFileSync, writeFileSync, appendFileSync, rmSync, mkdirSync, existsSync, readdirSync, statSync, cpSync, renameSync, openSync, readSync, closeSync, createWriteStream } from 'node:fs';
import { extname, join, resolve, dirname, normalize, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn } from 'node:child_process';
import { homedir } from 'node:os';
import { createHash } from 'node:crypto';
import { getStickerStore } from '@zaofan/dsh-qqbot/sticker-store';
import { getScheduleStore } from '@zaofan/dsh-qqbot/schedule-store';

export const name = 'qqbot-settings';
/**
 * 服务依赖(2026-09-10 排查修复): 只声明必备的 settings/webServer。
 * ⚠️ 曾声明 ['settings','webServer','agentPresets'] —— cordis 对 inject 声明的服务是
 *    「等齐才调用 apply」语义: 若宿主未提供 agentPresets, 桥的 apply 永远不被调用,
 *    所有 /api/qqbot-settings/* 路由都不会注册(实测表现为全部 404, 面板显示「无账号」)。
 *    agentPresets 现改为可选: apply 内使用时判空降级(缺失时该路由返回 500 提示)。
 */
export const inject = ['settings', 'webServer'];

const NS = 'im-qqbot';
/**
 * 定位宿主 profile 根(账号实例 patch 所在)。优先代码位置(实体安装: 包根上溯 3 级 = profile 根,
 * 上溯层级在单包合并时已按包根位置修正); 若该位置没有 cordis.patch.yml(link/symlink 安装时
 * 本文件被从源码目录加载), 则扫描 ~/.dsh/profiles/* 找装着 @zaofan/dsh-qqbot 的 profile。
 */
function resolveProfileRoot() {
  const byLocation = resolve(dirname(fileURLToPath(import.meta.url)), '..', '..', '..');
  try {
    if (existsSync(join(byLocation, 'cordis.patch.yml'))) return byLocation;
  } catch { /* 继续扫描 */ }
  try {
    const base = join(homedir(), '.dsh', 'profiles');
    for (const name of readdirSync(base)) {
      const prof = resolve(base, name);
      try {
        if (!statSync(prof).isDirectory()) continue;
      } catch { continue; }
      try {
        if (existsSync(join(prof, 'node_modules', '@zaofan', 'dsh-qqbot'))) return prof;
      } catch { /* 走下一判据 */ }
      try {
        const pkg = JSON.parse(readFileSync(join(prof, 'package.json'), 'utf8'));
        const blob = JSON.stringify(pkg.dsh?.profile?.bundles ?? []) + JSON.stringify(pkg.dependencies ?? {});
        if (blob.includes('@zaofan/dsh-qqbot')) return prof;
      } catch { /* 无 package.json, 跳过 */ }
    }
  } catch { /* profiles 目录不存在 */ }
  return byLocation;
}
const PROFILE_ROOT = resolveProfileRoot();
/** cordis.patch.yml = 宿主插件装配文件(账号实例声明处; 改它需重启 dsh 生效) */
const PATCH_FILE = join(PROFILE_ROOT, 'cordis.patch.yml');
/** dsh 家目录(与宿主保持一致: 优先环境变量 DSH_HOME, 否则回落 ~/.dsh) */
const DSH_HOME_DIR = ((process.env.DSH_HOME ?? '').trim()) || join(homedir(), '.dsh');
/** agent 预设根目录 —— ⚠️ 仅 ≤0.1.6 的**旧机制**(每预设一个子目录, 目录名=预设 id)。
 *  dsh 0.1.7 起预设改为「profile 配置里的声明行」(@deepseek-ai/dsh-agent-preset),
 *  既没有目录、也没有写接口, 所以这里只作为旧版回落路径保留。 */
const PRESET_ROOT = join(DSH_HOME_DIR, '.agent-presets');
/** 复制预设时排除的备份/压缩类文件(不把主人的隐私压缩包带进新预设) */
const COPY_SKIP = /\.(rar|zip|7z|bak|tmp|log|diag)$/i;
/** 预设 id 校验: 文件夹命名规范(字母数字开头, 允许 - _) */
const ID_RE = /^[A-Za-z0-9][A-Za-z0-9_-]*$/;

/** 同源回环 fence: 仅本机 loopback + 同源/无 Origin 放行 */
function isTrusted(req) {
  const h = req.headers?.host;
  if (typeof h !== 'string') return false;
  let hostname;
  try { hostname = new URL(`http://${h}`).hostname; } catch { return false; }
  const loopback = /^(\[::1\]|localhost|127(\.\d{1,3}){3})$/.test(hostname);
  if (!loopback) return false;
  if (req.headers?.['sec-fetch-site'] === 'cross-site') return false;
  const o = req.headers?.origin;
  if (o === undefined) return true;
  try { return new URL(o).host === req.headers.host; } catch { return false; }
}

function writeJson(res, status, body) {
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(body));
}

async function readJsonBody(req) {
  const chunks = [];
  let size = 0;
  for await (const c of req) {
    size += c.length;
    if (size > 8 * 1024 * 1024) return undefined;
    chunks.push(c);
  }
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { return undefined; }
}

/** 读命名空间当前解析值 + revision(redact 防密钥外泄) */
/**
 * 兜底：从 profile 的 cordis.patch.yml 里读某个 entry 的 config（2026-09-23 适配 dsh 0.1.7）。
 *
 * 背景：0.1.7 把设置机制换成了「从 profile 里插件条目的 config schema 推导」，
 * 注册入口 `installSection` 已移除 → 插件静默降级后 `describe()` 里不再有本实例的 ns，
 * 于是 /read 返回 {value:undefined,revision:undefined}（JSON 序列化后正好是 {}），
 * 前端就显示"读取失败: {}"。
 *
 * 这里只做「块级 + 简单标量」提取（不整文件 YAML 解析，因为含 !!js 标签）：
 * 找 `- id: <entryId>` 块的 `config:` 子树，逐行取标量，跳过 !!js 与嵌套子块；
 * secret 类字段按宿主 describe(redactSecrets) 的口径打码。
 */
function readEntryConfigFromPatch(entryId) {
  try {
    if (!existsSync(PATCH_FILE)) return null;
    const lines = readFileSync(PATCH_FILE, 'utf8').split(/\r\n|\n/);
    const esc = String(entryId).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const headRe = new RegExp('^\\s*-\\s*id:\\s*[\'"]?' + esc + '[\'"]?\\s*$');
    const start = lines.findIndex((l) => headRe.test(l));
    if (start < 0) return null;
    const headIndent = (lines[start].match(/^\s*/) || [''])[0].length;
    let end = lines.length;
    for (let i = start + 1; i < lines.length; i++) {
      const ind = (lines[i].match(/^\s*/) || [''])[0].length;
      if (/- /.test(lines[i]) && ind <= headIndent) { end = i; break; }
    }
    const block = lines.slice(start + 1, end);
    const ci = block.findIndex((l) => /^\s*config:\s*$/.test(l));
    if (ci < 0) return null;
    const cfgIndent = (block[ci].match(/^\s*/) || [''])[0].length;
    const out = {};
    const parseScalar = (v) => {
      const s = String(v).trim().replace(/^['"]|['"]$/g, '');
      if (s === 'true') return true;
      if (s === 'false') return false;
      if (s === 'null' || s === '~') return null;
      if (/^-?\d+$/.test(s)) return Number(s);
      return s;
    };
    // 递归解析（2026-09-24：之前只取一层，groupAdmin 这类嵌套对象的子字段全被跳过 →
    // 前端读回来是 undefined，勾选后"保存了却跳回去"）
    const parseBlock = (from, to, indent) => {
      const obj = {};
      for (let i = from; i < to; i++) {
        const raw = block[i];
        if (!raw.trim() || /^\s*#/.test(raw)) continue;
        if (((raw.match(/^\s*/) || [''])[0]).length !== indent) continue;
        const m = /^\s*([A-Za-z0-9_-]+):\s*(.*)$/.exec(raw);
        if (!m) continue;
        const key = m[1];
        const rest = m[2].trim();
        let subEnd = i + 1;
        while (subEnd < to) {
          const l = block[subEnd];
          if (l.trim() && ((l.match(/^\s*/) || [''])[0]).length <= indent) break;
          subEnd++;
        }
        if (rest === '') {
          const inner = block.slice(i + 1, subEnd);
          if (inner.some((l) => /^\s*-\s/.test(l))) {
            const arr = [];
            for (const l of inner) {
              const am = /^\s*-\s*(.*)$/.exec(l);
              if (am && am[1].trim()) arr.push(parseScalar(am[1]));
            }
            obj[key] = arr;
          } else {
            obj[key] = parseBlock(i + 1, subEnd, indent + 2);
          }
        } else if (rest === '[]') {
          obj[key] = [];
        } else if (rest.startsWith('!!js')) {
          obj[key] = rest;                                  // 表达式：原样返回（前端只读展示）
        } else {
          obj[key] = parseScalar(rest);
        }
        i = subEnd - 1;
      }
      return obj;
    };
    const parsed = parseBlock(ci + 1, block.length, cfgIndent + 2);
    const redact = (o) => {
      if (!o || typeof o !== 'object') return o;
      for (const k of Object.keys(o)) {
        if (/secret|token|password|_key$/i.test(k)) o[k] = '__REDACTED__';
        else if (o[k] && typeof o[k] === 'object') redact(o[k]);
      }
      return o;
    };
    redact(parsed);
    for (const [k, v] of Object.entries(parsed)) out[k] = v;
    return Object.keys(out).length ? out : null;
  } catch { return null; }
}
/** 读一个实例的配置视图；宿主 describe 拿不到时回落到 profile patch。 */
function viewOf(settings, ns) {
  const target = ns || NS;
  let list = [];
  try { list = settings.describe({ redactSecrets: true }) || []; } catch { list = []; }
  const d = list.find((x) => x.ns === target);
  if (d) return { value: d.value, revision: d.revision };
  const fb = readEntryConfigFromPatch(target);
  // revision 用 -1 标记"兜底视图、没有乐观锁基线"（/update 见负数就跳过 expectedRevision）
  if (fb) return { value: fb, revision: -1 };
  return { value: undefined, revision: undefined };
}

/**
 * ── 插件自有设置存储（2026-09-24）──
 *
 * 为什么不再写 profile 的 `cordis.patch.yml`：
 *   ① 0.1.7 下写 patch 会被宿主当**热更新**提交 → 插件重新 apply → 本插件启动时若凭据无效会再写
 *      → 自反馈闭环（实测把 dsh 启动刷死、无限弹二维码）；
 *   ② 手拼 YAML 保不住字段类型（实测 appId 写成裸数字、owners 空数组写成空串 → 宿主 schema 校验失败）；
 *   ③ 不支持"新增键"（groupAdmin.pollJoinRequests 这类写不进去）。
 *
 * 改用插件自己的 JSON 存储：不触发任何热更新、JSON 天生有类型、随便加键，
 * 而且**用户不需要手改任何配置文件**（可视化的初衷）。
 * 位置：{DSH_HOME}/qqbot-settings/<instanceNs>.json
 */
const OWN_SETTINGS_DIR = join(DSH_HOME_DIR, 'qqbot-settings');
function ownSettingsPath(ns) {
  const safe = String(ns || NS).replace(/[^A-Za-z0-9_-]/g, '_');
  return join(OWN_SETTINGS_DIR, safe + '.json');
}
function readOwnSettings(ns) {
  try {
    const p = ownSettingsPath(ns);
    if (!existsSync(p)) return {};
    const o = JSON.parse(readFileSync(p, 'utf8'));
    return o && typeof o === 'object' ? o : {};
  } catch { return {}; }
}
function writeOwnSettings(ns, obj) {
  const p = ownSettingsPath(ns);
  try { mkdirSync(OWN_SETTINGS_DIR, { recursive: true }); } catch { /* ignore */ }
  try { if (existsSync(p)) writeFileSync(p + '.bak-' + Date.now(), readFileSync(p)); } catch { /* 备份失败不阻塞 */ }
  writeFileSync(p, JSON.stringify(obj, null, 2), 'utf8');
  return p;
}
/** 深合并一层（够用：本插件嵌套只到 groupAdmin / sticker.gates 这一层）。 */
function mergeDeepOne(cur, patch) {
  const out = Object.assign({}, cur);
  for (const [k, v] of Object.entries(patch || {})) {
    if (v === undefined) continue;
    if (v === '__REDACTED__') continue;   // 脱敏占位符绝不写回
    if (v && typeof v === 'object' && !Array.isArray(v) && out[k] && typeof out[k] === 'object' && !Array.isArray(out[k])) {
      out[k] = Object.assign({}, out[k], v);
    } else {
      out[k] = v;
    }
  }
  return out;
}

/** 按 (条目, 缩进层级, 键名) 去掉重复键，保留**最后一次**出现（YAML 语义）。
 *  2026-09-24 兜底：写 patch 前必跑。重复键会让宿主的 YAML 严格解析直接抛错
 *  （YAMLException: duplicated mapping key）→ dsh 完全启动不了。 */
function dedupeYamlKeys(text) {
  const lines = String(text).split(/\r?\n/);
  const scope = ['']; const seen = new Map(); const keep = new Array(lines.length).fill(true);
  let cur = '';
  for (let i = 0; i < lines.length; i++) {
    const l = lines[i];
    if (!l.trim() || l.trimStart().startsWith('#')) continue;
    const mId = /^(\s*)-\s*id:\s*(\S+)\s*$/.exec(l);
    if (mId) { cur = mId[2]; seen.clear(); continue; }
    const mK = /^(\s*)([A-Za-z0-9_-]+):/.exec(l);
    if (!mK) continue;
    const sig = cur + '|' + mK[1].length + '|' + mK[2];
    if (seen.has(sig)) keep[seen.get(sig)] = false;
    seen.set(sig, i);
  }
  return lines.filter((_, i) => keep[i]).join('\n');
}

/** 请求里的目录参数(dataDir 显式传; 空=primary 主账号) */
function dirOf(u, key) {
  return (u?.searchParams?.get(key) || '').trim() || undefined;
}

const MIME = { jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', gif: 'image/gif', webp: 'image/webp', bmp: 'image/bmp' };

/** 注册一条路由, 统一 fence + method 检查。
 * ⚠️ 2026-09-10 关键修复: 同 path 只向 dsh webServer register 一次, 多 method 内部按
 *    req.method 分发。原实现对每个 route() 调用各 register 一次 —— dsh webServer 对同一
 *    path 重复 register 会抛错, 导致 apply 从该处中断, 其后所有路由全部未注册
 *    (实测: /group/botplay-events 的 GET+POST 同路径 → 其后 30 个路由缺失,
 *     dock 聊天视图/群发/审批全挂)。route() 本就接受 method 数组, 这里补按 path 去重。 */
const routeByPath = new Map();
function route(ctx, method, path, handler) {
  const methods = (Array.isArray(method) ? method : [method]).map((m) => String(m).toUpperCase());
  let reg = routeByPath.get(path);
  if (!reg) {
    reg = { handlers: new Map() };
    routeByPath.set(path, reg);
    ctx.effect(() => ctx.webServer.register({
      kind: 'exact',
      path,
      handler: async (req, res) => {
        if (!isTrusted(req)) return writeJson(res, 403, { error: 'refused: same-origin loopback only' });
        const h = reg.handlers.get(String(req.method || '').toUpperCase());
        if (!h) return writeJson(res, 405, { error: 'method not allowed' });
        try { await h(req, res); } catch (e) { writeJson(res, 500, { error: String(e?.message ?? e) }); }
      },
    }), `qqbot-settings: ${path}`);
  }
  for (const m of methods) reg.handlers.set(m, handler);
}

export function apply(ctx) {
  // ── 桥装载诊断(2026-09-10 排查路由全 404): 落 ~/.dsh/qqbot-bridge-diag.log ──
  // 用途: 宿主重启后可确认 apply 是否真的被 cordis 调用(以及当时 ctx 上有哪些服务)。
  try {
    // ⚠️ 未在 inject 声明的服务裸访问会抛 "without inject"（0.1.7 实测）→ 逐个 try 探测
    const probe = (n) => { try { return (ctx && ctx[n]) ? 'Y' : 'N'; } catch { return 'NO-INJECT'; } };
    const services = ['settings', 'webServer', 'agentPresets'].map((s) => s + '=' + probe(s)).join(' ');
    appendFileSync(
      join(homedir(), '.dsh', 'qqbot-bridge-diag.log'),
      `[${new Date().toISOString()}] bridge apply 被调用 inject=${JSON.stringify(inject)} ${services}\n`,
    );
  } catch { /* 诊断失败不影响装载 */ }
  // ── 临时诊断(排查"设置读取失败"): settings 服务可用性 + 已注册命名空间 ──
  route(ctx, 'GET', '/api/qqbot-settings/_debug', async (_req, res) => {
    try {
      const hasSettings = !!ctx.settings;
      let nss = [];
      let describeErr = null;
      try {
        const all = ctx.settings.describe({});
        nss = (Array.isArray(all) ? all : []).map((x) => x.ns);
      } catch (e) { describeErr = String(e?.message ?? e); }
      // 触发式反归档诊断(2026-09-11): 有多少次真的把归档的 QQ 会话拉回可见(见 dist/session/workspace-attach.js)
      let workspaceAttach = null;
      try {
        const wa = await import('./dist/session/workspace-attach.js');
        workspaceAttach = typeof wa.workspaceAttachState === 'function' ? wa.workspaceAttachState() : null;
      } catch { /* 模块未部署时忽略 */ }
      writeJson(res, 200, { hasSettings, nss, describeErr, workspaceAttach });
    } catch (e) { writeJson(res, 500, { error: String(e?.message ?? e) }); }
  });

  // ── 设置面板读写桥(多账号: ?ns= 选实例命名空间; 缺省 im-qqbot 主账号) ──
  route(ctx, 'GET', '/api/qqbot-settings/read', async (req, res) => {
    const u = new URL(req.url ?? '/', 'http://x');
    const ns = u.searchParams.get('ns') || NS;
    const base = viewOf(ctx.settings, ns) || {};
    const own = readOwnSettings(ns);
    // 自有存储优先：它就是用户在设置页保存的那份
    const value = Object.assign({}, base.value || {}, own);
    writeJson(res, 200, { value, revision: base.revision, source: Object.keys(own).length ? 'own' : 'patch' });
  });
  route(ctx, 'POST', '/api/qqbot-settings/update', async (req, res) => {
    const body = await readJsonBody(req);
    if (!body || typeof body !== 'object') return writeJson(res, 400, { error: 'body must be JSON object' });
    const ns = typeof body.ns === 'string' && body.ns ? body.ns : NS;
    // ⚠️ 2026-09-24 起：保存一律写**插件自有存储**（{DSH_HOME}/qqbot-settings/<ns>.json），
    //    绝不写 profile 的 cordis.patch.yml —— 写 patch 会被宿主当热更新提交，本插件启动时
    //    若凭据无效会再写配置，形成自反馈闭环（实测把 dsh 启动刷死、无限弹二维码）。
    //    自有存储还让「用户不必手改任何配置文件」（可视化的初衷）。
    try {
      const cur = readOwnSettings(ns);
      const merged = mergeDeepOne(cur, body.patch ?? {});
      const file = writeOwnSettings(ns, merged);
      // 通知插件实例重新读取（桥与插件同进程；不写宿主配置 → 不触发任何热更新）
      try { ctx.emit('qqbot/settings-changed', ns); } catch { /* 无监听者也无妨 */ }
      const base = viewOf(ctx.settings, ns) || {};
      writeJson(res, 200, {
        value: Object.assign({}, base.value || {}, merged),
        revision: base.revision,
        mode: 'own',
        file,
        note: '已保存（插件自有存储，热生效）',
      });
    } catch (e) {
      writeJson(res, 500, { error: '保存失败：' + String(e?.message ?? e) });
    }
  });

  // ── 定时唤醒辅助: 机器人见过的聊天台账(群/私聊带昵称) ──
  // 台账文件 {store.dataDir}/known-chats.jsonl 由 dsh-qqbot 中间件 append(见 dsh-qqbot src/features/chat-ledger.ts)。
  // 用途: Web 设置④区下拉点选目标(免抄 openid)——群无群名, 用最近发言者昵称帮主人辨认。
  // 多账号: ?dataDir= 指定账号图库目录(台账与之同目录); 缺省 primary。
  // ── 推断本插件的 dataRoot（与插件 src/gateway/data-root.ts 的算法保持一致）──
  //   为什么要这么做：桥和插件在运行时可能是**两份模块实例**（各自的模块级变量不共享）。
  //   插件在 bootstrap 里 initContextlessStore(dataRoot) 用的是正确路径；桥若没 init，
  //   contextless-store 的 ensurePath() 只能兜底到 {DSH_HOME}，于是"面板保存"写一个文件、
  //   "插件实际读取"读另一个文件 → 表现为保存无效 / 开关显示不一致（2026-09-27 实测）。
  function resolveContextlessDataRoot() {
    try {
      const parsed = parsePatch();
      const bots = (parsed && Array.isArray(parsed.bots)) ? parsed.bots : [];
      // 优先取"未禁用"的实例，其次任意一个有 cwd 的
      const pick = bots.filter((b) => b && !b.disabled && b.cfg && (b.cfg.cwd || b.cfg.dataRoot));
      const list = pick.length ? pick : bots.filter((b) => b && b.cfg && (b.cfg.cwd || b.cfg.dataRoot));
      for (const b of list) {
        const cfg = b.cfg || {};
        if (cfg.dataRoot) return String(cfg.dataRoot);
        if (cfg.cwd) return join(String(cfg.cwd), 'dshqqbot');   // 与 DEFAULT_DATA_SUBDIR 一致
      }
    } catch { /* 推不出来就交给 ensurePath 兜底 */ }
    return '';
  }
  /** 确保 contextless-store 绑定到正确的数据根（幂等；路径变了会重新绑定） */
  async function loadContextlessStore() {
    const mod = await import('./dist/features/contextless-store.js');   // ← 函数体内用真正的动态 import（不能调自己）
    try {
      const dr = resolveContextlessDataRoot();
      if (dr) mod.initContextlessStore(dr);
    } catch { /* ignore */ }
    return mod;
  }

  // ── 无上下文模式（2026-09-27 主人定）──
  //   会话级开关：dock 面板里对**某个会话**开启；开启后该会话每轮只带
  //   「@ 之前 N 条群消息 + 系统规则」，历史对话全部丢弃（大幅省 token）。
  //   开关存 {dataRoot}/.qqbot/contextless.json（由插件在 bootstrap 时初始化）。
  route(ctx, 'GET', '/api/qqbot-settings/contextless', async (req, res) => {
    try {
      const u = new URL(req.url ?? '/', 'http://x');
      const key = (u.searchParams.get('sessionKey') || '').trim();
      const mod = await loadContextlessStore();   // 先 init 到同一个 dataRoot，避免两份模块实例各写一个文件
      if (key) return writeJson(res, 200, mod.getContextless(key));
      return writeJson(res, 200, { list: mod.listContextless() });
    } catch (e) {
      return writeJson(res, 500, { error: String((e && e.message) || e) });
    }
  });
  route(ctx, 'POST', '/api/qqbot-settings/contextless', async (req, res) => {
    try {
      const body = await readJsonBody(req);
      if (!body || typeof body !== 'object') return writeJson(res, 400, { error: 'body must be JSON object' });
      const key = String(body.sessionKey || '').trim();
      if (!key) return writeJson(res, 400, { error: 'sessionKey required' });
      const mod = await loadContextlessStore();   // 先 init 到同一个 dataRoot，避免两份模块实例各写一个文件
      if (body.remove === true) { mod.clearContextless(key); return writeJson(res, 200, { ok: true, removed: true }); }
      const next = mod.setContextless(key, { enabled: body.enabled, window: body.window });
      return writeJson(res, 200, { ok: true, value: next });
    } catch (e) {
      return writeJson(res, 500, { error: String((e && e.message) || e) });
    }
  });

  route(ctx, 'GET', '/api/qqbot-settings/known-chats', async (req, res) => {
    try {
      const u = new URL(req.url ?? '/', 'http://x');
      const store = dirOf(u, 'dataDir') ? getStickerStore(dirOf(u, 'dataDir')) : getStickerStore();
      const dataDir = store.dataDir;
      const lines = [];
      try {
        const raw = readFileSync(join(dataDir, 'known-chats.jsonl'), 'utf8');
        for (const l of raw.split('\n')) {
          const t = l.trim();
          if (!t) continue;
          try {
            const o = JSON.parse(t);
            if (o && typeof o.id === 'string' && (o.scope === 'group' || o.scope === 'c2c')) {
              lines.push({ ts: typeof o.ts === 'number' ? o.ts : 0, scope: o.scope, id: o.id, name: typeof o.name === 'string' ? o.name : undefined });
            }
          } catch { /* 坏行跳过 */ }
        }
      } catch { /* 台账文件尚不存在 */ }
      const map = new Map();
      for (const l of lines) {
        const key = l.scope + ':' + l.id;
        const cur = map.get(key);
        if (!cur) map.set(key, { scope: l.scope, id: l.id, name: l.name, lastSeen: l.ts, count: 1 });
        else {
          cur.count += 1;
          if (l.ts > cur.lastSeen) { cur.lastSeen = l.ts; if (l.name) cur.name = l.name; }
        }
      }
      const chats = [...map.values()].sort((a, b) => b.lastSeen - a.lastSeen).slice(0, 80);
      writeJson(res, 200, { chats });
    } catch (e) {
      writeJson(res, 500, { error: String(e?.message ?? e) });
    }
  });

  // ── 定时任务管理(会话内 AI 用 schedule_timer 建的: once/daily, .qqbot/timers.json) ──
  // 多账号: ?schedDir= / body.schedDir 指定账号定时目录(join(cwd,'.qqbot')); 缺省 primary。
  // 本页只管 查看/开关/删除(新建在 QQ 会话里让 AI 建)。
  function timerJobs(schedDir) {
    const store = schedDir ? getScheduleStore(schedDir) : getScheduleStore();
    const now = Date.now();
    return store.list().map((j) => ({
      id: j.id, kind: j.kind, scope: j.scope, peerId: j.peerId,
      atTime: j.atTime || null, dueAt: j.dueAt || null,
      prompt: j.prompt, createdAt: j.createdAt, enabled: j.enabled,
      lastRunDate: j.lastRunDate || null,
      nextFireAt: store.nextFireAt(j, now),
    }));
  }
  route(ctx, ['GET', 'POST'], '/api/qqbot-settings/timers', async (req, res) => {
    // POST = 旧版客户端统一 action: body {id, schedDir?, enabled?} —— enabled 存在=开关, 缺省=删除
    if (req.method === 'POST') {
      const body = await readJsonBody(req);
      if (!body || typeof body.id !== 'string') return writeJson(res, 400, { error: 'id required' });
      const store = typeof body.schedDir === 'string' && body.schedDir ? getScheduleStore(body.schedDir) : getScheduleStore();
      const removing = body.enabled === undefined;
      const ok = removing ? store.remove(body.id) : store.setEnabled(body.id, body.enabled === true);
      try { store.flush(); } catch { /* ignore */ }
      if (!ok) return writeJson(res, 404, { error: '任务不存在' });
      return writeJson(res, 200, { ok: true });
    }
    const u = new URL(req.url ?? '/', 'http://x');
    writeJson(res, 200, { jobs: timerJobs(dirOf(u, 'schedDir')) });
  });
  // 开关: {id, enabled, schedDir?}
  route(ctx, 'POST', '/api/qqbot-settings/timers/toggle', async (req, res) => {
    const body = await readJsonBody(req);
    if (!body || typeof body.id !== 'string') return writeJson(res, 400, { error: 'id required' });
    const store = typeof body.schedDir === 'string' && body.schedDir ? getScheduleStore(body.schedDir) : getScheduleStore();
    const ok = store.setEnabled(body.id, body.enabled === true);
    try { store.flush(); } catch { /* ignore */ }
    if (!ok) return writeJson(res, 404, { error: '任务不存在' });
    writeJson(res, 200, { ok: true });
  });
  // 删除: {id, schedDir?}
  route(ctx, 'POST', '/api/qqbot-settings/timers/delete', async (req, res) => {
    const body = await readJsonBody(req);
    if (!body || typeof body.id !== 'string') return writeJson(res, 400, { error: 'id required' });
    const store = typeof body.schedDir === 'string' && body.schedDir ? getScheduleStore(body.schedDir) : getScheduleStore();
    const ok = store.remove(body.id);
    try { store.flush(); } catch { /* ignore */ }
    if (!ok) return writeJson(res, 404, { error: '任务不存在' });
    writeJson(res, 200, { ok: true });
  });

  // ── 账号与预设管理(第4 tab) ──
  // 账号实例声明在 cordis.patch.yml(改它需重启 dsh 生效); appSecret 明文存本机 profile, 勿提交 git。

  /** YAML 单引号标量(含 ' 转义为 '') */
  function yq(v) { return `'${String(v ?? '').replace(/'/g, "''")}'` }
  /** appSecret 裸写规则: 纯安全字符直接裸, 否则单引号 */
  function ysec(v) { const s = String(v ?? ''); return /^[A-Za-z0-9+/=_\-]+$/.test(s) ? s : yq(s) }
  /** 顶层块行判断(0 缩进以 "- " 开头) */
  function isTopLine(l) { return /^-\s/.test(l) }
  /** 块头是 im-qqbot 实例? */
  function isBotHead(l) { const m = /^-\s*id:\s*(\S+)\s*$/.exec(l.trim()); return m ? /^im-qqbot(-|$)/.test(m[1]) : false }
  function botIdOf(headLine) { const m = /^-\s*id:\s*(\S+)\s*$/.exec(headLine.trim()); return m ? m[1] : '' }

  /** 解析 patch: 返回 {raw, bots:[{id,start,end,ins,cfg:{appId,appSecret,preset,cwd},disabled}], hasFile}
   *  patch 语义(宿主 dsh-app-boot applyEntryPatches): 顶层 `- id: X` 只能覆盖已存在 id(bundle insert 建的);
   *  新增实例必须 `- insert:` 包装(其下 4 空格 `- id: Y`)。本文件里两种形态都识别。 */
  function parsePatchFrom(rawText) {
    const hasFile = existsSync(PATCH_FILE);
    const raw = rawText !== undefined && rawText !== null ? String(rawText) : (hasFile ? readFileSync(PATCH_FILE, 'utf8') : '');
    // 行尾容错: 兼容 CRLF(2026-09-08 曾因 patch 被写成 CRLF 导致整段解析失败)
    const lines = raw.split(/\r?\n/);
    const bots = [];
    let i = 0;
    while (i < lines.length) {
      const t = lines[i];
      if (isTopLine(t) && isBotHead(t)) {
        // 顶层覆盖形态: head 缩进 0
        const id = botIdOf(t);
        const start = i;
        let j = i + 1;
        const cfg = {};
        let disabled = false;
        let inCfg = false;
        while (j < lines.length && (lines[j].trim() === '' || !isTopLine(lines[j]))) {
          const c = lines[j];
          if (/^\s{2}config:\s*$/.test(c)) inCfg = true;
          else if (/^\s{2}disabled:\s*true\s*$/.test(c)) disabled = true;
          else if (inCfg && /^\s{4}(\S[^:]*):\s*(.*)$/.test(c)) {
            const km = /^\s{4}(\S[^:]*):\s*(.*)$/.exec(c);
            cfg[km[1]] = km[2].trim().replace(/^'|'$/g, '').replace(/''/g, "'");
          }
          j += 1;
        }
        bots.push({ id, start, end: j, ins: false, cfg, disabled, headLine: start });
        i = j;
      } else if (isTopLine(t) && /^\s*-\s*insert:\s*$/.test(t)) {
        // insert 形态: 找其下 4 空格 `- id: im-qqbot*`
        const insStart = i;
        let k = i + 1;
        let found = null;
        while (k < lines.length && (lines[k].trim() === '' || /^\s/.test(lines[k]) && !/^-\s/.test(lines[k]) || /^\s{2,}/.test(lines[k]))) {
          // 在 insert 列表内(行以空白开头或为列表项), 找 4 空格 "- id:"
          const c = lines[k];
          const m4 = /^\s{4}-\s*id:\s*(\S+)\s*$/.exec(c);
          if (m4 && /^im-qqbot(-|$)/.test(m4[1])) { found = { line: k, id: m4[1] }; break; }
          if (/^-\s/.test(c) && !/^\s/.test(c)) break; // 下一个顶层条目
          if (c.trim() !== '' && !/^\s/.test(c) && !/^-\s/.test(c)) break;
          k += 1;
        }
        if (found) {
          const id = found.id;
          let j = found.line + 1;
          const cfg = {};
          let disabled = false;
          let inCfg = false;
          while (j < lines.length && (lines[j].trim() === '' || /^\s{2,}/.test(lines[j]) && !isTopLine(lines[j]))) {
            const c = lines[j];
            if (/^\s{6}config:\s*$/.test(c)) inCfg = true;
            else if (/^\s{6}disabled:\s*true\s*$/.test(c)) disabled = true;
            else if (inCfg && /^\s{8}(\S[^:]*):\s*(.*)$/.test(c)) {
              const km = /^\s{8}(\S[^:]*):\s*(.*)$/.exec(c);
              cfg[km[1]] = km[2].trim().replace(/^'|'$/g, '').replace(/''/g, "'");
            }
            if (isTopLine(lines[j])) break;
            j += 1;
          }
          bots.push({ id, start: insStart, end: j, ins: true, cfg, disabled, headLine: found.line });
          i = j;
        } else {
          i += 1;
        }
      } else {
        i += 1;
      }
    }
    return { raw, hasFile, bots };
  }
  /** 从磁盘读取并解析(parsePatchFrom 的包装) */
  function parsePatch() { return parsePatchFrom(undefined); }

  /** 渲染一个实例块。主 im-qqbot(bundle 已 insert)→ 顶层覆盖; 新实例 → `- insert:` 包装(4/6/8 缩进) */
  function renderBotBlock(inst) {
    const id = String(inst.id || 'im-qqbot');
    const isMain = id === 'im-qqbot';
    const L0 = isMain ? 0 : 4; // 条目行缩进(主=0, insert 内=4)
    const pad0 = ' '.repeat(L0);
    const pad2 = ' '.repeat(L0 + 2);
    const pad4 = ' '.repeat(L0 + 4);
    const out = [];
    if (!isMain) out.push('- insert:');
    out.push(`${pad0}- id: ${id}`);
    if (!isMain) out.push(`${pad2}name: '@zaofan/dsh-qqbot'`);
    if (inst.disabled) out.push(`${pad2}disabled: true`);
    out.push(`${pad2}config:`);
    if (inst.appId) out.push(`${pad4}appId: ${yq(inst.appId)}`);
    if (inst.appSecret) out.push(`${pad4}appSecret: ${ysec(inst.appSecret)}`);
    if (!isMain) out.push(`${pad4}settingsNs: ${yq(id)}`); // 多账号实例身份: settings 命名空间按实例唯一
    if (inst.preset) out.push(`${pad4}preset: ${yq(inst.preset)}`);
    out.push(`${pad4}requireMention: false`);
    out.push(`${pad4}historyLimit: 20`);
    if (inst.cwd) out.push(`${pad4}cwd: ${yq(inst.cwd)}`);
    if (inst.dataRoot) out.push(`${pad4}dataRoot: ${yq(inst.dataRoot)}`); // 数据根(可选; 保存时保留, 见 saveInstances)
    return out.join('\n');
  }

  /** 在已有条目块内只更新指定键，保留原结构(缩进/位置/未知字段如 groupAdmin、dataRoot、name)。
   *  ⚠️ 2026-09-10 新增: 原实现用 renderBotBlock 整块重建 —— 会把 insert: 下的 im-qqbot-2 提成顶层
   *  `- id: im-qqbot`(新版无此 entry, 直接让整棵插件树加载失败), 并丢掉 name/settingsNs/historyLimit/
   *  groupAdmin/dataRoot 等未在渲染里列出的字段。改为原地增量更新后结构不再被破坏。
   *  ⚠️ 2026-09-10 二次修复: 除更新已存在的键外, 还要**补写缺失的键**(如原本没有 cwd 的实例),
   *  否则前端填了 cwd 也保存不进去(实测 im-qqbot-3 只更新 3/4 个键)。disabled 走块头层(children of id)。
   *  @param {string[]} lines 文件全部行(会被原地修改)
   *  @param {number} start 块首行索引(含, 即 `- id:` 或 `- insert:` 行)
   *  @param {number} end 块结束行索引(不含)
   *  @param {Record<string,string>} kv 要写入的键值(值为字符串); 已存在则改, 缺失则按规矩新增
   *  @returns {number} 实际写入的键数 */
  function updateKeysInBlock(lines, start, end, kv) {
    // 块头行: insert 包装时块首是 `- insert:`, 真正的 `- id:` 在下一行
    let headIdx = start;
    for (let i = start; i < Math.min(start + 3, end); i += 1) {
      if (/^\s*-\s*id:/.test(lines[i])) { headIdx = i; break; }
    }
    const headIndent = ((lines[headIdx] ?? '').match(/^\s*/) ?? [''])[0].length;
    const childIndent = headIndent + 2;      // name: / disabled: / config: 的缩进

    const pending = new Map(Object.entries(kv));
    let touched = 0;
    // ① 已存在的键: 原地改写(保留原缩进)
    for (let i = headIdx + 1; i < end && pending.size > 0; i += 1) {
      const m = /^(\s*)([A-Za-z_][A-Za-z0-9_]*):\s*(.*)$/.exec(lines[i]);
      if (!m) continue;
      const key = m[2];
      if (!pending.has(key)) continue;
      lines[i] = `${m[1]}${key}: ${pending.get(key)}`;
      pending.delete(key);
      touched += 1;
    }
    if (pending.size === 0) return touched;

    // ② 缺失的键: 找本条目自己的 `config:` 行(缩进 = childIndent, 避免命中嵌套的 groupAdmin 等)
    let cfgLine = -1;
    for (let i = headIdx + 1; i < end; i += 1) {
      if (new RegExp(`^\\s{${childIndent}}config:\\s*$`).test(lines[i])) { cfgLine = i; break; }
    }
    const keyIndent = childIndent + 2;       // config 下子键的缩进
    const addLines = [];
    for (const [key, val] of pending) {
      // disabled 属于条目层(childIndent), 也放这里 —— YAML 不要求键顺序
      addLines.push(`${' '.repeat(key === 'disabled' ? childIndent : keyIndent)}${key}: ${val}`);
    }
    if (cfgLine >= 0) {
      // 找 config: 之下最后一个同级键(含其子块), 插在后面。
      // 注意: 同级键的缩进 == keyIndent(不是 >), 用 >= 才能走到最后一个键;
      //       带子块的键(如 groupAdmin:) 其子行缩进 > keyIndent 也要一并跨过。
      let scan = cfgLine + 1;
      let lastLine = cfgLine;
      while (scan < end) {
        const blank = lines[scan].trim() === '';
        const ind = ((lines[scan].match(/^\s*/) ?? [''])[0]).length;
        if (!blank && ind >= keyIndent) { lastLine = scan; scan += 1; continue; }
        break;
      }
      lines.splice(lastLine + 1, 0, ...addLines);
    } else {
      // 没有 config: —— 在块头后补一个 config: 再放键
      let insertAt = end;
      for (let i = headIdx + 1; i < end; i += 1) {
        const ind = ((lines[i].match(/^\s*/) ?? [''])[0]).length;
        if (lines[i].trim() !== '' && ind <= headIndent && /- /.test(lines[i])) { insertAt = i; break; }
      }
      lines.splice(insertAt, 0, `${' '.repeat(childIndent)}config:`, ...addLines);
    }
    return touched + addLines.length;
  }


  /** 保存实例清单(全量同步; 行级重建, 其它插件行/注释原样保留)
   *  借鉴 dsh-qqbot-panel(2026-09-06): appSecret 空值/掩码(********) = 保留原值,
   *  只有提供全新非掩码值才覆盖 —— 前端只回显掩码, 不会因漏传/未改而误清 secret。
   *  ⚠️ 2026-09-09: dataRoot 同理 —— 前端不编辑它, 保存时必须保留原值,
   *     否则 accounts/save 会把 patch.yml 里的 dataRoot 覆盖掉(图库路径回退 cwd 的根因)。
   *  ⚠️ 2026-09-10: 已存在的条目改为"原地只更新字段", 不再整块重建(见 updateKeysInBlock 注释)。 */
  function saveInstances(instances) {
    const { raw, hasFile, bots } = parsePatch();
    if (!hasFile) return { ok: false, error: '找不到 cordis.patch.yml(仅 web profile 支持)' };
    const lines = raw.split('\n');
    const removals = [];
    const updates = [];
    const appends = [];
    const targetIds = new Set(instances.filter((x) => !x.remove).map((x) => String(x.id)));
    // 删除: 只删「没被提交的机器人条目」或显式 remove 的条目, 且范围严格限定在该条目自身:
    //   起点 = 它自己的 `- id:` 行(headLine, 不是包裹它的 `- insert:` 行),
    //   终点 = 下一个同级机器人条目的 headLine(或该 insert 块结束)。
    // ⚠️ 2026-09-10 事故一: 原用 { start: b.start }(insert 包装时为 `- insert:` 行) 且 end 取块末,
    //    导致同一 insert 下的其它插件条目(mcp-chrome)被连带删除。现改为按 headLine 精确切分。
    // ⚠️ 2026-09-10 事故二: 前端把"空骨架实例"(如用于禁用幽灵 im-qqbot 的 `- id: im-qqbot`
    //    + disabled: true, appId/appSecret 均为空)过滤掉不提交 → 会被当成"要删除"而误删,
    //    删掉后下次启动又触发扫码。故: 无凭据(appId/appSecret 皆空)的条目一律保留, 不参与自动删除。
    const removeIds = new Set(instances.filter((x) => x.remove).map((x) => String(x.id)));
    const doomed = bots.filter((b) => {
      if (removeIds.has(b.id)) return true;
      if (targetIds.has(b.id)) return false;
      const hasCred = !!(b.cfg?.appId || b.cfg?.appSecret);
      return hasCred;
    });
    for (const b of doomed) {
      const sameGroup = bots
        .filter((o) => o !== b && o.ins === b.ins && o.start === b.start && o.headLine > b.headLine)
        .sort((x, y) => x.headLine - y.headLine);
      const nextHead = sameGroup.length ? sameGroup[0].headLine : b.end;
      let tail = nextHead;
      while (tail > b.headLine + 1 && (lines[tail - 1] ?? '').trim() === '') tail -= 1;
      removals.push({ start: b.headLine, end: tail });
    }
    for (const inst of instances) {
      if (inst.remove) continue;
      const orig = bots.find((b) => b.id === String(inst.id));
      // 掩码/空 → 保留原 secret(仅当原值存在; 全新账号本就无原值则维持空)
      let secret = String(inst.appSecret ?? '');
      if (!secret || secret === SECRET_MASK) secret = orig?.cfg?.appSecret ? String(orig.cfg.appSecret) : '';
      // 前端不编辑 dataRoot → 保留原值(2026-09-09: 曾因保存覆盖丢失导致图库路径回退 cwd)
      let dataRoot = inst.dataRoot;
      if (dataRoot === undefined && orig?.cfg?.dataRoot) dataRoot = orig.cfg.dataRoot;

      if (orig) {
        const kv = {};
        // ✅ 2026-09-24：已有账号的 appId/appSecret/preset/cwd 只写**自有存储**，不再写 patch。
        //    原因：patch 里 - insert: 下挂多条目时，updateKeysInBlock 的块边界会跨到隔壁条目，
        //    实测把 im-qqbot-2 的凭据写进了 mcp-chrome、并给 im-qqbot-3 追加重复键。
        //    插件启动时自有存储会覆盖 patch 值，所以只写自有存储完全等效，且绝不会写歪。
        //    disabled 例外：它是宿主的 entry 属性、不在 config 里，必须继续写 patch。
        const ownKv = {};
        if (inst.appId !== undefined) ownKv.appId = String(inst.appId);
        if (secret) ownKv.appSecret = String(secret);
        if (inst.preset !== undefined && String(inst.preset) !== '') ownKv.preset = String(inst.preset);
        if (inst.cwd !== undefined && String(inst.cwd) !== '') ownKv.cwd = String(inst.cwd);
        try {
          const nsKey = String(inst.settingsNs || inst.id);
          writeOwnSettings(nsKey, Object.assign(readOwnSettings(nsKey), ownKv));
        } catch { /* 自有存储失败 → 退化到写 patch（下面仍会处理 disabled） */ }
        if (inst.disabled !== undefined) kv.disabled = inst.disabled ? 'true' : 'false';
        if (Object.keys(kv).length) updates.push({ id: String(inst.id), kv });
        updates.push({ id: String(inst.id), kv });
      } else {
        appends.push(renderBotBlock({ ...inst, appSecret: secret, dataRoot }));
      }
    }
    // 先删块(倒序), 再逐条原地改字段。
    // ⚠️ 每次更新前重新 parsePatch 取最新下标: splice 过(删除或插入新键)之后,
    //    之前算好的 start/end 会错位, 曾导致插入落到错误缩进上把 YAML 写坏。
    for (const r of removals.sort((a, b) => b.start - a.start)) lines.splice(r.start, r.end - r.start);
    for (const u of updates) {
      let fresh = null;
      try {
        const reparsed = parsePatchFrom(lines.join('\n'));
        fresh = reparsed.bots.find((b) => b.id === u.id) ?? null;
      } catch { fresh = null; }
      if (!fresh) continue;
      updateKeysInBlock(lines, fresh.start, fresh.end, u.kv);
    }
    let out = lines.join('\n').replace(/\n{3,}/g, '\n\n').trimEnd() + '\n';
    if (appends.length) out += (out.trimEnd() ? '\n' : '') + appends.join('\n') + '\n';
    writeFileSync(`${PATCH_FILE}.bak`, raw, 'utf8');
    // ✅ 2026-09-24 兜底①：写前按 (条目,缩进,键) 去重。
    //    起因：`- insert:` 下挂多条目时块边界会跨到隔壁条目，曾把凭据写进 mcp-chrome、
    //    并给 im-qqbot-3 追加重复键；重复键会让宿主 YAML 解析抛错、dsh 完全起不来。
    out = dedupeYamlKeys(out);
    // ✅ 2026-09-24 兜底②：把凭据同步写进插件自有存储。
    //    插件启动时自有存储**覆盖** patch 的值，所以即便 patch 被写歪，机器人照样用正确凭据连上。
    try {
      for (const inst of instances) {
        if (inst.remove) continue;
        const nsKey = String(inst.settingsNs || inst.id);
        const cur = readOwnSettings(nsKey);
        let sec = String(inst.appSecret ?? '');
        if (!sec || sec === SECRET_MASK) sec = cur.appSecret ? String(cur.appSecret) : '';
        if (inst.appId !== undefined) cur.appId = inst.appId;
        if (sec) cur.appSecret = sec;
        if (inst.preset) cur.preset = String(inst.preset);
        if (inst.cwd) cur.cwd = String(inst.cwd);
        if (inst.disabled !== undefined) cur.disabled = !!inst.disabled;
        writeOwnSettings(nsKey, cur);
      }
    } catch { /* 自有存储失败不阻塞 patch 写入 */ }
    writeFileSync(PATCH_FILE, out, 'utf8');
    return { ok: true, file: PATCH_FILE, needRestart: true };
  }


  // 账号列表(多账号: 每条带 settings ns 与数据目录, 供二级 UI 按账号读写)
  // 借鉴 zhengjy01/dsh-qqbot-panel(2026-09-06): appSecret 只回显掩码(不泄露明文),
  // 并带 hasSecret 供前端区分"已保存"与"真空"; 保存时空值/掩码 = 保留原 secret。
  const SECRET_MASK = '********';
  route(ctx, 'GET', '/api/qqbot-settings/accounts', async (_req, res) => {
    try {
      const { bots, hasFile } = parsePatch();
      const reg = await import('./dist/features/session-registry.js');
      writeJson(res, 200, {
        hasFile,
        instances: bots.map((b) => {
          const cwd = b.cfg?.cwd || '';
          // 数据根与 dist 侧 dataRootOf 对齐: 未配 dataRoot → `{cwd}/dshqqbot`(2026-09-12 新默认)
          const droot = b.cfg?.dataRoot || (cwd ? join(cwd, 'dshqqbot') : '');
          return {
            id: b.id,
            ns: b.id, // settings 命名空间 = 实例 id(主 im-qqbot; 非主实例 render 已写 settingsNs=id)
            appId: b.cfg?.appId || '',
            appSecret: b.cfg?.appSecret ? SECRET_MASK : '', // 掩码回显(借鉴 panel: masked)
            hasSecret: !!b.cfg?.appSecret,
            preset: b.cfg?.preset || '',
            cwd,
            disabled: !!b.disabled,
            online: typeof reg.isBotOnline === 'function' ? reg.isBotOnline(b.id) : false, // 在线状态(bot ws ready 事件驱动)
            // 账号数据目录(各号各库各定时): 图库={cwd}/表情包, 定时={cwd}/.qqbot
            dataDir: droot ? join(droot, '表情包') : '',
            schedDir: droot ? join(droot, '.qqbot') : '',
          };
        }),
      });
    } catch (e) { writeJson(res, 500, { error: String(e?.message ?? e) }); }
  });
  // 保存账号清单: body {instances:[{id,appId,appSecret,preset,cwd,disabled,remove}]}
  route(ctx, 'POST', '/api/qqbot-settings/accounts/save', async (req, res) => {
    const body = await readJsonBody(req);
    if (!body || !Array.isArray(body.instances)) return writeJson(res, 400, { error: 'instances 数组必填' });
    try {
      const r = saveInstances(body.instances);
      writeJson(res, r.ok ? 200 : 400, r);
    } catch (e) { writeJson(res, 500, { error: String(e?.message ?? e) }); }
  });

  // ── 工作区列表(借鉴 zhengjy01/dsh-qqbot-panel 的 workspace picker, 2026-09-06):
  //    列出"已有 dsh 会话"的工作区目录 + 会话数, 供账号 cwd 挑选(避免指到空目录/错目录)。
  //    dsh 把会话按工作区路径归到 ~/.dsh/sessions/--<编码路径>--, 目录内 *.zstd = 会话数。
  /** dsh session 目录名 → 工作区绝对路径(~XXXX 为 UTF-16 code unit, - 为段分隔, 首段补盘符冒号) */
  function decodeSessionDirName(name) {
    try {
      const segs = name.split('-').filter(Boolean);
      if (segs.length === 0) return '';
      const decoded = segs.map((s) => s.replace(/~([0-9A-F]{4})/g, (_m, hex) => String.fromCharCode(parseInt(hex, 16))));
      // 首段是盘符(D / C) → 补冒号; 其余段拼回路径分隔
      const head = /^[A-Za-z]$/.test(decoded[0]) ? decoded[0] + ':' : decoded[0];
      return [head].concat(decoded.slice(1)).join('\\');
    } catch { return ''; }
  }
  route(ctx, 'GET', '/api/qqbot-settings/workspaces', async (_req, res) => {
    try {
      const sessionsRoot = join(homedir(), '.dsh', 'sessions');
      const out = [];
      if (existsSync(sessionsRoot)) {
        for (const ent of readdirSync(sessionsRoot, { withFileTypes: true })) {
          if (!ent.isDirectory()) continue;
          const dir = join(sessionsRoot, ent.name);
          let count = 0;
          try {
            // 会话文件(.zstd)在 workspace 目录的深层子目录里, 需递归统计
            const stack = [dir];
            while (stack.length) {
              const cur = stack.pop();
              for (const f of readdirSync(cur, { withFileTypes: true })) {
                const p = join(cur, f.name);
                if (f.isDirectory()) stack.push(p);
                else if (f.isFile() && f.name.endsWith('.zstd')) count += 1;
              }
            }
          } catch { /* 目录读取失败忽略 */ }
          const path = decodeSessionDirName(ent.name);
          out.push({ dir: ent.name, path: path || ent.name, count });
        }
      }
      out.sort((a, b) => b.count - a.count);
      writeJson(res, 200, { workspaces: out });
    } catch (e) { writeJson(res, 500, { error: String(e?.message ?? e) }); }
  });

  // ── agent 预设: 列表/复制/打开文件夹/说明 ──
  /** QQ 通道工具插件的规范行 id/name(复制预设时自动补上; 新行名跟随本安装主包) */
  const CHANNEL_TOOLS_ROW_ID = 'qqbot-channel-tools';
  const CHANNEL_TOOLS_ROW_NAME = '@zaofan/dsh-qqbot/channel-tools';
  /** 检测 preset 的 agent.cordis.yml 是否已含 qqbot-channel-tools 插件行 */
  function presetHasChannelTools(base) {
    try {
      const txt = readFileSync(join(base, 'agent.cordis.yml'), 'utf8');
      // 匹配连续的 "- id: qqbot-channel-tools" 与 "name: .../channel-tools" 两行(m: $=每行行尾)
      return /id:\s*qqbot-channel-tools\s*\n[ \t]*name:\s*['"]?[^'\n]*\/channel-tools['"]?\s*$/m.test(txt);
    } catch { return false; }
  }
  /** 若 preset 缺 channel-tools 插件行, 在 agent.cordis.yml 末尾自动补上(幂等) */
  function ensureChannelToolsRow(base) {
    const p = join(base, 'agent.cordis.yml');
    let txt = '';
    try { txt = readFileSync(p, 'utf8'); } catch { return false; }
    if (presetHasChannelTools(base)) return true;
    const sep = txt.endsWith('\n') ? '' : '\n';
    txt += `${sep}- id: ${CHANNEL_TOOLS_ROW_ID}\n  name: '${CHANNEL_TOOLS_ROW_NAME}'\n`;
    writeFileSync(p, txt, 'utf8');
    return true;
  }
  function scanPresets() {
    if (!existsSync(PRESET_ROOT)) return [];
    const out = [];
    for (const dir of readdirSync(PRESET_ROOT, { withFileTypes: true })) {
      if (!dir.isDirectory()) continue;
      const id = dir.name;
      const base = join(PRESET_ROOT, id);
      if (!existsSync(join(base, 'agent.cordis.yml'))) continue;
      let name = '';
      try {
        const pm = join(base, 'preset.yml');
        if (existsSync(pm)) {
          const m = /^name:\s*(.*)$/m.exec(readFileSync(pm, 'utf8'));
          if (m) name = m[1].trim().replace(/^["']|["']$/g, '');
        }
      } catch { /* ignore */ }
      let mtime = 0;
      try { mtime = statSync(join(base, 'agent.cordis.yml')).mtimeMs; } catch { /* ignore */ }
      out.push({ id, name: name || id, mtime, hasChannelTools: presetHasChannelTools(base) });
    }
    return out.sort((a, b) => b.mtime - a.mtime);
  }
  /**
   * 列出可用预设（双模式，2026-09-23 适配 dsh 0.1.7）。
   *  - dsh 0.1.7+：走宿主 `agentPresets.list()` —— 新版预设是 profile 配置里的
   *    「声明行」(@deepseek-ai/dsh-agent-preset)，**已无目录**，扫目录只会得到空列表；
   *  - dsh ≤0.1.6：回落 `scanPresets()` 扫 {DSH_HOME}/.agent-presets 目录（旧机制）。
   *  统一返回 [{id, name, description, source}]，source=registry|dir。
   */
  /**
   * 安全取宿主 agentPresets 服务（2026-09-23 实测修正）。
   * ⚠️ cordis 对**未在 inject 里声明**的服务, 裸访问 `ctx.xxx` 会直接抛
   *    "cannot get property \"agentPresets\" without inject"（0.1.7 上实测命中）。
   *    而桥的 inject 只声明 settings/webServer（多声明会让宿主缺服务时整个 apply 不执行），
   *    所以这里必须用 **ctx.get()**（不抛）探测，拿不到返回 null 走旧目录回落。
   */
  function getAgentPresets() {
    try {
      if (ctx && typeof ctx.get === 'function') {
        const svc = ctx.get('agentPresets');
        if (svc) return svc;
      }
    } catch { /* ignore */ }
    try { return (ctx && ctx.agentPresets) || null; } catch { return null; }
  }
  async function listPresets() {
    const ap = getAgentPresets();
    if (ap && typeof ap.list === 'function') {
      try {
        const arr = await ap.list();
        if (Array.isArray(arr) && arr.length) {
          return arr
            .map((p) => ({
              id: String((p && p.id) || ''),
              name: String((p && (p.name || p.id)) || ''),
              description: String((p && p.description) || ''),
              source: 'registry',
            }))
            .filter((p) => p.id);
        }
      } catch { /* registry 不可用 → 回落旧目录 */ }
    }
    return scanPresets().map((p) => ({
      id: p.id,
      name: p.name,
      description: '',
      source: 'dir',
      mtime: p.mtime,
      hasChannelTools: p.hasChannelTools,
    }));
  }
  /**
   * 写操作在新版下的统一提示（2026-09-23）。
   * dsh 0.1.7+ 的注册表「不写入任何声明、没有任何接口接受 YAML 写回」，
   * 新增/覆盖预设只能写 profile 的 bundle 补丁 —— 与其静默失败，不如给出明确指引。
   * 返回 null 表示走旧版目录流程。
   */
  function presetWriteBlocked() {
    const ap = getAgentPresets();
    if (ap && typeof ap.list === 'function') {
      return '当前 dsh 版本的预设是「profile 配置里的声明行」，不再是目录文件（官方注册表不接受任何写回）。'
        + '请在 profile 的 cordis.patch.yml 里用 `- insert:` 添加/修改 `@deepseek-ai/dsh-agent-preset` 行'
        + '（或用创造模式生成 bundle），保存后由 patchReload 热生效。';
    }
    return null;
  }
  route(ctx, 'GET', '/api/qqbot-settings/presets', async (_req, res) => {
    try {
      const presets = await listPresets();
      const viaRegistry = presets.some((p) => p.source === 'registry');
      writeJson(res, 200, { root: viaRegistry ? null : PRESET_ROOT, presets, mode: viaRegistry ? 'registry' : 'dir' });
    } catch (e) {
      writeJson(res, 500, { error: String((e && e.message) || e) });
    }
  });
  // 复制并双名: {sourceId, newId, newName}
  route(ctx, 'POST', '/api/qqbot-settings/presets/copy', async (req, res) => {
    const body = await readJsonBody(req);
    // dsh 0.1.7+：预设是 profile patch 里的声明行 → 复制 = 整段搬运 + 改写 id/name
    if (getAgentPresets()) {
      if (!body || typeof body.sourceId !== 'string' || typeof body.newId !== 'string') {
        return writeJson(res, 400, { error: 'sourceId/newId 必填' });
      }
      const nId = body.newId.trim();
      if (!ID_RE.test(nId)) return writeJson(res, 400, { error: '预设 id 只能字母/数字开头，含 - _' });
      if (nId === String(body.sourceId).trim()) return writeJson(res, 400, { error: '新预设 id 不能与源相同' });
      const nName = String(body.newName ?? nId).trim() || nId;
      try {
        const arr = await getAgentPresets().list();
        if (Array.isArray(arr) && arr.some((x) => x && x.id === nId)) {
          return writeJson(res, 409, { error: '预设 ' + nId + ' 已存在' });
        }
      } catch { /* 列表不可用时靠 patch 自身判断 */ }
      const srcId = String(body.sourceId).trim();
      // 先按 patch 里的原块整段复制（原汁原味、字节保真）；
      // patch 里没有（如宿主内置预设 standard）→ 回退用宿主文档读出组成再生成
      let r = copyPresetDecl(srcId, nId, nName);
      if (!r.ok) r = await copyPresetViaDocument(srcId, nId, nName);
      if (!r.ok) return writeJson(res, 404, { error: r.error });
      return writeJson(res, 200, { ok: true, newId: nId, backup: r.backup, note: '已写入 profile patch，热生效（新会话生效）' });
    }
    if (!body || typeof body.sourceId !== 'string' || typeof body.newId !== 'string') {
      return writeJson(res, 400, { error: 'sourceId/newId 必填' });
    }
    const newId = body.newId.trim();
    if (!ID_RE.test(newId)) return writeJson(res, 400, { error: '预设 id 只能字母/数字开头，含 - _（也是文件夹名）' });
    const src = join(PRESET_ROOT, String(body.sourceId).trim());
    const dst = join(PRESET_ROOT, newId);
    if (!existsSync(join(src, 'agent.cordis.yml'))) return writeJson(res, 404, { error: '源预设不存在' });
    if (existsSync(dst)) return writeJson(res, 409, { error: `预设 ${newId} 已存在` });
    try {
      cpSync(src, dst, { recursive: true, filter: (s) => !COPY_SKIP.test(s) });
      // 复制出的新预设自动补上 QQ 通道工具插件行(缺则加; 幂等)——保证新人格在 QQ 里能发图/查表情包
      ensureChannelToolsRow(dst);
      // 人设名写入新 preset.yml(name 为 YAML 双引号标量; JSON 转义兼容)
      const pm = join(dst, 'preset.yml');
      if (existsSync(pm)) {
        const txt = readFileSync(pm, 'utf8');
        const nameYaml = JSON.stringify(String(body.newName ?? newId));
        const next = txt.replace(/^name:.*$/m, `name: ${nameYaml}`);
        writeFileSync(pm, next, 'utf8');
      }
      writeJson(res, 200, { ok: true, newId });
    } catch (e) { writeJson(res, 500, { error: String(e?.message ?? e) }); }
  });
  // 从内置"标准模式(standard)"新建一个预设(空机器起步用): 复制宿主 standard + 自动补 QQ 通道工具行
  // 复用宿主原生 agentPresets.copy(from,id,name) —— 复制出的正是宿主当前标准版, 保证能跑; 无需自己拼组合。
  route(ctx, 'POST', '/api/qqbot-settings/presets/new', async (req, res) => {
    const body = await readJsonBody(req);
    // dsh 0.1.7+：从 profile patch 里的 preset-standard 声明整段复制出一个新预设
    if (getAgentPresets()) {
      const nId = String(body?.id ?? '').trim();
      const nName = String(body?.name ?? '').trim() || nId;
      if (!ID_RE.test(nId)) return writeJson(res, 400, { error: '预设 id 只能字母/数字开头，含 - _' });
      // standard 是**宿主内置**预设（不在用户 patch 里）→ 用宿主的预设文档读它的组成
      let r = await copyPresetViaDocument('standard', nId, nName);
      if (!r.ok) {
        // 兜底：万一 patch 里正好也有一份 preset-standard，就直接整段复制
        const local = copyPresetDecl('standard', nId, nName);
        if (local.ok) r = local;
      }
      if (!r.ok) return writeJson(res, 500, { error: r.error });
      return writeJson(res, 200, { ok: true, newId: nId, backup: r.backup, note: '已从 standard 生成新预设并写入 profile patch，热生效' });
    }
    const newId = String(body?.id ?? '').trim();
    const newName = String(body?.name ?? '').trim() || undefined;
    if (!ID_RE.test(newId)) return writeJson(res, 400, { error: '预设 id 只能字母/数字开头，含 - _（也是文件夹名）' });
    try {
      const ap = getAgentPresets();
      if (!ap || typeof ap.copy !== 'function') {
        return writeJson(res, 500, { error: '宿主未提供 agentPresets 服务, 无法从标准模式新建' });
      }
      await ap.copy('standard', newId, newName);
      const dstDir = join(PRESET_ROOT, newId);
      ensureChannelToolsRow(dstDir);
      writeJson(res, 200, { ok: true, newId });
    } catch (e) {
      const msg = String(e?.message ?? e);
      // 宿主 RemoteError 里的用户可读文案: 取含中文(预设/已存在)的后段
      const m = /(预设|preset|id|已存在|exist)[^\n]*$/im.exec(msg);
      writeJson(res, 500, { error: m ? m[0] : msg });
    }
  });
  // 打开预设文件夹(本机弹资源管理器; 仅限 presetRoot 内白名单路径)
  route(ctx, 'POST', '/api/qqbot-settings/presets/open', async (req, res) => {
    const blocked = presetWriteBlocked();
    if (blocked) return writeJson(res, 501, { error: blocked });
    const body = await readJsonBody(req);
    const id = String(body?.id ?? '').trim();
    if (!ID_RE.test(id)) return writeJson(res, 400, { error: '非法的预设 id' });
    const dir = join(PRESET_ROOT, id);
    if (!dir.startsWith(PRESET_ROOT) || !existsSync(join(dir, 'agent.cordis.yml'))) {
      return writeJson(res, 404, { error: '预设不存在' });
    }
    try {
      const child = spawn('explorer', [dir], { detached: true, stdio: 'ignore' });
      child.unref();
      writeJson(res, 200, { ok: true });
    } catch (e) { writeJson(res, 500, { error: String(e?.message ?? e) }); }
  });


  // ── 预设人格文件浏览/编辑(2026-09-07): "展开改写人格"。安全: 仅 PRESET_ROOT/{id} 内白名单文件;
  //    写权限仅限"复制出来带QQ工具标记"的副本(防误改内置/半成品); 大小上限 200KB。
  //
  // ── 2026-09-24 适配 dsh 0.1.7：预设改为 profile patch 里的声明行后，目录没了，
  //    但「人设正文」仍在 patch 内（persona 插件 config.prefix 的块标量）。
  //    这里为它提供"虚拟文件"读写：只动那一段块标量，其余内容一个字节都不碰。
  const PRESET_EDIT_EXT = /.(yml|yaml|json|mjs|js|md|txt)$/i;
  const PRESET_EDIT_MAX = 200 * 1024;

  /** 定位 profile patch 里某个预设声明块 `- id: preset-<id>`。 */
  function locatePresetBlock(lines, presetId) {
    const esc = String(presetId).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const re = new RegExp('^\\s*-\\s*id:\\s*[\'"]?preset-' + esc + '[\'"]?\\s*$');
    const head = lines.findIndex((l) => re.test(l));
    if (head < 0) return null;
    const headIndent = (lines[head].match(/^\s*/) || [''])[0].length;
    let end = lines.length;
    for (let i = head + 1; i < lines.length; i++) {
      const ind = (lines[i].match(/^\s*/) || [''])[0].length;
      if (/- /.test(lines[i]) && ind <= headIndent) { end = i; break; }
    }
    return { head, headIndent, end };
  }

  /**
   * 读预设的人设正文（0.1.7 路径）。
   * 结构: preset 块 → `- id: persona` → `prefix|text|prompt: |-` → 块标量正文
   * @returns {{text:string, indent:number, bodyStart:number, bodyEnd:number}|null}
   */
  function readPresetPersona(presetId, linesOverride) {
    try {
      if (!existsSync(PATCH_FILE)) return null;
      const lines = linesOverride || readFileSync(PATCH_FILE, 'utf8').split(/\r\n|\n/);
      const blk = locatePresetBlock(lines, presetId);
      if (!blk) return null;
      let pi = -1;
      for (let i = blk.head + 1; i < blk.end; i++) {
        if (/^\s*-\s*id:\s*['"]?persona['"]?\s*$/.test(lines[i])) { pi = i; break; }
      }
      if (pi < 0) return null;
      const personaIndent = (lines[pi].match(/^\s*/) || [''])[0].length;
      let ki = -1;
      let indent = 0;
      let inline = false;
      let inlineVal = '';
      for (let i = pi + 1; i < blk.end; i++) {
        const l = lines[i];
        if (/^\s*#/.test(l)) continue;                                   // 注释行跳过
        const mB = /^(\s*)(?:prefix|text|prompt):\s*\|-?\s*$/.exec(l);
        if (mB) { ki = i; indent = mB[1].length; inline = false; break; }
        const mI = /^(\s*)(?:prefix|text|prompt):\s+(\S.*)$/.exec(l);    // 行内标量写法
        if (mI) { ki = i; indent = mI[1].length; inline = true; inlineVal = mI[2].trim(); break; }
        const ind = (l.match(/^\s*/) || [''])[0].length;
        if (/- /.test(l) && ind <= personaIndent) break;
      }
      if (ki < 0) return null;
      if (inline) {
        // 行内写法（如 `prefix: 你是一个 xx 助手`）→ 直接返回那一句
        let v = inlineVal;
        if ((v.startsWith("'") && v.endsWith("'")) || (v.startsWith('"') && v.endsWith('"'))) v = v.slice(1, -1);
        return { text: v, indent: indent + 2, bodyStart: ki + 1, bodyEnd: ki + 1, inline: true, lineIndex: ki };
      }
      let bEnd = ki + 1;
      while (bEnd < blk.end) {
        const raw = lines[bEnd];
        if (raw.trim() === '') { bEnd++; continue; }
        if (((raw.match(/^\s*/) || [''])[0]).length <= indent) break;
        bEnd++;
      }
      let last = bEnd;
      while (last > ki + 1 && lines[last - 1].trim() === '') last--;
      const body = lines.slice(ki + 1, last);
      const cuts = body.filter((l) => l.trim()).map((l) => (l.match(/^\s*/) || [''])[0].length);
      const cut = cuts.length ? Math.min(...cuts) : indent + 2;
      // 纯空白行原样保留（既不切片也不补缩进），保证「读出 → 原样写回」字节级一致
      const text = body.map((l) => (l.trim() === '' ? l : l.slice(cut))).join('\n');
      return { text, indent: cut, bodyStart: ki + 1, bodyEnd: last };
    } catch { return null; }
  }

  /**
   * 复制一个预设声明（dsh 0.1.7 路径）：在 profile patch 里把 `- id: preset-<src>` 整段
   * 复制一份，只改写三处后追加到顶层数组 —— `- id:` / `config.id` / `config.name`，其余一个字节不动。
   * 行内换行按原文保真，缩进原样搬运。
   */
  function copyPresetDecl(srcId, newId, newName) {
    try {
      if (!existsSync(PATCH_FILE)) return { ok: false, error: 'profile patch 不存在' };
      const raw = readFileSync(PATCH_FILE, 'utf8');
      const parts = raw.split(/(\r\n|\n)/);
      const lineTexts = [];
      const eols = [];
      for (let i = 0; i < parts.length; i++) {
        if (i % 2 === 0) lineTexts.push(parts[i]);
        else eols.push(parts[i]);
      }
      const blk = locatePresetBlock(lineTexts, srcId);
      if (!blk) return { ok: false, error: '在 profile patch 里找不到源预设 preset-' + srcId };
      const escRe = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const headRe = new RegExp('id:\\s*[\'"]?preset-' + escRe(srcId) + '[\'"]?');
      const seg = lineTexts.slice(blk.head, blk.end);
      const out = [];
      let cfgIndent = -1;
      for (let i = 0; i < seg.length; i++) {
        let l = seg[i];
        const ind = (l.match(/^\s*/) || [''])[0].length;
        if (i === 0) {
          l = l.replace(headRe, 'id: preset-' + newId);
        } else {
          const mCfg = /^(\s*)config:\s*$/.exec(l);
          if (mCfg) { cfgIndent = mCfg[1].length; }
          else if (cfgIndent >= 0 && ind === cfgIndent + 2) {
            if (/^\s*id:\s/.test(l)) l = l.replace(/id:\s*.*$/, 'id: ' + newId);
            else if (/^\s*name:\s/.test(l)) l = l.replace(/name:\s*.*$/, 'name: ' + newName);
          }
        }
        out.push(l);
      }
      const eol = eols[blk.end - 1] || eols[blk.head] || '\n';
      let add = '';
      for (const l of out) add += l + eol;
      let text = raw;
      if (!/[\r\n]$/.test(text)) text += eol;
      text += add;
      const bak = PATCH_FILE + '.bak-copy-' + Date.now();
      try { writeFileSync(bak, raw, 'utf8'); } catch { /* 备份失败不阻塞 */ }
      writeFileSync(PATCH_FILE, text, 'utf8');
      return { ok: true, backup: bak, newId };
    } catch (e) { return { ok: false, error: String((e && e.message) || e) }; }
  }

  /**
   * 用宿主的 `agentPresets.readDocument(id)` 读来源预设的组成，生成一条新的 preset 声明写进 patch。
   * 用途：**内置预设**（如 `standard`，它不在用户 patch 里）或任何 patch 中不存在的预设。
   * readDocument 官方标注"仅用于查看"——我们只把它当模板读出来，写进**自己的** profile patch。
   */
  async function copyPresetViaDocument(srcId, newId, newName) {
    const ap = getAgentPresets();
    if (!ap || typeof ap.readDocument !== 'function') {
      return { ok: false, error: '宿主未提供 agentPresets.readDocument（读不了内置预设的组成）' };
    }
    let doc;
    try { doc = await ap.readDocument(srcId); }
    catch (e) { return { ok: false, error: '读取源预设 ' + srcId + ' 失败：' + String((e && e.message) || e) }; }
    const content = String((doc && doc.content) || '');
    if (!content.trim()) return { ok: false, error: '源预设 ' + srcId + ' 的组成为空' };
    const pad = '          ';
    const head = [
      '# ── 复制自 ' + srcId + '（组成由宿主的预设文档读出）──',
      '- insert:',
      '    - id: preset-' + newId,
      "      name: '@deepseek-ai/dsh-agent-preset'",
      '      config:',
      '        id: ' + newId,
      '        name: ' + newName,
      '        plugins:',
    ];
    const bodyLines = content.split(/\r\n|\n/).map((l) => (l.trim() === '' ? '' : pad + l));
    const raw = readFileSync(PATCH_FILE, 'utf8');
    const parts = raw.split(/(\r\n|\n)/);
    const eol = parts[1] ?? '\n';
    let text = raw;
    if (!/[\r\n]$/.test(text)) text += eol;
    text += head.join(eol) + eol + bodyLines.join(eol) + eol;
    const bak = PATCH_FILE + '.bak-newpreset-' + Date.now();
    try { writeFileSync(bak, raw, 'utf8'); } catch { /* 备份失败不阻塞 */ }
    writeFileSync(PATCH_FILE, text, 'utf8');
    return { ok: true, backup: bak, newId, from: 'document' };
  }

  /** YAML 标量序列化。forceQuote=true 时强制加引号（保留原字段的字符串类型 —— 例如 appId
   *  的 schema 是 string，裸写数字会被 YAML 解析成 number → 宿主 schema 校验失败）。 */
  function yScalar(v, forceQuote) {
    if (v === null || v === undefined) return "''";
    if (typeof v === 'boolean') return String(v);
    const s = String(v);
    if (typeof v === 'number' && !forceQuote) return s;       // 真正的数字字段（historyLimit 等）保持数字
    if (forceQuote) return "'" + s.replace(/'/g, "''") + "'";
    if (typeof v === 'string') {
      if (s === '' || /[:#'"\[\]{}&*!|>%@`,]/.test(s) || /^\s|\s$/.test(s) || /^(true|false|null|~|-?\d)/i.test(s)) {
        return "'" + s.replace(/'/g, "''") + "'";
      }
    }
    return s;
  }
  /** 把值序列化成"一行 YAML"（数组走流式，避免多行插入）。keepType 提示按原字段类型保真。 */
  function yValue(v, keepQuoted, origWasArray) {
    if (Array.isArray(v)) {
      if (!v.length) return '[]';
      return '[' + v.map((it) => yScalar(it, typeof it === 'string')).join(', ') + ']';
    }
    if (v === '' || v === null || v === undefined) {
      // ⚠️ 空值必须看原字段类型：原本是数组的（owners）写成 `''` 会让宿主 schema 校验失败
      return origWasArray ? '[]' : "''";
    }
    return yScalar(v, keepQuoted || typeof v === 'string');
  }

  /**
   * 把一批字段合并进 profile patch 里某个 entry 的 `config`（dsh 0.1.7 路径，2026-09-24）。
   *
   * 为什么需要：0.1.7 的 `settings.update()` 只接受 **schema 里声明为 volatile** 的字段
   * （源码：`const form = volatileForm(schema); if (!form) throw new Error('Plugin entry "x" has no volatile fields')`），
   * 本插件用自定义 config、没有 schemastery schema → 保存必被拒。这里改为直接改 profile patch：
   * **已存在的字段就地替换值**；patch 里没有的字段记入 `missing` 返回给前端（不擅自新增结构）。
   * 支持一层嵌套对象。写前自动备份，换行逐行保真。
   */
  function mergeEntryConfigInPatch(entryId, patch) {
    try {
      if (!existsSync(PATCH_FILE)) return { ok: false, error: 'profile patch 不存在' };
      if (!patch || typeof patch !== 'object') return { ok: false, error: 'patch 必须是对象' };
      const raw = readFileSync(PATCH_FILE, 'utf8');
      const parts = raw.split(/(\r\n|\n)/);
      const lineTexts = [];
      const eols = [];
      for (let i = 0; i < parts.length; i++) {
        if (i % 2 === 0) lineTexts.push(parts[i]);
        else eols.push(parts[i]);
      }
      const esc = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const headRe = new RegExp('^\\s*-\\s*id:\\s*[\'"]?' + esc(entryId) + '[\'"]?\\s*$');
      const start = lineTexts.findIndex((l) => headRe.test(l));
      if (start < 0) return { ok: false, error: '在 profile patch 里找不到 entry ' + entryId };
      const headIndent = (lineTexts[start].match(/^\s*/) || [''])[0].length;
      let end = lineTexts.length;
      for (let i = start + 1; i < lineTexts.length; i++) {
        const ind = (lineTexts[i].match(/^\s*/) || [''])[0].length;
        if (/- /.test(lineTexts[i]) && ind <= headIndent) { end = i; break; }
      }
      let ci = -1;
      for (let i = start + 1; i < end; i++) {
        if (/^\s*config:\s*$/.test(lineTexts[i])) { ci = i; break; }
      }
      if (ci < 0) return { ok: false, error: 'entry ' + entryId + ' 在 profile patch 里没有 config: 段' };
      const cfgIndent = (lineTexts[ci].match(/^\s*/) || [''])[0].length;
      const keyIndent = cfgIndent + 2;
      let cEnd = ci + 1;
      for (let i = ci + 1; i < end; i++) {
        if (lineTexts[i].trim() && ((lineTexts[i].match(/^\s*/) || [''])[0]).length <= cfgIndent) break;
        cEnd = i + 1;
      }
      const missing = [];
      const setKey = (key, value, from, to, indent) => {
        // ⚠️ 脱敏占位符绝不写回（2026-09-24 实测事故）：设置页读到的是 viewOf 打码过的
        //    `__REDACTED__`，若原样写入就会把真密钥覆盖掉。这个值一律视为"未修改"。
        if (value === '__REDACTED__') return true;
        const re = new RegExp('^\\s{' + indent + '}' + esc(key) + ':\\s*(.*)$');
        for (let i = from; i < to; i++) {
          if (!re.test(lineTexts[i])) continue;
          if (value && typeof value === 'object' && !Array.isArray(value)) {
            let subEnd = i + 1;
            for (let j = i + 1; j < to; j++) {
              if (lineTexts[j].trim() && ((lineTexts[j].match(/^\s*/) || [''])[0]).length <= indent) break;
              subEnd = j + 1;
            }
            for (const [k, v] of Object.entries(value)) {
              if (v === undefined) continue;
              if (!setKey(k, v, i + 1, subEnd, indent + 2)) missing.push(key + '.' + k);
            }
            return true;
          }
          // 按**原字段类型**保真写入（引号风格 / 数组 / 空值），避免写坏宿主 schema：
          // 实测踩坑：appId 裸写数字 → "expected string"；owners 空值写成 '' → "expected array"
          const origRaw = String(lineTexts[i] || '');
          const origVal = ((origRaw.match(/:\s*(.*)$/) || [])[1] || '').trim();
          const origWasArray = origVal === '[]' || origVal.startsWith('- ');
          const keepQuoted = /^['"]/.test(origVal);
          lineTexts[i] = ' '.repeat(indent) + key + ': ' + yValue(value, keepQuoted, origWasArray);
          return true;
        }
        return false;
      };
      for (const [k, v] of Object.entries(patch)) {
        if (v === undefined) continue;
        if (!setKey(k, v, ci + 1, cEnd, keyIndent)) missing.push(k);
      }
      let out = '';
      for (let i = 0; i < lineTexts.length; i++) {
        out += lineTexts[i];
        if (i < eols.length) out += eols[i];
      }
      const bak = PATCH_FILE + '.bak-cfg-' + Date.now();
      try { writeFileSync(bak, raw, 'utf8'); } catch { /* 备份失败不阻塞 */ }
      writeFileSync(PATCH_FILE, out, 'utf8');
      return { ok: true, backup: bak, missing };
    } catch (e) { return { ok: false, error: String((e && e.message) || e) }; }
  }

  /** 写回人设正文（只替换那段块标量，写前自动备份整个 patch）。
   *  ⚠️ 换行符**逐行保真**：patch 可能 LF/CRLF 混用（实测踩过），统一 eol 会改掉别处字节。 */
  function writePresetPersona(presetId, text) {
    try {
      if (!existsSync(PATCH_FILE)) return { ok: false, error: 'profile patch 不存在' };
      const raw = readFileSync(PATCH_FILE, 'utf8');
      const parts = raw.split(/(\r\n|\n)/);
      const lineTexts = [];
      const eols = [];
      for (let i = 0; i < parts.length; i++) {
        if (i % 2 === 0) lineTexts.push(parts[i]);
        else eols.push(parts[i]);
      }
      const found = readPresetPersona(presetId, lineTexts);
      if (!found) return { ok: false, error: '没找到该预设的人设段落（persona / prefix）' };
      let pad;
      let insertAt;
      let endAt;
      if (found.inline) {
        // 行内标量 → 升级成块标量（`prefix: |-` + 缩进正文），这样多行人设也存得下
        const keyRaw = lineTexts[found.lineIndex];
        const key = (/(prefix|text|prompt):/.exec(keyRaw) || [])[1] || 'prefix';
        const keyIndent = (keyRaw.match(/^\s*/) || [''])[0];
        lineTexts[found.lineIndex] = keyIndent + key + ': |-';
        pad = keyIndent + '  ';
        insertAt = found.lineIndex + 1;
        endAt = found.lineIndex + 1;
      } else {
        pad = ' '.repeat(found.indent);
        insertAt = found.bodyStart;
        endAt = found.bodyEnd;
      }
      const nl = eols[insertAt - 1] || '\n';   // 沿用原段落的换行风格
      const body = String(text).split(/\r\n|\n|\r/).map((l) => (l.trim() === '' ? l : pad + l));
      const head = lineTexts.slice(0, insertAt);
      const tail = lineTexts.slice(endAt);
      let out = '';
      for (let i = 0; i < head.length; i++) out += head[i] + (eols[i] ?? '\n');
      for (const l of body) out += l + nl;
      for (let i = 0; i < tail.length; i++) {
        out += tail[i];
        const ei = endAt + i;
        if (ei < eols.length) out += eols[ei];
      }
      const bak = PATCH_FILE + '.bak-persona-' + Date.now();
      try { writeFileSync(bak, raw, 'utf8'); } catch { /* 备份失败不阻塞 */ }
      writeFileSync(PATCH_FILE, out, 'utf8');
      return { ok: true, backup: bak };
    } catch (e) { return { ok: false, error: String((e && e.message) || e) }; }
  }

  function presetDirSafe(id) {
    if (!ID_RE.test(String(id || ''))) return null;
    const dir = resolve(PRESET_ROOT, id);
    if (!dir.startsWith(resolve(PRESET_ROOT) + sep)) return null;
    if (!existsSync(join(dir, 'agent.cordis.yml'))) return null;
    return dir;
  }
  function presetWritable(id) {
    // 安全规则: 仅"复制出来带 QQ 工具标记"的预设可改写(底层/实验预设保持只读)。
    const p = scanPresets().find((x) => x.id === id);
    return !!(p && p.hasChannelTools);
  }
  route(ctx, 'GET', '/api/qqbot-settings/presets/files', async (req, res) => {
    const q = new URL(req.url, 'http://x').searchParams;
    const rid = String(q.get('id') || '').trim();
    // dsh 0.1.7+：预设声明在 profile patch 里 → 对外虚拟成「人设正文」一个可编辑文件
    if (getAgentPresets()) {
      if (!ID_RE.test(rid)) return writeJson(res, 400, { error: '非法的预设 id' });
      const persona = readPresetPersona(rid);
      if (!persona) return writeJson(res, 404, { error: '该预设没有内联人设段落（persona / prefix）；人格可能在外部 .mjs 文件里' });
      return writeJson(res, 200, {
        id: rid,
        dir: '(profile patch)',
        writable: true,
        files: [{ name: 'persona（人设正文）', size: Buffer.byteLength(persona.text, 'utf8'), mtime: 0 }],
      });
    }
    const dir = presetDirSafe(rid);
    if (!dir) return writeJson(res, 404, { error: '预设不存在' });
    try {
      const files = readdirSync(dir, { withFileTypes: true })
        .filter((d) => d.isFile() && PRESET_EDIT_EXT.test(d.name))
        .map((d) => { const st = statSync(join(dir, d.name)); return { name: d.name, size: st.size, mtime: st.mtimeMs }; })
        .sort((a, b) => (b.name === 'agent.cordis.yml' ? 1 : 0) - (a.name === 'agent.cordis.yml' ? 1 : 0) || a.name.localeCompare(b.name));
      writeJson(res, 200, { id: q.get('id'), dir, writable: presetWritable(q.get('id')), files });
    } catch (e) { writeJson(res, 500, { error: String(e?.message ?? e) }); }
  });
  route(ctx, ['GET', 'PUT'], '/api/qqbot-settings/presets/file', async (req, res) => {
    // dsh 0.1.7+：只支持「人设正文」这一个虚拟文件的读写（落在 profile patch 的 persona 块标量里）
    if (getAgentPresets()) {
      if (req.method === 'PUT') {
        const body = await readJsonBody(req);
        const id = String(body?.id ?? '').trim();
        if (!ID_RE.test(id)) return writeJson(res, 400, { error: '非法的预设 id' });
        const content = String(body?.content ?? '');
        if (Buffer.byteLength(content, 'utf8') > PRESET_EDIT_MAX) return writeJson(res, 400, { error: '内容过大(上限 200KB)' });
        const w = writePresetPersona(id, content);
        if (!w.ok) return writeJson(res, 500, { error: w.error });
        return writeJson(res, 200, {
          ok: true,
          name: 'persona（人设正文）',
          size: Buffer.byteLength(content, 'utf8'),
          backup: w.backup,
          note: '已写入 profile patch，patchReload 热生效（新会话生效）',
        });
      }
      const q = new URL(req.url, 'http://x').searchParams;
      const id = String(q.get('id') || '').trim();
      if (!ID_RE.test(id)) return writeJson(res, 400, { error: '非法的预设 id' });
      const persona = readPresetPersona(id);
      if (!persona) return writeJson(res, 404, { error: '该预设没有内联人设段落（persona / prefix）' });
      return writeJson(res, 200, { id, name: 'persona（人设正文）', content: persona.text, writable: true });
    }
    if (req.method === 'PUT') {
      const body = await readJsonBody(req);
      const id = String(body?.id ?? '');
      const dir = presetDirSafe(id);
      const name = String(body?.name ?? '');
      if (!dir || !PRESET_EDIT_EXT.test(name)) return writeJson(res, 400, { error: '参数不合法' });
      const p = join(dir, name);
      if (!existsSync(p) || !resolve(p).startsWith(resolve(dir) + sep)) return writeJson(res, 404, { error: '文件不存在' });
      if (!presetWritable(id)) return writeJson(res, 403, { error: '安全限制: 仅"带QQ工具标记"的复制预设可改写(底层预设只读)' });
      const content = String(body?.content ?? '');
      if (Buffer.byteLength(content, 'utf8') > PRESET_EDIT_MAX) return writeJson(res, 400, { error: '内容过大(上限 200KB)' });
      try {
        const tmp = p + '.tmp-' + Date.now();
        writeFileSync(tmp, content, 'utf8');
        renameSync(tmp, p);
        writeJson(res, 200, { ok: true, name, size: Buffer.byteLength(content, 'utf8') });
      } catch (e) { writeJson(res, 500, { error: String(e?.message ?? e) }); }
      return;
    }
    const q = new URL(req.url, 'http://x').searchParams;
    const id = q.get('id') || '';
    const dir = presetDirSafe(id);
    const name = String(q.get('name') || '');
    if (!dir || !PRESET_EDIT_EXT.test(name)) return writeJson(res, 400, { error: '参数不合法' });
    const p = join(dir, name);
    if (!existsSync(p) || !resolve(p).startsWith(resolve(dir) + sep)) return writeJson(res, 404, { error: '文件不存在' });
    try { writeJson(res, 200, { id, name, content: readFileSync(p, 'utf8') }); }
    catch (e) { writeJson(res, 500, { error: String(e?.message ?? e) }); }
  });

  // ── QQ 菜单/指令面板管理(2026-09-07): 经 QQBot.api 网关转发官方接口(v2/menu、v2/panels CRUD+target)。
  //    面板=机器人在会话/群里的指令入口; 菜单=长按/下拉快捷菜单。白名单 path, 仅本机 loopback 可调。
  const QQ_API_PATH_RE = new RegExp('^/v2/(menu|panels)(/[A-Za-z0-9_-]+)?(/target)?$');
  route(ctx, 'POST', '/api/qqbot-settings/qq/proxy', async (req, res) => {
    const body = await readJsonBody(req);
    const ns = String(body?.ns ?? '');
    const method = String(body?.method ?? 'GET').toUpperCase();
    const path = String(body?.path ?? '');
    if (!QQ_API_PATH_RE.test(path)) return writeJson(res, 400, { error: '仅支持 /v2/menu 与 /v2/panels 相关接口' });
    if (!['GET', 'POST', 'PUT', 'PATCH', 'DELETE'].includes(method)) return writeJson(res, 400, { error: '不支持的方法' });
    try {
      const gc = await groupClientOf(ns);
      const apiG = gc && gc.client && gc.client.api;
      if (!apiG || typeof apiG.get !== 'function') return writeJson(res, 400, { error: '找不到该账号实例(未配置/未连接)' });
      const fn = apiG[method.toLowerCase()];
      if (typeof fn !== 'function') return writeJson(res, 400, { error: '网关不支持 ' + method });
      const out = (method === 'GET' || method === 'DELETE')
        ? await fn(path, body && body.query)
        : await fn(path, body && body.body);
      writeJson(res, 200, out ?? { ok: true });
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      const code = e && e.code;
      writeJson(res, 200, { ok: false, err: { code: code || 'QQ_API_ERROR', human: msg } });
    }
  });

  // ── 扫码绑定注册流程(每个账号走 QQ 官方绑定, 拿平台下发的 appId/appSecret) ──(每个账号走 QQ 官方绑定, 拿平台下发的 appId/appSecret) ──
  // 前端拿 qrUrl 打开授权页(手机 QQ 扫码) → host 轮询 → 完成回填。displayQrCodeToConsole=false。
  const bindSessions = new Map(); // id -> {url, creds, error, stop}
  let bindSeq = 0;
  route(ctx, 'POST', '/api/qqbot-settings/bind/start', async (_req, res) => {
    const id = 'bind-' + (++bindSeq) + '-' + Date.now().toString(36);
    try {
      const { startQrConnect } = await import('@tencent-connect/qqbot-connector');
      const sess = { url: '', creds: null, error: null };
      bindSessions.set(id, sess);
      const stop = startQrConnect({
        onSuccess: (creds) => { sess.creds = Array.isArray(creds) ? creds[0] : creds; },
        onFailure: (err) => { sess.error = String(err?.message ?? err); },
        onQrDisplayed: (url) => { sess.url = url; },
        onQrExpired: () => { /* 前端轮询会拿到新 url */ },
      }, { displayQrCodeToConsole: false, source: 'dsh-qqbot' });
      sess.stop = stop;
      // 等第一个二维码 URL(最多 12s)
      const deadline = Date.now() + 12000;
      while (!sess.url && !sess.error && Date.now() < deadline) {
        await new Promise((r) => setTimeout(r, 300));
      }
      if (!sess.url) {
        stop();
        bindSessions.delete(id);
        return writeJson(res, 500, { error: sess.error || '获取绑定二维码超时' });
      }
      writeJson(res, 200, { id, url: sess.url });
    } catch (e) {
      writeJson(res, 500, { error: String(e?.message ?? e) });
    }
  });
  route(ctx, 'GET', '/api/qqbot-settings/bind/poll', async (req, res) => {
    const u = new URL(req.url ?? '/', 'http://x');
    const id = u.searchParams.get('id') || '';
    const sess = bindSessions.get(id);
    if (!sess) return writeJson(res, 404, { error: '绑定会话不存在或已结束' });
    if (sess.creds) { bindSessions.delete(id); return writeJson(res, 200, { status: 'done', appId: sess.creds.appId, appSecret: sess.creds.appSecret }); }
    if (sess.error) { bindSessions.delete(id); return writeJson(res, 200, { status: 'error', error: sess.error }); }
    writeJson(res, 200, { status: 'wait', url: sess.url });
  });
  route(ctx, 'POST', '/api/qqbot-settings/bind/cancel', async (req, res) => {
    const body = await readJsonBody(req);
    const sess = bindSessions.get(String(body?.id ?? ''));
    if (sess) { try { sess.stop?.(); } catch { /* ignore */ } bindSessions.delete(String(body?.id ?? '')); }
    writeJson(res, 200, { ok: true });
  });

  // ── 图库管理 ──
  // 列表: /api/qqbot-settings/stickers?layer=&q=&untagged=1&includeTrash=1
  route(ctx, 'GET', '/api/qqbot-settings/stickers', async (req, res) => {
    const u = new URL(req.url ?? '/', 'http://x');
    const layer = u.searchParams.get('layer') || undefined;
    const q = u.searchParams.get('q') || undefined;
    const untagged = u.searchParams.get('untagged') === '1';
    const includeTrash = u.searchParams.get('includeTrash') === '1';
    const store = dirOf(u, 'dataDir') ? getStickerStore(dirOf(u, 'dataDir')) : getStickerStore();
    const items = store.queryAll({ layer: layer === 'all' ? undefined : layer, q: q || undefined, untagged, includeTrash });
    writeJson(res, 200, { items, total: items.length });
  });

  // 缩略图: /api/qqbot-settings/sticker-img?id=xxx (id 由 store 内部解析路径, 不外接路径)
  route(ctx, 'GET', '/api/qqbot-settings/sticker-img', async (req, res) => {
    const u = new URL(req.url ?? '/', 'http://x');
    const id = u.searchParams.get('id') || '';
    const store = dirOf(u, 'dataDir') ? getStickerStore(dirOf(u, 'dataDir')) : getStickerStore();
    const meta = store.get(id);
    if (!meta) return writeJson(res, 404, { error: 'not found' });
    const p = store.pathOf(id);
    const buf = readFileSync(p);
    const ext = extname(p).replace('.', '').toLowerCase();
    res.writeHead(200, { 'content-type': MIME[ext] ?? 'application/octet-stream', 'cache-control': 'private, max-age=3600' });
    res.end(buf);
  });

  // 批量: {op:'promote'|'trash'|'restore'|'tag', ids:[], tags?:string[], desc?:string}
  route(ctx, 'POST', '/api/qqbot-settings/stickers/batch', async (req, res) => {
    const body = await readJsonBody(req);
    if (!body || typeof body !== 'object') return writeJson(res, 400, { error: 'bad body' });
    const store = typeof body.dataDir === 'string' && body.dataDir ? getStickerStore(body.dataDir) : getStickerStore();
    const op = body.op;
    const ids = Array.isArray(body.ids) ? body.ids.map(String) : [];
    let okN = 0;
    for (const id of ids) {
      if (op === 'promote') { if (store.promote(id)) okN += 1; }
      else if (op === 'trash') { if (store.markTrash(id)) okN += 1; }
      else if (op === 'restore') { if (store.restore(id)) okN += 1; }
      else if (op === 'tag') { if (store.setDescTags(id, Array.isArray(body.tags) ? body.tags : undefined, typeof body.desc === 'string' ? body.desc : undefined)) okN += 1; }
      else return writeJson(res, 400, { error: `unknown op ${op}` });
    }
    try { store.flush(); } catch { /* ignore */ } // 批量改完立即落盘, 防杀进程丢最后一笔
    writeJson(res, 200, { ok: okN, total: ids.length });
  });

  // 导入: {paths?: string[], urls?: string[], files?: [{name,dataBase64}]} → 逐项导入
  route(ctx, 'POST', '/api/qqbot-settings/stickers/import', async (req, res) => {
    const body = await readJsonBody(req);
    if (!body || typeof body !== 'object') return writeJson(res, 400, { error: 'bad body' });
    const store = typeof body.dataDir === 'string' && body.dataDir ? getStickerStore(body.dataDir) : getStickerStore();
    const results = [];
    const paths = Array.isArray(body.paths) ? body.paths : [];
    const urls = Array.isArray(body.urls) ? body.urls : [];
    const files = Array.isArray(body.files) ? body.files : [];
    for (const p of paths) {
      try {
        const r = store.importLocalFile(String(p));
        results.push({ ref: String(p), status: r.status, id: r.id, error: r.error });
      } catch (e) { results.push({ ref: String(p), status: 'error', error: String(e?.message ?? e) }); }
    }
    for (const url of urls) {
      try {
        const r = await store.capture(String(url), { sourceUrl: String(url) }, undefined);
        results.push({ ref: String(url), status: r.status, id: r.id, error: r.error });
      } catch (e) { results.push({ ref: String(url), status: 'error', error: String(e?.message ?? e) }); }
    }
    for (const f of files) {
      const name = String(f?.name ?? 'upload');
      const b64 = typeof f?.dataBase64 === 'string' ? f.dataBase64 : '';
      try {
        if (!b64) throw new Error('no data');
        const buf = Buffer.from(b64, 'base64');
        const tmpDir = join(store.dataDir, '.import');
        mkdirSync(tmpDir, { recursive: true });
        const tmp = join(tmpDir, `${Date.now()}-${name.replace(/[^a-zA-Z0-9._-]/g, '_')}`);
        writeFileSync(tmp, buf);
        const r = store.importLocalFile(tmp);
        try { rmSync(tmp, { force: true }); } catch { /* ignore */ }
        results.push({ ref: name, status: r.status, id: r.id, error: r.error });
      } catch (e) { results.push({ ref: name, status: 'error', error: String(e?.message ?? e) }); }
    }
    try { store.flush(); } catch { /* ignore */ } // 导入完立即落盘
    writeJson(res, 200, { results });
  });

  // ── ⑥QQ 群管理面板(P3, 2026-09-05): 多群管理 host 路由(读/写走 GroupAdminClient; 面板=主人直发免 QQ 审批) ──
  // 数据: {cwd}/.qqbot/{groups.json 群注册表, join-pending.json 待审, group-audit.jsonl 审计日志}
  // 鉴权: 与全路由一致走 route() 同源 loopback fence; 面板主人级鉴权(P4 加强)。
  function nsBot(ns) {
    const { bots } = parsePatch();
    const id = ns && ns !== 'im-qqbot' ? String(ns) : 'im-qqbot';
    const b = bots.find((x) => x.id === id);
    if (!b) return null;
    const appId = b.cfg?.appId || '';
    const appSecret = b.cfg?.appSecret || '';
    // 数据根: dataRoot(新) > `{cwd}/dshqqbot`(**2026-09-12 新默认**, 与 dist 侧 dataRootOf 对齐);
    // nsBot 的 cwd 字段按数据根返回(全为数据目录用途) —— 未配 dataRoot 的实例不再落到工作目录。
    const cwd = (b.cfg?.dataRoot || (b.cfg?.cwd ? join(b.cfg.cwd, 'dshqqbot') : ''));
    if (!appId || !appSecret) return null;
    return { id, appId, appSecret, cwd, ns: id };
  }
  async function groupClientOf(ns) {
    const bot = nsBot(ns);
    if (!bot) return null;
    const mod = await import('./dist/api/group-admin.js');
    return { bot, client: mod.createGroupAdmin({ appId: bot.appId, appSecret: bot.appSecret }) };
  }
  /** 已判定「群不存在」的 gid → 判定时刻（死群退避用，24h TTL；内存即可，重启重探一次） */
  const DEAD_GROUP_CACHE = new Map();
  /**
   * 审计日志滚动上限（2026-09-14 补）：原来是纯 append，没有上限 ——
   *   面板群列表接口每刷一次就要为**每个已死的群**写一条 group.dead（实测 9 天 4.2 万行 / 7.5MB）。
   *   这里加**大小上限**：超过 2MB 就只保留最近 2000 行，任何一类事件刷屏都挡得住。
   */
  const AUDIT_MAX_BYTES = 2 * 1024 * 1024;
  const AUDIT_KEEP_LINES = 2000;
  function audit(cwd, entry) {
    try {
      mkdirSync(join(cwd, '.qqbot'), { recursive: true });
      const af = join(cwd, '.qqbot', 'group-audit.jsonl');
      writeFileSync(af, JSON.stringify({ ts: new Date().toISOString(), ...entry }) + '\n', { flag: 'a' });
      try {
        if (statSync(af).size > AUDIT_MAX_BYTES) {
          const lines = readFileSync(af, 'utf8').split('\n').filter(Boolean);
          writeFileSync(af, lines.slice(-AUDIT_KEEP_LINES).join('\n') + '\n', 'utf8');
        }
      } catch { /* 压缩失败不影响主链 */ }
    } catch { /* ignore */ }
  }
  function readGroupsJson(cwd) {
    try { return JSON.parse(readFileSync(join(cwd, '.qqbot', 'groups.json'), 'utf8') || '{}'); } catch { return {}; }
  }
  function writeGroupsJson(cwd, g) {
    try { mkdirSync(join(cwd, '.qqbot'), { recursive: true }); writeFileSync(join(cwd, '.qqbot', 'groups.json'), JSON.stringify(g, null, 1), 'utf8'); } catch { /* ignore */ }
  }
  // 🗂 目标分组(2026-09-12 从浏览器 localStorage 搬到 host): 主人与 AI **共用同一份分组** ——
  //    dock「📇 群组管理 → 🗂 分组」编辑它, agent 侧 broadcast_send 直接按分组名群发。
  //    结构: [{ id, name, members: ['group:openid' | 'c2c:openid', ...] }] → {cwd}/.qqbot/target-groups.json
  function readTargetGroupsJson(cwd) {
    try {
      const o = JSON.parse(readFileSync(join(cwd, '.qqbot', 'target-groups.json'), 'utf8') || '{}');
      return Array.isArray(o && o.groups) ? o.groups : [];
    } catch { return []; }
  }
  function writeTargetGroupsJson(cwd, groups) {
    try { mkdirSync(join(cwd, '.qqbot'), { recursive: true }); writeFileSync(join(cwd, '.qqbot', 'target-groups.json'), JSON.stringify({ groups }, null, 1), 'utf8'); } catch { /* ignore */ }
  }
  function readPendingJson(cwd) {
    try { return JSON.parse(readFileSync(join(cwd, '.qqbot', 'join-pending.json'), 'utf8') || '{}'); } catch { return {}; }
  }
  // ── botplay 事件独立文件存储(2026-09-10 M4.3): {dataRoot}/botplay-events.json
  //    (主人定: 事件配置放工作目录根, 和「表情包」等平级; 曾放 .qqbot 子目录, 读时兼容迁移)
  function readBotplayEventsFile(cwd) {
    try {
      const root = join(cwd, 'botplay-events.json');
      if (existsSync(root)) return JSON.parse(readFileSync(root, 'utf8') || '{}');
      const legacy = join(cwd, '.qqbot', 'botplay-events.json');
      if (existsSync(legacy)) { try { renameSync(legacy, root); } catch { /* 迁移失败继续读旧 */ } return JSON.parse(readFileSync(legacy, 'utf8') || '{}'); }
      return {};
    } catch { return {}; }
  }
  function writeBotplayEventsFile(cwd, events) {
    try {
      const f = join(cwd, 'botplay-events.json');
      const tmp = f + '.tmp-' + Date.now();
      writeFileSync(tmp, JSON.stringify({ version: 1, events: Array.isArray(events) ? events : [] }, null, 2), 'utf8');
      renameSync(tmp, f);
      return true;
    } catch { return false; }
  }
  // 从 settings 现值取 botplayEvents(迁移/兜底用)
  function botplayEventsFromSettings(ns) {
    try { const v = viewOf(ctx.settings, ns); const ev = v && v.value && v.value.botplayEvents; return Array.isArray(ev) ? ev : []; } catch { return []; }
  }
  const NSQ = (u) => (u.searchParams.get('ns') || '').trim() || undefined;
  const GQ = (u) => (u.searchParams.get('gid') || '').trim();

  // ── Web 会话 → QQ 目标反查(悬浮球自动选目标用) ──
  // dsh-qqbot 的 sessionId = sha256(`qqbot:{appId}:{scope}:{peerId}`) 前 32 hex 排成 UUID。
  // 输入 web 当前会话 sessionId, 遍历所有实例的注册表群 + 台账私聊, 命中即返回归属。
  function deriveSessionIdOf(appId, scope, peerId) {
    const hash = createHash('sha256').update(`qqbot:${appId}:${scope}:${peerId}`).digest('hex');
    return `${hash.slice(0, 8)}-${hash.slice(8, 12)}-${hash.slice(12, 16)}-${hash.slice(16, 20)}-${hash.slice(20, 32)}`;
  }
  function chatLedgerNames(dataDir) {
    const out = new Map(); // key=scope:id -> {name, ts}
    try {
      const raw = readFileSync(join(dataDir, 'known-chats.jsonl'), 'utf8');
      for (const l of raw.split('\n')) {
        const t = l.trim(); if (!t) continue;
        try {
          const o = JSON.parse(t);
          if (o && typeof o.id === 'string' && (o.scope === 'group' || o.scope === 'c2c') && o.id) {
            const key = o.scope + ':' + o.id;
            const cur = out.get(key);
            if (!cur || (o.ts || 0) > cur.ts) out.set(key, { name: o.name || '', ts: o.ts || 0 });
          }
        } catch { /* 坏行 */ }
      }
    } catch { /* 无台账 */ }
    return out;
  }
  route(ctx, 'GET', '/api/qqbot-settings/session-lookup', async (req, res) => {
    try {
      const u = new URL(req.url ?? '/', 'http://x');
      const sessionId = (u.searchParams.get('sessionId') || '').trim();
      if (!sessionId) return writeJson(res, 400, { error: 'sessionId 必填' });
      const { bots } = parsePatch();
      const botByNs = new Map();
      for (const bot of bots) {
        if (bot.disabled || !bot.cfg?.appId || !bot.cfg?.cwd) continue;
        botByNs.set(bot.id, bot);
      }
      const hits = [];
      const seen = new Set();
      // 按实例台账补昵称(dataRoot/表情包/known-chats.jsonl)
      const nameOf = (ns, scope, peerId) => {
        const bot = botByNs.get(ns);
        if (!bot) return '';
        try {
          const cwd = bot.cfg.dataRoot || bot.cfg.cwd;
          const ld = chatLedgerNames(join(cwd, '表情包')).get(scope + ':' + peerId);
          return (ld && ld.name) || '';
        } catch { return '' }
      };
      const pushHit = (ns, scope, peerId, name, via) => {
        const key = ns + ':' + scope + ':' + peerId;
        if (seen.has(key)) return;
        seen.add(key);
        hits.push({ ns, scope, peerId, name, via });
      };
      // ① 权威: 真实会话记录(唯一可靠源 —— fork 后 sessionId 为 randomUUID, derive 推导会 miss)
      const sessReg = await import('./dist/features/session-registry.js');
      for (const r of sessReg.findSessionBySessionIdWeb(sessionId)) {
        pushHit(r.ns, r.scope, r.peerId, nameOf(r.ns, r.scope, r.peerId), 'session');
      }
      // ② 兜底: 确定性推导(会话记录未建立/被回收时, 从注册表+台账推导; 与权威命中自动去重)
      for (const bot of bots) {
        if (bot.disabled || !bot.cfg?.appId || !bot.cfg?.cwd) continue;
        const appId = bot.cfg.appId;
        const cwd = bot.cfg.dataRoot || bot.cfg.cwd;
        const ns = bot.id;
        const ledger = chatLedgerNames(join(cwd, '表情包'));
        const groups = readGroupsJson(cwd);
        const gids = new Set([...Object.keys(groups), ...[...ledger.keys()].filter((k) => k.startsWith('group:')).map((k) => k.slice(6))]);
        for (const gid of gids) {
          if (!gid) continue;
          if (deriveSessionIdOf(appId, 'group', gid) !== sessionId) continue;
          const regMeta = groups[gid];
          const ld = ledger.get('group:' + gid);
          pushHit(ns, 'group', gid, (regMeta && regMeta.name) || (ld && ld.name) || '', 'derive');
        }
        for (const [key2, ld] of ledger) {
          if (!key2.startsWith('c2c:')) continue;
          const openid = key2.slice(4);
          if (!openid || deriveSessionIdOf(appId, 'c2c', openid) !== sessionId) continue;
          pushHit(ns, 'c2c', openid, ld.name || '', 'derive');
        }
      }
      writeJson(res, 200, { ok: true, sessionId, hits });
    } catch (e) { writeJson(res, 500, { error: String((e && e.message) || e) }); }
  });

  // 群列表(注册表 + pending 出现过的群 + 台账群; 逐个调官方 info 校验有效性+补群名, 11255=群已注销/不存在则标记失效并过滤)
  route(ctx, 'GET', '/api/qqbot-settings/group/accounts', async (req, res) => {
    try {
      const u = new URL(req.url ?? '/', 'http://x');
      const bot = nsBot(NSQ(u));
      if (!bot) return writeJson(res, 400, { error: '找不到该账号实例(请先在账号页配置 appId/appSecret)' });
      const reg = readGroupsJson(bot.cwd);
      const pend = readPendingJson(bot.cwd);
      const map = new Map();
      for (const [gid, meta] of Object.entries(reg)) {
        if (!gid) continue;
        map.set(gid, { gid, name: (meta && meta.name) || '', from: 'registry', lastAt: (meta && meta.lastAt) || 0 });
      }
      for (const gid of Object.keys(pend)) {
        if (!gid) continue;
        if (map.has(gid)) { const m = map.get(gid); m.from = 'registry+pending'; }
        else map.set(gid, { gid, name: '', from: 'pending', lastAt: 0 });
      }
      try {
        const store = getStickerStore(bot.cwd ? join(bot.cwd, '表情包') : undefined);
        const raw = readFileSync(join(store.dataDir, 'known-chats.jsonl'), 'utf8');
        for (const l of raw.split('\n')) {
          const t = l.trim(); if (!t) continue;
          try {
            const o = JSON.parse(t);
            if (o && o.scope === 'group' && typeof o.id === 'string' && o.id) {
              if (map.has(o.id)) { if (!map.get(o.id).name && o.name) map.get(o.id).name = o.name; }
              else map.set(o.id, { gid: o.id, name: o.name || '', from: 'ledger', lastAt: typeof o.ts === 'number' ? o.ts : 0 });
            }
          } catch { /* 坏行跳过 */ }
        }
      } catch { /* 无台账 */ }
      // 逐个校验有效性 + 用官方群名补全显示名(注册表里的群也顺手回写官方名)
      const gc = await groupClientOf(NSQ(u));
      const out = [];
      const aliveReg = {};
      if (gc) {
        for (const g of [...map.values()].sort((a, b) => (b.lastAt || 0) - (a.lastAt || 0))) {
          // 死群退避（2026-09-14 补）：已判「群不存在」的 gid 24h 内不再重复校验 ——
          //   原来这里每次都全量校验，面板每刷一次就为每个死群写一条 group.dead（实测 9 天 4.2 万行）。
          //   命中缓存直接跳过（**也不写审计**），过 24h 再探一次（万一群复活/又被拉回去）。
          const deadAt = DEAD_GROUP_CACHE.get(g.gid);
          if (deadAt && Date.now() - deadAt < 24 * 3600_000) continue;
          try {
            const info = await gc.client.getGroupInfo(g.gid);
            if (info.ok && info.data) {
              const official = info.data.group_name || '';
              if (official) g.name = official;
              out.push(g);
              aliveReg[g.gid] = { name: official || (reg[g.gid] && reg[g.gid].name) || '', lastAt: (reg[g.gid] && reg[g.gid].lastAt) || Date.now() };
            } else {
              // 11255 等 = 群已注销/不存在 → 不返回给 UI(避免选中后调用报错), 仅保留审计
              DEAD_GROUP_CACHE.set(g.gid, Date.now());
              audit(bot.cwd, { ev: 'group.dead', ns: bot.id, gid: g.gid, code: info.err && info.err.code, human: info.err && info.err.human });
            }
          } catch (e2) {
            audit(bot.cwd, { ev: 'group.check-error', ns: bot.id, gid: g.gid, error: String((e2 && e2.message) || e2) });
            out.push(g); // 网络类错误不判死, 保守保留
          }
        }
        // 回写有效群注册表(自动剔除已注销群)
        if (Object.keys(aliveReg).length >= 0) writeGroupsJson(bot.cwd, aliveReg);
      } else {
        out.push(...map.values());
      }
      writeJson(res, 200, { groups: out });
    } catch (e) { writeJson(res, 500, { error: String((e && e.message) || e) }); }
  });

  // 待审入群申请(官方列表 + 本地 pending 已处理标记)
  route(ctx, 'GET', '/api/qqbot-settings/group/join_requests', async (req, res) => {
    try {
      const u = new URL(req.url ?? '/', 'http://x');
      const gid = GQ(u);
      if (!gid) return writeJson(res, 400, { error: 'gid 必填' });
      const gc = await groupClientOf(NSQ(u));
      if (!gc) return writeJson(res, 400, { error: '找不到该账号实例(请先在账号页配置 appId/appSecret)' });
      const r = await gc.client.listJoinRequests(gid);
      if (!r.ok) return writeJson(res, 200, { ok: false, err: r.err });
      const pend = readPendingJson(gc.bot.cwd);
      const local = (pend[gid] || []).map((x) => ({ member_openid: x.member_openid, join_request_id: x.join_request_id, notified: !!x.notified, seen_at: x.seen_at }));
      // 验证信息人话化: verify_info 的 method 是英文枚举(admin_review_qa), 复用 dist 的 verifyHuman 翻译
      const gaMod = await import('./dist/api/group-admin.js');
      const vh = (gaMod && typeof gaMod.verifyHuman === 'function') ? gaMod.verifyHuman : (vi) => (vi && (vi.verify_message || vi.method)) || '-';
      const list = (r.data.list || []).map((j) => ({ ...j, verify_human: vh(j.verify_info) }));
      writeJson(res, 200, { ok: true, list, local });
    } catch (e) { writeJson(res, 500, { error: String((e && e.message) || e) }); }
  });

  // ── 本地小模型(2026-09-13 主人定): 状态检测 + 一键下载 ──
  // 模型: bge-small-zh-v1.5 (ONNX q8 ≈ 23MB, 中文专训); 放用户级 {DSH_HOME|~/.dsh}/models/bge-small-zh
  // (跨工作区共享一份), 可用 localModel.modelDir 覆盖。下载走 node:https + 镜像兜底。
  const LOCAL_MODEL_FILES = ['onnx/model_quantized.onnx', 'tokenizer.json', 'tokenizer_config.json', 'config.json'];
  const LOCAL_MODEL_BASES = [
    'https://hf-mirror.com/Xenova/bge-small-zh-v1.5/resolve/main',
    'https://huggingface.co/Xenova/bge-small-zh-v1.5/resolve/main',
  ];
  function localModelDirOf(bot) {
    const cfgDir = String((bot && bot.cfg && bot.cfg.localModel && bot.cfg.localModel.modelDir) || '').trim();
    if (cfgDir) return cfgDir;
    const dshHome = (process.env.DSH_HOME && process.env.DSH_HOME.trim()) || join(homedir(), '.dsh');
    return join(dshHome, 'models', 'bge-small-zh');
  }
  /** 下载单文件(跟随重定向); 失败抛错 */
  async function downloadFile(url, dest, hops = 0) {
    const { default: https } = await import('node:https');
    return await new Promise((resolve, reject) => {
      const req = https.get(url, { headers: { 'user-agent': 'dsh-qqbot', accept: '*/*' } }, (resp) => {
        const code = resp.statusCode || 0;
        if (code >= 300 && code < 400 && resp.headers.location && hops < 6) {
          resp.resume();
          const next = new URL(resp.headers.location, url).toString();
          return downloadFile(next, dest, hops + 1).then(resolve, reject);
        }
        if (code !== 200) {
          resp.resume();
          return reject(new Error(`HTTP ${code}`));
        }
        const tmp = dest + '.part';
        const ws = createWriteStream(tmp);
        resp.pipe(ws);
        ws.on('finish', () => ws.close(() => {
          try { renameSync(tmp, dest); } catch (e) { return reject(e); }
          resolve(dest);
        }));
        ws.on('error', reject);
      });
      req.on('error', reject);
      req.setTimeout(180000, () => req.destroy(new Error('下载超时(180s)')));
    });
  }
  // ── 本地小模型：强制重置加载状态（面板「🔄 重新检测」调用）──
  // 背景：local-embed 曾有"一次失败永久关闭"的缺陷，用户点重新检测时希望能立刻再试一次。
  // ⚠️ 桥与插件在同进程：动态 import 同一份 dist 模块，拿到的就是插件正在用的那个实例表。
  route(ctx, 'POST', '/api/qqbot-settings/local-model/reset', async (req, res) => {
    try {
      const mod = await import('./dist/features/local-embed.js');
      let n = 0;
      try { n = typeof mod.resetAllEmbedders === 'function' ? mod.resetAllEmbedders() : 0; } catch (e) { n = -1; }
      return writeJson(res, 200, { ok: true, reset: n });
    } catch (e) {
      return writeJson(res, 500, { error: String((e && e.message) || e) });
    }
  });

  route(ctx, 'GET', '/api/qqbot-settings/local-model/status', async (req, res) => {
    try {
      const u = new URL(req.url ?? '/', 'http://x');
      const bot = nsBot(NSQ(u));
      const dir = localModelDirOf(bot);
      const missing = LOCAL_MODEL_FILES.filter((rel) => !existsSync(join(dir, rel)));
      let bytes = 0;
      for (const rel of LOCAL_MODEL_FILES) { try { bytes += statSync(join(dir, rel)).size; } catch { /* 缺文件不计数 */ } }
      const cfg = (bot && bot.cfg && bot.cfg.localModel) || {};
      writeJson(res, 200, {
        ok: true,
        enabled: cfg.enabled !== false,
        modelDir: dir,
        available: missing.length === 0,
        missing,
        bytes,
        // ⚠️ 2026-09-13 修(主人反馈"选了低分不唤醒, 过一会又跳回去"): 原来这里漏返回 valueGate,
        //    面板读回 undefined → 一律按默认 'log' 渲染 → 看着像"保存没生效"(其实配置里已是 block)。
        valueGate: cfg.valueGate === 'off' || cfg.valueGate === 'block' ? cfg.valueGate : 'log',
        valueMinScore: typeof cfg.valueMinScore === 'number' ? cfg.valueMinScore : 0.5,
        // 附件唤醒开关（2026-09-15）：跟 valueGate 一样**必须返回** ——
        //   否则面板读回 undefined → 勾选框永远按默认渲染，看着像"保存没生效"。
        attachmentPassthrough:
          cfg.attachmentPassthrough && typeof cfg.attachmentPassthrough === 'object'
            ? cfg.attachmentPassthrough
            : undefined,
      });
    } catch (e) { writeJson(res, 500, { ok: false, error: String((e && e.message) || e) }); }
  });
  route(ctx, 'POST', '/api/qqbot-settings/local-model/download', async (req, res) => {
    try {
      const body = await readJsonBody(req);
      const bot = nsBot(String((body && body.ns) || ''));
      const dir = localModelDirOf(bot);
      mkdirSync(join(dir, 'onnx'), { recursive: true });
      const done = [];
      for (const rel of LOCAL_MODEL_FILES) {
        const dest = join(dir, rel);
        if (existsSync(dest)) { done.push(rel + ': 已存在'); continue; }
        let lastErr = '';
        let ok = false;
        for (const base of LOCAL_MODEL_BASES) {
          try { await downloadFile(base + '/' + rel, dest); ok = true; lastErr = ''; break; }
          catch (e) { lastErr = String((e && e.message) || e); }
        }
        if (!ok) return writeJson(res, 500, { ok: false, error: `${rel} 下载失败: ${lastErr}`, done, modelDir: dir });
        done.push(rel + ': OK');
      }
      writeJson(res, 200, { ok: true, done, modelDir: dir });
    } catch (e) { writeJson(res, 500, { ok: false, error: String((e && e.message) || e) }); }
  });
  // 导出 Excel（2026-09-14 主人："好感度熟识度可以一键导出 excel 表格，i need to share"）
  //   零依赖：xlsx 由 dist/features/xlsx.js 现场拼（见那个文件头：不为了导出拖进 exceljs）
  //   三张表：熟识度 / 好感度 / 口径说明（分享给别人时看得懂）
  route(ctx, 'GET', '/api/qqbot-settings/export.xlsx', async (req, res) => {
    try {
      const u = new URL(req.url ?? '/', 'http://x');
      const bot = nsBot(NSQ(u));
      const dataRoot = (bot && bot.cfg && typeof bot.cfg.dataRoot === 'string' && bot.cfg.dataRoot) ? bot.cfg.dataRoot : ((bot && bot.cwd) || '');
      if (!dataRoot) return writeJson(res, 400, { ok: false, error: '找不到数据根目录' });
      const [{ buildXlsx }, affMod, attMod] = await Promise.all([
        import('./dist/features/xlsx.js'),
        import('./dist/features/local-signals.js'),
        import('./dist/features/attitude.js'),
      ]);
      const limit = Math.max(1, Math.min(500, Number(u.searchParams.get('limit')) || 200));
      const aff = affMod.topAffinity(dataRoot, limit) || [];
      const att = attMod.topAttitude(dataRoot, limit) || [];
      const fmt = (ts) => (ts ? new Date(ts).toLocaleString('zh-CN') : '');
      const shortId = (k) => String(k || '').replace(/^(person|group|c2c):/, '');

      const rows1 = [['#', '昵称', 'openid', '熟识度', '档位', '来过(天)', '消息数', '被点名', '接话', '最近活跃']];
      aff.forEach((x, i) => rows1.push([i + 1, x.name || '', shortId(x.key), x.score ?? '', x.tier || '', x.reviews ?? 0, x.msgs ?? 0, x.mentions ?? 0, x.replies ?? 0, fmt(x.lastAt)]));

      const rows2 = [['#', '昵称', 'openid', '好感度', '档位', '好感占比', '事件数', '最近一次涨跌原因', '最近活跃']];
      att.forEach((x, i) => {
        let tier = '';
        let ratio = '';
        try {
          const g = attMod.attitudeGateFor(dataRoot, x.key);
          tier = g.tier;
          ratio = Math.round(g.ratio * 1000) / 1000;
        } catch { /* 算不出留空 */ }
        rows2.push([i + 1, x.name || '', shortId(x.key), x.a ?? '', tier, ratio, x.events ?? 0, x.lastWhy || '', fmt(x.lastAt)]);
      });

      // 总览：两个维度**按人合并成一行**放第一张（2026-09-14 主人打开文件问"好感度呢？"——
      //   分表藏在底部标签页里容易漏看；分享场景下，一张总表最直观）
      const attByKey = new Map(att.map((x) => [x.key, x]));
      const seenKeys = new Set();
      const merged = [];
      for (const x of aff) { merged.push({ key: x.key, name: x.name, aff: x, att: attByKey.get(x.key) }); seenKeys.add(x.key); }
      for (const x of att) { if (!seenKeys.has(x.key)) merged.push({ key: x.key, name: x.name, aff: undefined, att: x }); }
      merged.sort((a, b) => (b.att?.a ?? -99) - (a.att?.a ?? -99));
      const rows0 = [['#', '昵称', 'openid', '熟识度', '熟识档位', '好感度', '好感档位', '好感占比', '来过(天)', '消息数', '被点名', '接话', '事件数', '最近一次涨跌原因', '最近活跃']];
      merged.forEach((m, i) => {
        let tier = '';
        let ratio = '';
        if (m.att) {
          try {
            const g = attMod.attitudeGateFor(dataRoot, m.key);
            tier = g.tier;
            ratio = Math.round(g.ratio * 1000) / 1000;
          } catch { /* 算不出留空 */ }
        }
        rows0.push([i + 1, m.name || '', shortId(m.key), m.aff?.score ?? '', m.aff?.tier ?? '', m.att?.a ?? '', tier, ratio,
          m.aff?.reviews ?? '', m.aff?.msgs ?? '', m.aff?.mentions ?? '', m.aff?.replies ?? '', m.att?.events ?? '', m.att?.lastWhy ?? '',
          fmt(m.att?.lastAt || m.aff?.lastAt)]);
      });

      const rows3 = [
        ['一键导出 · 口径说明', ''],        ['生成时间', new Date().toLocaleString('zh-CN')],
        ['熟识度', '她把你记得多牢 —— 客观计数 + 记忆曲线，慢变（来过几天、说了多少、被点名、接话）'],
        ['好感度', '她对你什么态度 —— 随事件可升可降（内心倾向判「亲近/拒绝/任务」+ 正文情绪判「暖/冷/中性」）'],
        ['“最近一次涨跌原因”', '形如「内心亲近 +0.5」「内心拒绝 −0.5 / 又烦又冷(重罚) −0.5」「两好相凑 ×1.2」'],
        ['判定把握', '本地小模型对不上号时会**弃权**（不给标签、不动分），所以有些格子是空的'],
        ['红线', '负好感只退礼貌档：少主动，绝不冷落、阴阳、攻击'],
        ['来源', 'dsh-qqbot 插件 · 数据文件 .qqbot/affinity.json 与 attitude.json'],
      ];

      const buf = buildXlsx([
        { name: '总览', rows: rows0, widths: [5, 18, 34, 9, 10, 9, 10, 10, 9, 9, 9, 8, 9, 44, 20] },
        { name: '熟识度', rows: rows1, widths: [5, 18, 34, 10, 10, 10, 9, 9, 8, 20] },
        { name: '好感度', rows: rows2, widths: [5, 18, 34, 10, 10, 11, 9, 44, 20] },
        { name: '说明', rows: rows3, widths: [20, 90] },
      ]);
      const when = new Date();
      const p2 = (n) => String(n).padStart(2, '0');
      const cn = `熟识度好感度_${when.getFullYear()}${p2(when.getMonth() + 1)}${p2(when.getDate())}_${p2(when.getHours())}${p2(when.getMinutes())}.xlsx`;
      res.writeHead(200, {
        'content-type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'content-disposition': `attachment; filename="qqbot-stats.xlsx"; filename*=UTF-8''${encodeURIComponent(cn)}`,
        'content-length': String(buf.length),
        'cache-control': 'no-store',
      });
      res.end(buf);
      audit(dataRoot, { ev: 'export.xlsx', ns: bot && bot.id, rows: aff.length + att.length });
    } catch (e) { writeJson(res, 500, { ok: false, error: String((e && e.message) || e) }); }
  });

  // 好感度台账(2026-09-13 主人定, 观察期): 只读, 供面板显示"谁跟她最熟"
  //   数据源: {dataRoot}/.qqbot/affinity.json (每条群消息累计 互动/被点名/接话; 熟度现算, 公式透明)
  route(ctx, 'GET', '/api/qqbot-settings/affinity', async (req, res) => {
    try {
      const u = new URL(req.url ?? '/', 'http://x');
      const bot = nsBot(NSQ(u));
      const dataRoot = (bot && bot.cfg && typeof bot.cfg.dataRoot === 'string' && bot.cfg.dataRoot) ? bot.cfg.dataRoot : ((bot && bot.cwd) || '');
      if (!dataRoot) return writeJson(res, 200, { ok: true, items: [] });
      const mod = await import('./dist/features/local-signals.js');
      const limit = Math.max(1, Math.min(50, Math.round(Number(u.searchParams.get('limit'))) || 8));
      const items = (mod.topAffinity(dataRoot, limit) || []).map((x) => ({
        key: x.key, name: x.name || '', score: x.score, tier: x.tier || '', reviews: x.reviews || 0, msgs: x.msgs, mentions: x.mentions, replies: x.replies, lastAt: x.lastAt,
      }));
      writeJson(res, 200, { ok: true, items });
    } catch (e) { writeJson(res, 500, { ok: false, error: String((e && e.message) || e) }); }
  });

  // 好感度(2026-09-14 主人"直接推进"): A 值台账 —— 与「熟识度」是**两个维度**, 面板分两列
  //   熟识度 = 她把他记多牢(客观计数+记忆曲线, 慢变) ｜ 好感度 = 她对他什么态度(随事件可升可降)
  //   数据源: {dataRoot}/.qqbot/attitude.json (内心倾向 + 正文情绪 → Δ → A 值, 见 features/attitude.ts)
  route(ctx, 'GET', '/api/qqbot-settings/attitude', async (req, res) => {
    try {
      const u = new URL(req.url ?? '/', 'http://x');
      const bot = nsBot(NSQ(u));
      const dataRoot = (bot && bot.cfg && typeof bot.cfg.dataRoot === 'string' && bot.cfg.dataRoot) ? bot.cfg.dataRoot : ((bot && bot.cwd) || '');
      if (!dataRoot) return writeJson(res, 200, { ok: true, items: [] });
      const mod = await import('./dist/features/attitude.js');
      // ⚠️ 2026-09-15 修(主人反馈"小明不是有好感度吗, 怎么显示 0/—"):
      //   面板那张熟识度表是**按 key 左连接**好感度的(top N 只够"排行榜", 不够"连接") ——
      //   原来默认 limit=8, 排第 9 的人(小明 a=0.064 但 events=128)就 join 不到 → 显示 "—"。
      //   all=1 = 要全量(连接用); 默认仍是 top N 排行语义, 不破坏别处调用。
      const wantAll = u.searchParams.get('all') === '1';
      const limit = wantAll ? 100000 : Math.max(1, Math.min(50, Math.round(Number(u.searchParams.get('limit'))) || 8));
      const items = (mod.topAttitude(dataRoot, limit) || []).map((x) => {
        // 档位名（面板显示用，2026-09-14 主人要求）：按"好感度占其范围的比例"分 很亲近/亲近/中立/冷淡/疏远
        let tier = '';
        let ratio = 0;
        try {
          const g = mod.attitudeGateFor(dataRoot, x.key);
          if (g) { tier = g.tier; ratio = Math.round(g.ratio * 1000) / 1000; }
        } catch { /* 算不出就不显示档位 */ }
        return {
          key: x.key, name: x.name || '', a: x.a, events: x.events || 0, lastAt: x.lastAt || 0, why: x.lastWhy || '', codes: x.lastCodes || [], tier, ratio,
        };
      });
      writeJson(res, 200, { ok: true, items });
    } catch (e) { writeJson(res, 500, { ok: false, error: String((e && e.message) || e) }); }
  });

  // 价值样例库读写(2026-09-13 主人定): {dataRoot}/.qqbot/value-samples.jsonl —— 用户可直接编辑
  function valueSamplesPathOf(bot) {
    const dataRoot = (bot && bot.cfg && typeof bot.cfg.dataRoot === 'string' && bot.cfg.dataRoot)
      ? bot.cfg.dataRoot
      : ((bot && bot.cwd) || '');
    return dataRoot ? join(dataRoot, '.qqbot', 'value-samples.jsonl') : '';
  }
  route(ctx, 'GET', '/api/qqbot-settings/value-samples', async (req, res) => {
    try {
      const u = new URL(req.url ?? '/', 'http://x');
      const p = valueSamplesPathOf(nsBot(NSQ(u)));
      if (!p) return writeJson(res, 400, { ok: false, error: '找不到数据目录' });
      const exists = existsSync(p);
      const text = exists ? readFileSync(p, 'utf8') : '';
      const lines = text.split('\n').filter((l) => l.trim());
      let pos = 0;
      let neg = 0;
      let bad = 0;
      for (const l of lines) {
        try { const o = JSON.parse(l); if (o.y === 1) pos += 1; else neg += 1; } catch { bad += 1; }
      }
      writeJson(res, 200, { ok: true, text, total: lines.length, pos, neg, bad, isDefault: !exists, path: p });
    } catch (e) { writeJson(res, 500, { ok: false, error: String((e && e.message) || e) }); }
  });
  route(ctx, 'POST', '/api/qqbot-settings/value-samples', async (req, res) => {
    try {
      const body = await readJsonBody(req);
      const p = valueSamplesPathOf(nsBot(String((body && body.ns) || '')));
      if (!p) return writeJson(res, 400, { ok: false, error: '找不到数据目录' });
      const lines = String((body && body.text) || '').split('\n').filter((l) => l.trim());
      const bad = [];
      const clean = [];
      lines.forEach((l, i) => {
        try {
          const o = JSON.parse(l);
          const m = String(o && o.m ? o.m : '').trim();
          if (!m) throw new Error('缺 m 字段');
          clean.push(JSON.stringify({ m, y: o.y === 1 ? 1 : 0, src: typeof o.src === 'string' ? o.src : 'manual' }));
        } catch (e) { bad.push(`第${i + 1}行 ${String((e && e.message) || e)}`); }
      });
      if (bad.length) return writeJson(res, 400, { ok: false, error: `有 ${bad.length} 行格式不对 → ${bad.slice(0, 3).join('; ')}` });
      mkdirSync(dirname(p), { recursive: true });
      writeFileSync(p, clean.join('\n') + (clean.length ? '\n' : ''), 'utf8');
      const pos = clean.filter((l) => JSON.parse(l).y === 1).length;
      writeJson(res, 200, { ok: true, saved: clean.length, pos, neg: clean.length - pos, path: p });
    } catch (e) { writeJson(res, 500, { ok: false, error: String((e && e.message) || e) }); }
  });
  // 「让ai写」(2026-09-13 主人要的): 模拟一条用户消息唤醒她(照抄定时任务的做法: 伪造 msg → handleInbound)
  route(ctx, 'POST', '/api/qqbot-settings/value-samples/let-ai-write', async (req, res) => {
    try {
      const body = await readJsonBody(req);
      const ns = String((body && body.ns) || '');
      const mod = await import('@zaofan/dsh-qqbot/channel-tools');
      if (typeof mod.askAiToWriteSamples !== 'function') {
        return writeJson(res, 500, { ok: false, error: '线上插件还是旧版本(需重启宿主加载新代码)' });
      }
      const scope = String((body && body.scope) || 'group') === 'c2c' ? 'c2c' : 'group';
      let peerId = String((body && body.peerId) || '');
      if (!peerId) {
        // 兜底(免得非要先选目标): 从最近评分记录里取最近活跃的群
        try {
          const b2 = nsBot(ns);
          const dr = (b2 && b2.cfg && typeof b2.cfg.dataRoot === 'string' && b2.cfg.dataRoot) ? b2.cfg.dataRoot : ((b2 && b2.cwd) || '');
          const pf = dr ? join(dr, '.qqbot', 'value-scores.jsonl') : '';
          if (pf && existsSync(pf)) {
            const rows = readFileSync(pf, 'utf8').split('\n').filter((l) => l.trim());
            for (let i = rows.length - 1; i >= 0; i--) {
              try { const o = JSON.parse(rows[i]); if (o && o.gid) { peerId = String(o.gid); break; } } catch { /* 坏行跳过 */ }
            }
          }
        } catch { /* 兜底失败就按"没有目标"返回 */ }
      }
      const r = await mod.askAiToWriteSamples(ns, scope, peerId);
      writeJson(res, 200, r);
    } catch (e) { writeJson(res, 500, { ok: false, error: String((e && e.message) || e) }); }
  });

  // 价值评分记录(观察期): {dataRoot}/.qqbot/value-scores.jsonl 尾 N 条
  // gid= 时**只给该群的记录**(2026-09-13 主人要求: 评分要跟随面板"当前会话"命中的群, 与群管理页一致)
  route(ctx, 'GET', '/api/qqbot-settings/value-scores', async (req, res) => {
    try {
      const u = new URL(req.url ?? '/', 'http://x');
      const bot = nsBot(NSQ(u));
      const gid = (u.searchParams.get('gid') || '').trim();
      const limit = Math.max(1, Math.min(100, Number(u.searchParams.get('limit')) || 20));
      const dataRoot = (bot && bot.cfg && typeof bot.cfg.dataRoot === 'string' && bot.cfg.dataRoot)
        ? bot.cfg.dataRoot
        : ((bot && bot.cwd) || '');
      const p = dataRoot ? join(dataRoot, '.qqbot', 'value-scores.jsonl') : '';
      if (!p || !existsSync(p)) return writeJson(res, 200, { ok: true, items: [], total: 0, totalAll: 0, gid });
      let lines = readFileSync(p, 'utf8').split('\n').filter((l) => l.trim());
      const totalAll = lines.length;
      if (gid) {
        lines = lines.filter((l) => {
          try { return String(JSON.parse(l).gid || '') === gid; } catch { return false; }
        });
      }
      const items = lines.slice(-limit).map((l) => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
      writeJson(res, 200, { ok: true, items, total: lines.length, totalAll, gid });
    } catch (e) { writeJson(res, 500, { ok: false, error: String((e && e.message) || e) }); }
  });

  // 本地成员清单(官方成员列表未开放 → 用机器人见过的发言者兜底; 供禁言"选人"与成员 Tab 展示)
  route(ctx, 'GET', '/api/qqbot-settings/group/members_local', async (req, res) => {
    try {
      const u = new URL(req.url ?? '/', 'http://x');
      const gid = GQ(u);
      const bot = nsBot(NSQ(u));
      if (!bot) return writeJson(res, 400, { error: '找不到该账号实例(请先在账号页配置 appId/appSecret)' });
      const store = getStickerStore(bot.cwd ? join(bot.cwd, '表情包') : undefined);
      // 与台账同 dataDir 的 group-members.jsonl
      const mod = await import('./dist/features/chat-ledger.js');
      const members = mod.readGroupMembers(store.dataDir, gid || undefined);
      writeJson(res, 200, { ok: true, members });
    } catch (e) { writeJson(res, 500, { error: String((e && e.message) || e) }); }
  });

  // 手动审批入群 {ns?, gid, member_openid, op:approve|decline, reason?}
  route(ctx, 'POST', '/api/qqbot-settings/group/approve', async (req, res) => {
    const body = await readJsonBody(req);
    if (!body || typeof body !== 'object') return writeJson(res, 400, { error: 'bad body' });
    const gid = String(body.gid || '');
    const mid = String(body.member_openid || '');
    const op = String(body.op || '');
    if (!gid || !mid || (op !== 'approve' && op !== 'decline')) return writeJson(res, 400, { error: 'gid/member_openid/op(approve|decline) 必填' });
    try {
      const gc = await groupClientOf(String(body.ns || ''));
      if (!gc) return writeJson(res, 400, { error: '找不到该账号实例(请先在账号页配置 appId/appSecret)' });
      const listR = await gc.client.listJoinRequests(gid);
      const found = listR.ok ? (listR.data.list || []).find((x) => x.member_openid === mid) : undefined;
      const r = await gc.client.approveJoinRequest(gid, mid, op, {
        ...(found ? { join_request_id: found.join_request_id } : {}),
        ...(op === 'decline' && String(body.reason || '') ? { reject_reason: String(body.reason) } : {}),
      });
      audit(gc.bot.cwd, { ev: 'group.approve', ns: gc.bot.id, gid, member_openid: mid, op, reason: String(body.reason || ''), ok: r.ok, code: r.ok ? undefined : (r.err && r.err.code) });
      writeJson(res, r.ok ? 200 : 200, r.ok ? { ok: true, msg: op === 'approve' ? '已放行' : '已拒绝' } : { ok: false, err: r.err });
    } catch (e) { writeJson(res, 500, { error: String((e && e.message) || e) }); }
  });

  // 禁言状态 {ns?, gid}
  route(ctx, 'GET', '/api/qqbot-settings/group/mute_state', async (req, res) => {
    try {
      const u = new URL(req.url ?? '/', 'http://x');
      const gid = GQ(u);
      if (!gid) return writeJson(res, 400, { error: 'gid 必填' });
      const gc = await groupClientOf(NSQ(u));
      if (!gc) return writeJson(res, 400, { error: '找不到该账号实例(请先在账号页配置 appId/appSecret)' });
      const r = await gc.client.getMuteState(gid);
      writeJson(res, 200, r.ok ? { ok: true, data: r.data } : { ok: false, err: r.err });
    } catch (e) { writeJson(res, 500, { error: String((e && e.message) || e) }); }
  });

  // 手动禁言/解禁 {ns?, gid, member_openid, action:mute|unmute, seconds?}
  route(ctx, 'POST', '/api/qqbot-settings/group/mute', async (req, res) => {
    const body = await readJsonBody(req);
    if (!body || typeof body !== 'object') return writeJson(res, 400, { error: 'bad body' });
    const gid = String(body.gid || '');
    const mid = String(body.member_openid || '');
    const action = String(body.action || '');
    if (!gid || !mid || (action !== 'mute' && action !== 'unmute')) return writeJson(res, 400, { error: 'gid/member_openid/action(mute|unmute) 必填' });
    try {
      const gc = await groupClientOf(String(body.ns || ''));
      if (!gc) return writeJson(res, 400, { error: '找不到该账号实例(请先在账号页配置 appId/appSecret)' });
      const secs = action === 'mute' ? Math.max(1, Math.min(30 * 86400, Math.round(Number(body.seconds || 600)))) : 0;
      const p2 = (n) => String(n).padStart(2, '0');
      const expire = action === 'mute' ? new Date(Date.now() + secs * 1000) : null;
      const rfc = expire ? expire.getFullYear() + '-' + p2(expire.getMonth() + 1) + '-' + p2(expire.getDate()) + 'T' + p2(expire.getHours()) + ':' + p2(expire.getMinutes()) + ':' + p2(expire.getSeconds()) + '+08:00' : null;
      const r = await gc.client.setMemberMute(gid, mid, rfc);
      audit(gc.bot.cwd, { ev: 'group.mute', ns: gc.bot.id, gid, member_openid: mid, action, seconds: secs, ok: r.ok, code: r.ok ? undefined : (r.err && r.err.code) });
      // ⚠️ 官方对"禁言已退群成员"静默返回成功但不生效(实测 HTTP 200 空体, 状态列表无此人)
      // → 禁言后回读 restrict_chat_setting 验证: 目标不在成员列表 = 已不在群/无法禁言 → 人话提示 + 自动剔除本地名单
      if (r.ok && action === 'mute') {
        try {
          const st = await gc.client.getMuteState(gid);
          const stMembers = (st.ok && st.data && Array.isArray(st.data.members) ? st.data.members : []) || [];
          const present = stMembers.some((m) => m.member_openid === mid);
          if (!present) {
            const store = getStickerStore(gc.bot.cwd ? join(gc.bot.cwd, '表情包') : undefined);
            const ledgerMod = await import('./dist/features/chat-ledger.js');
            ledgerMod.removeGroupMember(store.dataDir, gid, mid);
            audit(gc.bot.cwd, { ev: 'group.member-auto-remove', ns: gc.bot.id, gid, member_openid: mid, reason: '禁言无效(成员已不在群)' });
            return writeJson(res, 200, { ok: false, err: { code: 'MEMBER_NOT_IN_GROUP', human: '该成员已不在群(可能已退群)——已自动从本地成员清单剔除' } });
          }
        } catch (e2) { /* 回读失败不阻断, 按成功返回 */ }
      }
      writeJson(res, r.ok ? 200 : 200, r.ok ? { ok: true, msg: action === 'mute' ? '已禁言 ' + Math.round(secs / 60) + ' 分钟' : '已解除禁言' } : { ok: false, err: r.err });
    } catch (e) { writeJson(res, 500, { error: String((e && e.message) || e) }); }
  });

  // 面板代发消息: 以机器人身份向群发文本 {ns?, gid, text, insertContext?}
  // insertContext=true → 发完后往该 QQ 会话 append 一条 user/message(模拟用户消息, 内容以
  // 「用户代你发送: 」开头, web 流可见、不唤醒、不开回合——与入群申请通知同款姿势)。
  // 该文本只进 web 流, QQ 群里收到的是干净原文。
  route(ctx, 'POST', '/api/qqbot-settings/group/send', async (req, res) => {
    const body = await readJsonBody(req);
    if (!body || typeof body !== 'object') return writeJson(res, 400, { error: 'bad body' });
    const gid = String(body.gid || '').trim();
    const text = String(body.text || '').trim();
    if (!gid || !text) return writeJson(res, 400, { error: 'gid 与 text 必填' });
    if (text.length > 2000) return writeJson(res, 400, { error: '文本过长(最多 2000 字符)' });
    try {
      const gc = await groupClientOf(String(body.ns || ''));
      if (!gc) return writeJson(res, 400, { error: '找不到该账号实例(请先在账号页配置 appId/appSecret)' });
      const r = await gc.client.sendGroupText(gid, text);
      audit(gc.bot.cwd, { ev: 'group.send', ns: gc.bot.id, gid, text: text.slice(0, 120), ok: r.ok, code: r.ok ? undefined : (r.err && r.err.code) });
      let ctxNote = '';
      if (r.ok && body.insertContext === true) {
        const why = await appendUserRelayToPeer(String(body.ns || 'im-qqbot'), 'group', gid, text).catch((e) => { audit(gc.bot.cwd, { ev: 'group.send.insertContext-failed', ns: gc.bot.id, error: String((e && e.message) || e) }); return 'failed'; });
        if (why) audit(gc.bot.cwd, { ev: 'group.send.insertContext-skipped', ns: gc.bot.id, gid, reason: why });
        ctxNote = why ? '(' + (WHY_MAP[why] || why) + ')' : '(已写入上下文: 用户代你发送)';
      }
      writeJson(res, r.ok ? 200 : 200, r.ok ? { ok: true, msg: '已发送 ✓ ' + ctxNote } : { ok: false, err: r.err });
    } catch (e) { writeJson(res, 500, { error: String((e && e.message) || e) }); }
  });

  // 面板代发私聊: 以机器人身份向用户发文本 {ns?, openid, text, insertContext?}(悬浮球 dock 发消息用)
  route(ctx, 'POST', '/api/qqbot-settings/chat/send', async (req, res) => {
    const body = await readJsonBody(req);
    if (!body || typeof body !== 'object') return writeJson(res, 400, { error: 'bad body' });
    const openid = String(body.openid || '').trim();
    const text = String(body.text || '').trim();
    if (!openid || !text) return writeJson(res, 400, { error: 'openid 与 text 必填' });
    if (text.length > 2000) return writeJson(res, 400, { error: '文本过长(最多 2000 字符)' });
    try {
      const gc = await groupClientOf(String(body.ns || ''));
      if (!gc) return writeJson(res, 400, { error: '找不到该账号实例(请先在账号页配置 appId/appSecret)' });
      const r = await gc.client.sendC2cText(openid, text);
      audit(gc.bot.cwd, { ev: 'chat.send', ns: gc.bot.id, openid, text: text.slice(0, 120), ok: r.ok, code: r.ok ? undefined : (r.err && r.err.code) });
      let ctxNote = '';
      if (r.ok && body.insertContext === true) {
        const why = await appendUserRelayToPeer(String(body.ns || 'im-qqbot'), 'c2c', openid, text).catch((e) => { audit(gc.bot.cwd, { ev: 'chat.send.insertContext-failed', ns: gc.bot.id, error: String((e && e.message) || e) }); return 'failed'; });
        if (why) audit(gc.bot.cwd, { ev: 'chat.send.insertContext-skipped', ns: gc.bot.id, openid, reason: why });
        ctxNote = why ? '(' + (WHY_MAP[why] || why) + ')' : '(已写入上下文: 用户代你发送)';
      }
      writeJson(res, r.ok ? 200 : 200, r.ok ? { ok: true, msg: '已发送 ✓ ' + ctxNote } : { ok: false, err: r.err });
    } catch (e) { writeJson(res, 500, { error: String((e && e.message) || e) }); }
  });

  // ── 自定义卡片按钮(2026-09-10 主人要求: 卡片按钮要能写「回文本 / 跳链接 / 执行命令」) ──
  // client 传结构化 cardButtons=[{label, action:'text'|'cmd'|'url', payload}]。
  // 这里生成 cardId、把按钮动作写进 {dataRoot}/.qqbot/card-callbacks.json —— 格式与 dist 侧
  // src/features/card-callback.ts 严格一致(改格式两边都要改); 按钮 data 编 `bpk:<cardId>:<btnId>`:
  //   action=url  → action.type=0 官方跳转(客户端直接跳, 不走回调)
  //   其余        → action.type=1 回调 → 点击后 QQ 推 INTERACTION_CREATE → bootstrap 的
  //                 cardCallbackController 查表执行(text 回文本 / cmd 走命令执行器)
  function writeCardCallbacks(dataRoot, card) {
    try {
      const p = join(dataRoot, '.qqbot', 'card-callbacks.json');
      mkdirSync(dirname(p), { recursive: true });
      let f = { version: 1, cards: [] };
      try { if (existsSync(p)) f = JSON.parse(readFileSync(p, 'utf8')) || f; } catch { f = { version: 1, cards: [] }; }
      const now = Date.now();
      const kept = (Array.isArray(f.cards) ? f.cards : []).filter(c => c && c.cardId !== card.cardId && (c.expireAt || 0) > now);
      kept.push(card);
      writeFileSync(p, JSON.stringify({ version: 1, cards: kept.slice(-200) }, null, 1), 'utf8');
    } catch { /* 写失败只影响按钮回调, 不阻断发卡 */ }
  }
  function buildCardKeyboardFromPairs(dataRoot, pairs, meta) {
    const list = (Array.isArray(pairs) ? pairs : []).filter(b => b && b.label).slice(0, 25);
    if (!list.length) return undefined;
    const cardId = 'c' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
    const buttons = list.map((b, i) => ({
      id: 'b' + (i + 1),
      label: String(b.label).slice(0, 20),
      action: b.action === 'url' ? 'url' : (b.action === 'cmd' ? 'cmd' : 'text'),
      payload: String(b.payload == null ? '' : b.payload),
    }));
    const rows = buttons.map(b => ({
      buttons: [{
        id: b.id,
        render_data: { label: b.label, style: 1 },
        action: {
          type: b.action === 'url' ? 0 : 1, // 0=跳转 1=回调
          permission: { type: 2 },
          data: 'bpk:' + cardId + ':' + b.id,
          unsupport_tips: '请在支持的客户端点击',
        },
      }],
    }));
    writeCardCallbacks(dataRoot, {
      cardId,
      buttons,
      createdAt: Date.now(),
      expireAt: Date.now() + 7 * 24 * 3600 * 1000,
      scope: meta && meta.scope,
      targetId: meta && meta.targetId,
    });
    return { content: { rows } };
  }

  // ── 自定义 markdown 卡片发送(2026-09-10 主人实测: markdown 嵌网络图+按钮可渲染):
  //     接收 {ns?, gid | openid, markdown, keyboard?} → 群用 sendGroupCard / 私聊用 sendC2cCard;
  //     群发走 broadcast/create(type=markdown)。openid 支持为 2026-09-10 主人要求(卡片可选私聊目标)。
  route(ctx, 'POST', '/api/qqbot-settings/chat/send-card', async (req, res) => {
    const body = await readJsonBody(req);
    if (!body || typeof body !== 'object') return writeJson(res, 400, { error: 'bad body' });
    const gid = String(body.gid || '').trim();
    const openid = String(body.openid || '').trim();
    const md = String(body.markdown || '').trim();
    if (!gid && !openid) return writeJson(res, 400, { error: 'gid 或 openid 必填' });
    if (!md) return writeJson(res, 400, { error: 'markdown 必填' });
    if (md.length > 8000) return writeJson(res, 400, { error: 'markdown 过长(最多 8000 字符)' });
    try {
      const gc = await groupClientOf(String(body.ns || ''));
      if (!gc) return writeJson(res, 400, { error: '找不到该账号实例' });
      // 结构化按钮(新路径) → 生成回调表 + bpk: 键盘; 也兼容旧路径直接给 keyboard
      let kb = body.keyboard && body.keyboard.content && Array.isArray(body.keyboard.content.rows) ? body.keyboard : undefined;
      if (!kb && Array.isArray(body.cardButtons) && body.cardButtons.length) {
        kb = buildCardKeyboardFromPairs(gc.bot.cwd, body.cardButtons, { scope: openid ? 'c2c' : 'group', targetId: openid || gid });
      }
      const r = openid
        ? await gc.client.sendC2cCard(openid, md, kb)
        : await gc.client.sendGroupCard(gid, md, kb);
      audit(gc.bot.cwd, { ev: 'chat.send-card', ns: gc.bot.id, gid, openid, mdLen: md.length, kbRows: kb ? kb.content.rows.length : 0, cbButtons: Array.isArray(body.cardButtons) ? body.cardButtons.length : 0, ok: r.ok, code: r.ok ? undefined : (r.err && r.err.code) });
      writeJson(res, 200, r.ok
        ? { ok: true, msg: '✅ 卡片已发送' + (openid ? '(私聊)' : '(群)'), id: r.data && r.data.id }
        : { ok: false, err: r.err });
    } catch (e) { writeJson(res, 500, { error: String((e && e.message) || e) }); }
  });

  // ── botplay 事件独立文件存储(M4.3): GET 读 / POST 写, 均按 ns 取 dataRoot ──
  // ⚠️ 2026-09-10 修复: NSQ 参数是 URL 对象(内部调 u.searchParams.get), 原写法 NSQ(req.url)
  //    传了字符串 → "Cannot read properties of undefined (reading 'get')" 500。
  route(ctx, 'GET', '/api/qqbot-settings/group/botplay-events', async (req, res) => {
    const ns = NSQ(new URL(req.url ?? '/', 'http://x'));
    const bot = nsBot(ns);
    if (!bot || !bot.cwd) return writeJson(res, 400, { error: '找不到该账号实例' });
    const fromFile = readBotplayEventsFile(bot.cwd);
    let events = Array.isArray(fromFile.events) ? fromFile.events : (Array.isArray(fromFile) ? fromFile : []);
    // 文件缺失/空 → 迁移 settings 旧数据(botplay 事件曾存 settings.yaml, 2026-09-10 前)
    if (events.length === 0) {
      const legacy = botplayEventsFromSettings(bot.ns);
      if (Array.isArray(legacy) && legacy.length > 0) { writeBotplayEventsFile(bot.cwd, legacy); events = legacy; }
    }
    writeJson(res, 200, { ok: true, events, source: 'file' });
  });

  route(ctx, 'POST', '/api/qqbot-settings/group/botplay-events', async (req, res) => {
    const body = await readJsonBody(req);
    if (!body || typeof body !== 'object') return writeJson(res, 400, { error: 'bad body' });
    const ns = String(body.ns || 'im-qqbot').trim();
    const bot = nsBot(ns);
    if (!bot || !bot.cwd) return writeJson(res, 400, { error: '找不到该账号实例' });
    if (!Array.isArray(body.events)) return writeJson(res, 400, { error: 'events 必须为数组' });
    const okFile = writeBotplayEventsFile(bot.cwd, body.events);
    // settings 现值同步清空(2026-09-10: 事件已独立文件, settings 里残留旧数组会与新文件重复/歧义 → 置空)
    let okSettings = true;
    try {
      const cur = viewOf(ctx.settings, bot.ns);
      const curVal = (cur && cur.value) || {};
      if (curVal.botplayEvents !== undefined && Array.isArray(curVal.botplayEvents) && curVal.botplayEvents.length > 0) {
        const patch = Object.assign({}, curVal, { botplayEvents: [] });
        await ctx.settings.update(bot.ns, patch, (cur && cur.revision) || undefined);
      }
    } catch { okSettings = false; }
    audit(bot.cwd, { ev: 'botplay.events-save', ns: bot.ns, n: body.events.length, okFile, okSettings });
    writeJson(res, 200, { ok: okFile, msg: okFile ? '✅ 已保存(独立文件, live 热更已生效)' : '写入文件失败' });
  });

  // ── M3 群发任务队列(2026-09-10): 持久化状态机 draft→queued→sending→done, 二次确认, 可中止/撤回 ──
  // 数据: {dataRoot}/.qqbot/broadcast-tasks.json(broadcast.ts 管理); 推进由每次 list 请求驱动(串行, 天然限频)。
  // 路由: broadcast/create(草稿) → broadcast/confirm(二次确认后入队) → broadcast/list(推进+展示) →
  //       broadcast/cancel(中止) → broadcast/recall(撤回某目标已发消息)。
  async function broadcastMod() {
    return import('./dist/features/broadcast.js');
  }

  // 创建群发草稿 {ns?, type:'text'|'markdown', text, targets:[{scope,peerId,name?}]}
  route(ctx, 'POST', '/api/qqbot-settings/group/broadcast/create', async (req, res) => {
    const body = await readJsonBody(req);
    if (!body || typeof body !== 'object') return writeJson(res, 400, { error: 'bad body' });
    const text = String(body.text || '').trim();
    const targets = Array.isArray(body.targets) ? body.targets : [];
    // 卡片群发(2026-09-10 主人要求): type=card 时 text 为 markdown 正文, 另带 keyboard
    const wantCard = body.type === 'card';
    if (!text) return writeJson(res, 400, { error: wantCard ? 'markdown 必填' : 'text 必填' });
    if (text.length > (wantCard ? 8000 : 2000)) return writeJson(res, 400, { error: wantCard ? 'markdown 过长(最多 8000 字符)' : '文本过长(最多 2000 字符)' });
    // 卡片群发(2026-09-10 主人要求): type=card 时 text 为 markdown 正文, 另带 keyboard;
    // 优先用结构化 cardButtons 现生成(回调表+bpk: 键盘, 与 chat/send-card 同一套), 兼容直接给 keyboard
    let kb = wantCard && body.keyboard && body.keyboard.content && Array.isArray(body.keyboard.content.rows) ? body.keyboard : undefined;
    if (targets.length === 0) return writeJson(res, 400, { error: 'targets 至少一个(勾选群/私聊)' });
    if (targets.length > 200) return writeJson(res, 400, { error: '目标太多(最多 200)' });
    for (const t of targets) {
      if (!t || (t.scope !== 'group' && t.scope !== 'c2c') || !t.peerId) return writeJson(res, 400, { error: 'targets 每项需 scope(group|c2c)+peerId' });
    }
    try {
      const bot = nsBot(String(body.ns || ''));
      if (!bot) return writeJson(res, 400, { error: '找不到该账号实例(请先在账号页配置 appId/appSecret)' });
      // 结构化按钮 → 现生成回调表 + bpk: 键盘(与 chat/send-card 同一套; 群发各目标共用这张表)
      if (wantCard && !kb && Array.isArray(body.cardButtons) && body.cardButtons.length) {
        kb = buildCardKeyboardFromPairs(bot.cwd, body.cardButtons, { scope: 'group', targetId: '' });
      }
      const bm = await broadcastMod();
      const task = bm.createTask(bot.cwd, {
        type: wantCard ? 'card' : (body.type === 'markdown' ? 'markdown' : 'text'),
        content: text,
        keyboard: kb,
        targets: targets.map((t) => ({ scope: t.scope, peerId: t.peerId, name: t.name ? String(t.name) : undefined })),
        created_by: 'dock',
      });
      audit(bot.cwd, { ev: 'group.broadcast.create', ns: bot.id, task_id: task.task_id, targets: targets.length, type: wantCard ? 'card' : 'text' });
      writeJson(res, 200, { ok: true, task });
    } catch (e) { writeJson(res, 500, { error: String((e && e.message) || e) }); }
  });

  // 确认群发(二次确认后调用) {ns?, task_id}
  route(ctx, 'POST', '/api/qqbot-settings/group/broadcast/confirm', async (req, res) => {
    const body = await readJsonBody(req);
    if (!body || typeof body !== 'object') return writeJson(res, 400, { error: 'bad body' });
    const taskId = String(body.task_id || '');
    if (!taskId) return writeJson(res, 400, { error: 'task_id 必填' });
    try {
      const bot = nsBot(String(body.ns || ''));
      if (!bot) return writeJson(res, 400, { error: '找不到该账号实例' });
      const bm = await broadcastMod();
      const t = bm.confirmTask(bot.cwd, taskId);
      if (!t) return writeJson(res, 400, { error: '任务不存在' });
      if (t.state !== 'queued') return writeJson(res, 200, { ok: false, msg: `任务状态为 ${t.state}, 无法确认` });
      audit(bot.cwd, { ev: 'group.broadcast.confirm', ns: bot.id, task_id: taskId });
      writeJson(res, 200, { ok: true, task: t });
    } catch (e) { writeJson(res, 500, { error: String((e && e.message) || e) }); }
  });

  // 🗂 目标分组读写(2026-09-12): GET=读(供 client 加载/迁移), POST=整体写回(供 client 保存)。
  // 同 path 两个 method 必须合并成一次 route 注册(webServer 按 path 唯一, 分开注册会让整插件 effect 失败→全接口 404)。
  route(ctx, ['GET', 'POST'], '/api/qqbot-settings/group/target-groups', async (req, res) => {
    try {
      if (req.method === 'GET') {
        const u = new URL(req.url ?? '/', 'http://x');
        const bot = nsBot(NSQ(u));
        if (!bot) return writeJson(res, 400, { error: '找不到该账号实例' });
        return writeJson(res, 200, { ok: true, groups: readTargetGroupsJson(bot.cwd) });
      }
      const body = await readJsonBody(req);
      if (!body || typeof body !== 'object') return writeJson(res, 400, { error: 'bad body' });
      const bot = nsBot(String(body.ns || ''));
      if (!bot) return writeJson(res, 400, { error: '找不到该账号实例' });
      const groups = Array.isArray(body.groups) ? body.groups : [];
      writeTargetGroupsJson(bot.cwd, groups);
      audit(bot.cwd, { ev: 'group.target-groups.save', ns: bot.id, n: groups.length });
      writeJson(res, 200, { ok: true, groups });
    } catch (e) { writeJson(res, 500, { error: String((e && e.message) || e) }); }
  });

  // 群发任务列表(读时推进一个目标) {ns?}
  route(ctx, 'GET', '/api/qqbot-settings/group/broadcast/list', async (req, res) => {
    try {
      const u = new URL(req.url ?? '/', 'http://x');
      const bot = nsBot(NSQ(u));
      if (!bot) return writeJson(res, 400, { error: '找不到该账号实例' });
      const bm = await broadcastMod();
      // 推进一步: 找第一个 queued/sending 的任务推进(串行限频)
      const gc = await groupClientOf(NSQ(u));
      if (gc) {
        const tasks = bm.listTasks(bot.cwd);
        const active = tasks.find((t) => t.state === 'queued' || t.state === 'sending');
        if (active) await bm.advanceTask(bot.cwd, active.task_id, gc.client);
      }
      const after = bm.listTasks(bot.cwd);
      writeJson(res, 200, { ok: true, tasks: after });
    } catch (e) { writeJson(res, 500, { error: String((e && e.message) || e) }); }
  });

  // 中止群发 {ns?, task_id}
  route(ctx, 'POST', '/api/qqbot-settings/group/broadcast/cancel', async (req, res) => {
    const body = await readJsonBody(req);
    if (!body || typeof body !== 'object') return writeJson(res, 400, { error: 'bad body' });
    const taskId = String(body.task_id || '');
    if (!taskId) return writeJson(res, 400, { error: 'task_id 必填' });
    try {
      const bot = nsBot(String(body.ns || ''));
      if (!bot) return writeJson(res, 400, { error: '找不到该账号实例' });
      const bm = await broadcastMod();
      const t = bm.cancelTask(bot.cwd, taskId, 'dock');
      if (!t) return writeJson(res, 400, { error: '任务不存在' });
      audit(bot.cwd, { ev: 'group.broadcast.cancel', ns: bot.id, task_id: taskId });
      writeJson(res, 200, { ok: true, task: t });
    } catch (e) { writeJson(res, 500, { error: String((e && e.message) || e) }); }
  });

  // 撤回群发中某目标已发的消息(2 分钟窗口) {ns?, task_id, peerId}
  route(ctx, 'POST', '/api/qqbot-settings/group/broadcast/recall', async (req, res) => {
    const body = await readJsonBody(req);
    if (!body || typeof body !== 'object') return writeJson(res, 400, { error: 'bad body' });
    const taskId = String(body.task_id || '');
    const peerId = String(body.peerId || '');
    if (!taskId || !peerId) return writeJson(res, 400, { error: 'task_id 与 peerId 必填' });
    try {
      const bot = nsBot(String(body.ns || ''));
      const gc = await groupClientOf(String(body.ns || ''));
      if (!bot || !gc) return writeJson(res, 400, { error: '找不到该账号实例' });
      const bm = await broadcastMod();
      const r = await bm.recallTaskMessage(bot.cwd, taskId, peerId, gc.client);
      audit(bot.cwd, { ev: 'group.broadcast.recall', ns: bot.id, task_id: taskId, peerId, ok: r.ok });
      writeJson(res, 200, r);
    } catch (e) { writeJson(res, 500, { error: String((e && e.message) || e) }); }
  });


  // 按"勾选目标"撤回最近一条广播消息(2026-09-12 主人要求): **不必知道 task_id** ——
  // 服务端自己在该目标的广播记录里找"最新的、已成功且带 message_id"的那条, 2 分钟窗口内撤回。
  // 存在意义: 主人只勾选了目标就该能撤, 不该被迫去任务列表里翻 task_id(那条路又长又容易看不见按钮)。
  route(ctx, 'POST', '/api/qqbot-settings/group/recall-last', async (req, res) => {
    const body = await readJsonBody(req);
    if (!body || typeof body !== 'object') return writeJson(res, 400, { error: 'bad body' });
    const targets = Array.isArray(body.targets) ? body.targets : [];
    if (targets.length === 0) return writeJson(res, 400, { error: 'targets 至少一个' });
    try {
      const bot = nsBot(String(body.ns || ''));
      const gc = await groupClientOf(String(body.ns || ''));
      if (!bot || !gc) return writeJson(res, 400, { error: '找不到该账号实例' });
      const bm = await broadcastMod();
      const tasks = bm.listTasks(bot.cwd).slice().sort((a, b) => (b.created_at || 0) - (a.created_at || 0));
      const out = [];
      for (const t of targets) {
        const peerId = String((t && t.peerId) || '');
        if (!peerId) { out.push({ peerId: '', ok: false, err: '缺少 peerId' }); continue; }
        const hit = tasks.find((x) => x.results && x.results[peerId] && x.results[peerId].ok && x.results[peerId].message_id);
        if (!hit) { out.push({ peerId, ok: false, err: '该目标没有可撤回的广播消息(不是广播发的或没有 message_id)' }); continue; }
        const r = await bm.recallTaskMessage(bot.cwd, hit.task_id, peerId, gc.client);
        out.push({ peerId, ok: r.ok, err: r.err, message_id: r.message_id, task_id: hit.task_id });
        audit(bot.cwd, { ev: 'group.broadcast.recall-last', ns: bot.id, peerId, task_id: hit.task_id, ok: r.ok });
      }
      writeJson(res, 200, { ok: true, results: out });
    } catch (e) { writeJson(res, 500, { error: String((e && e.message) || e) }); }
  });


  // ── 悬浮球「💬 聊天视图」(2026-09-07): 读某 QQ 会话最近的入站/出站消息, 只读不建会话 ──
  // 会话事件结构(宿主 dsh-session): {type, seq, time, data}; user/message 的 data=消息体根(data.content),
  // assistant/message 的 data={turn,step,message:{role,content,…}}。只收这两型:
  //   · user/message   — 群友/对方发言(左气泡)。滤 source.kind='plugin'(runtime context/系统注入)与
  //                      伪造系统通知(入群申请/定时, 内容无 [当前时间 头); 剥「[当前时间 …]」头、
  //                      QQ 入站「[昵称 (openid)]」外壳、<@openid> 提及(换成群成员昵称)、尾部 (@you)、
  //                      长附件 URL(折叠成 [图片] 等)。面板代发(「用户代你发送: 」)标 tag=面板代发。
  //   · assistant/message — 机器人回复(右气泡)。只取 content 里 type=text 块; 纯思考/纯工具步(无正文)跳过。
  // chunk/tool-call/tool-result/step/turn/request 等一律不取 → 天然滤掉流式与工具噪声。
  // 分页: 事件 seq 全序(含 chunk 等), 倒扫快进后只保留聊天两型, 每页默认 50 条升序返回 + hasMore。
  function chatTextOf(blocks) {
    if (!Array.isArray(blocks)) return '';
    const parts = [];
    for (const b of blocks) if (b && b.type === 'text' && typeof b.text === 'string' && b.text) parts.push(b.text);
    return parts.join('\n').trim();
  }
  // ── 入站"块标记"在 dock 聊天视图里的解析（2026-09-15 起标记改短, 见插件 src/transport/markers.ts）──
  //   新标记: [引]…[/引] [当前] [历史]…[/历史] + 时间行 "[2026-09-15 周二 11:06]"（不再带"当前时间"四字）
  //   老标记: [Quoted message begins]…[ends] [Current message] [Chat history begins]/[ends] + "[当前时间 …]"
  //   ⚠️ **两套都要认**: 老会话里的历史消息是渲染时解析的, 只认新标记会让旧记录显示成一堆裸标记。
  const RE_TIME_HEAD = /^\s*\[(?:\d{4}-\d{2}-\d{2}\s[^\]]*|当前时间[^\]]*)\]\s*\r?\n?/;
  const isTimeHeadLine = (s) => /^\[(?:\d{4}-\d{2}-\d{2}\s|当前时间)/.test(s);
  const RE_HIST_BEGIN_LINE = /^\[(?:历史|Chat history begins)\]$/;
  const RE_HIST_END_LINE = /^\[\/(?:历史|Chat history ends)\]$/;   // 老标记没有斜杠
  const RE_CURRENT_LINE = /^\[(?:当前|Current message)\]$/;
  const RE_QUOTE_BEGIN = /\[(?:引|Quoted message begins)\]/i;
  const RE_QUOTE_END = /\[\/(?:引|Quoted message ends)\]/i;
  const RE_CURRENT_ANY = /\[(?:当前|Current message)\]\s*/g;
  const hasHistoryBlock = (s) => RE_HIST_BEGIN_LINE.test(String(s || '').trim()) || String(s || '').indexOf('[Chat history begins]') >= 0;
  function chatPeelTimeHead(text) {
    // QQ 入站文本头形如 "[2026-09-15 周二 11:06]\n\n"（老版是 "[当前时间 2026-09-05 周六 19:08]"）, 整体剥掉
    return String(text || '').replace(RE_TIME_HEAD, '');
  }
  function chatDisplayClean(text, nameByMid) {
    let s = String(text || '');
    // <@openid> 提及 → @昵称(群成员表有则换名, 否则 @短id)
    s = s.replace(/<@([A-Za-z0-9_-]{6,})>/g, (all, id) => {
      const nm = (nameByMid && nameByMid.get && nameByMid.get(id)) || '';
      return nm ? ('@' + nm) : ('@' + id.slice(0, 6));
    });
    // 行尾 (@you) 等点名标记剥掉(那是给 LLM 的, QQ 界面不显示)
    s = s.replace(/\s*\(@you\)\s*$/, '');
    return s.trim();
  }
  const QQ_MEDIA_RE = /(?:multimedia\.nt\.qq\.com\.cn|multimedia\.qq\.com|qpic\.cn|qlogo\.cn)/i;
  const QQ_URL_RE = /https?:\/\/[^\s\]\)）]+/g;
  // 从聊天文本抽离 QQ 媒体 URL(图/附件直显用), 附件描述行整行吞掉; 返回 {text, images}
  // 面板代发媒体标记 "[MEDIA:类型|来源]": 网络图直接当图; 本机路径图/音频/视频转成 raw-media 直出 URL
  function chatMediaSrcToImg(kind, src) {
    const k = String(kind || '')
      .replace(/图片|img/gi, 'image').replace(/视频|video/gi, 'video')
      .replace(/语音|音频|voice/gi, 'voice').replace(/文件|file/gi, 'file');
    const s = String(src || '').trim();
    if (!s) return null;
    if (/^https?:\/\//i.test(s)) return { url: s, kind: k };
    if (k === 'image' || k === 'voice' || k === 'video') {
      return { url: '/api/qqbot-settings/chat/raw-media?p=' + encodeURIComponent(s), kind: k };
    }
    return null; // 本地文件类型不确定时不渲染, 保留文字
  }
  // 按扩展名判本机文件类型(整行本地路径的文本消息也能看图/播音频)
  function chatLocalExtKind(path) {
    const ext = String(path || '').split('?')[0].split('.').pop().toLowerCase();
    if (/^(jpe?g|png|gif|webp|bmp)$/.test(ext)) return 'image';
    if (/^(mp3|wav|ogg|opus|m4a|aac|amr|silk)$/.test(ext)) return 'voice';
    if (/^(mp4|webm|mov|m4v)$/.test(ext)) return 'video';
    return null;
  }
  // 来源短名(标注用): 路径/URL 尾段去 query
  function chatSrcShortName(src) {
    let s = String(src || '').trim();
    const i = Math.max(s.lastIndexOf('/'), s.lastIndexOf('\\'));
    if (i >= 0) s = s.slice(i + 1);
    return s.replace(/[?#].*$/, '') || src || '';
  }
  function chatLocalRawUrl(p) {
    return '/api/qqbot-settings/chat/raw-media?p=' + encodeURIComponent(p);
  }
  // ── 图片台账(兜底) ──────────────────────────────────────────────────────────
  // 格式与 dist/features/image-url-ledger.js 完全一致: `{表情包目录}/image-url-ledger.jsonl`,
  //   一行一条 {id,url,at}; 查表从后往前取最新的那条。上限 1000 条(写侧维护)。
  // ⚠️ 渲染链是同步的 → 这里自带一份**同步只读**实现(按 mtime+size 缓存), 不去 await 那个模块。
  const CHAT_LEDGER_NAME = 'image-url-ledger.jsonl';
  const chatLedgerCache = new Map();
  // `…\表情包\lib\candidate\x.jpg` → `…\表情包`(找不到 lib 段就退回上一级)
  function chatLedgerDirOf(imgPath) {
    const p = String(imgPath || '');
    const s = p.indexOf('\\') >= 0 ? '\\' : '/';
    const parts = p.split(/[\\/]/);
    const i = parts.lastIndexOf('lib');
    return i > 0 ? parts.slice(0, i).join(s) : dirname(p);
  }
  function chatLedgerIndex(dir) {
    const file = join(dir, CHAT_LEDGER_NAME);
    let key = 'missing';
    try { const st = statSync(file); key = st.mtimeMs + ':' + st.size; } catch (e) { /* 台账还没建 */ }
    const hit = chatLedgerCache.get(file);
    if (hit && hit.key === key) return hit.index;
    const index = new Map();
    try {
      for (const line of readFileSync(file, 'utf8').split('\n')) {
        const s = line.trim();
        if (!s) continue;
        try {
          const o = JSON.parse(s);
          if (o && o.id && o.url) index.set(String(o.id), String(o.url)); // 后出现的覆盖 = 最新链接
        } catch (e) { /* 坏行跳过 */ }
      }
    } catch (e) { /* 没有台账文件 */ }
    chatLedgerCache.set(file, { key, index });
    return index;
  }
  // 图片文件路径 → 台账里的 QQ 链接(查不到返回 '')
  function chatLedgerImageUrl(imgPath) {
    try {
      const id = chatSrcShortName(imgPath).replace(/\.[a-z0-9]{1,6}$/i, '');
      if (!id) return '';
      return chatLedgerIndex(chatLedgerDirOf(imgPath)).get(id) || '';
    } catch (e) { return ''; }
  }
  // 反向: QQ 链接 → { id, dir } —— 历史消息里那条链接以前被我们收进过图库, 现在还能对上号,
  //   就说明**本地有这张图** → 前端可以改走本地(sticker-img / raw-media), 不必依赖会过期的 rkey。
  function chatLedgerDirs() {
    const dirs = new Set();
    for (const k of chatLedgerCache.keys()) dirs.add(dirname(k));
    try { const dd = getStickerStore().dataDir; if (dd) dirs.add(String(dd)); } catch (e) { /* 图库不可用 */ }
    return [...dirs];
  }
  function chatLedgerOfUrl(url) {
    const u = String(url || '');
    if (!/^https?:\/\//i.test(u)) return null;
    for (const dir of chatLedgerDirs()) {
      const idx = chatLedgerIndex(dir);
      for (const [id, link] of idx) if (link === u) return { id, dir };
    }
    return null;
  }
  // 图库 id → 同源缩略图接口(sticker-img 按 id 解析, 与所在层无关)
  function chatStickerImgUrl(id, stickerDir) {
    if (!id) return '';
    return '/api/qqbot-settings/sticker-img?id=' + encodeURIComponent(id)
      + (stickerDir ? '&dataDir=' + encodeURIComponent(stickerDir) : '');
  }
  // 图库里的真实路径: 文件名就是图库 id, 但**文件会搬层**(candidate→library→trash),
  //   消息里记的是"当时"的路径 → 这里问 store 拿当前路径(2026-09-13 主人实测的 [图加载失败] 就是这个)
  function chatStickerRealPath(imgPath) {
    try {
      const id = chatSrcShortName(imgPath).replace(/\.[a-z0-9]{1,6}$/i, '');
      if (!/^[0-9a-f]{6,}$/i.test(id)) return '';
      const dir = chatLedgerDirOf(imgPath);
      const store = getStickerStore(dir);
      if (!store || typeof store.get !== 'function' || !store.get(id)) return '';
      const p = typeof store.pathOf === 'function' ? store.pathOf(id) : '';
      return p && chatLocalFileExists(p) ? p : '';
    } catch (e) { return ''; }
  }
  function chatLocalFileExists(p) {
    try { return statSync(p).isFile(); } catch (e) { return false; }
  }
  // 附件行里的**本机目标**(2026-09-13 主人要求: dock 聊天界面图片要同时兼容 url 与本地路径/图库链接)
  //   背景: 入站消息的图片从 QQ 链接改成本地路径后(`- Image: 名 (1086×1448) → D:\…\a.jpg`),
  //   dock 里图片直接不显示了 —— 这里把本机目标转成同源直出 URL 给 <img> 用。
  //   支持三种: ① Windows 绝对路径 ② /api/qqbot-settings/... 本插件接口(含 sticker-img?id=)
  //   ③ 其它绝对路径(POSIX)。返回 { url, kind, name, fb } 或 null。
  //   顺序: ①图库查**当前真实路径**(搬层也能对上) ②文件不在 → 台账 QQ 链接 ③都不行 → 原路径(前端再兜)
  function chatLocalTargetOf(raw, hasVoiceCtx) {
    const l = String(raw || '');
    // 优先取 "→ " 之后到行尾(路径里可能有空格); 没有箭头就在行内找绝对路径
    const arrow = l.match(/→\s*([\s\S]+?)\s*$/);
    let cand = arrow ? arrow[1].trim() : '';
    if (!cand) {
      const m2 = l.match(/([A-Za-z]:[\\/][^\s]+)/);
      cand = m2 ? m2[1] : '';
    }
    if (!cand) return null;
    // ① 已经是本插件自己的接口路径 → 原样用(相对路径, 浏览器同源能取)
    if (/^\/api\/qqbot-settings\//i.test(cand)) {
      return { url: cand, kind: chatAttachmentKind(l, hasVoiceCtx, undefined) || 'image', name: chatSrcShortName(cand), fb: '' };
    }
    // ② 本机文件 → 先问图库拿**当前真实路径**(candidate→library 搬层后, 消息里那条路径已失效 ——
    //   主人实测的 [图加载失败] 就是这么来的), 文件真不在才退台账的 QQ 链接
    if (!/^[A-Za-z]:[\\/]/.test(cand) && !/^\\\\/.test(cand) && !cand.startsWith('/')) return null;
    const lk = chatLocalExtKind(cand) || chatAttachmentKind(l, hasVoiceCtx, undefined) || 'image';
    const realPath = chatStickerRealPath(cand);
    const usePath = realPath || cand;
    const alive = chatLocalFileExists(usePath);
    const qqUrl = chatLedgerImageUrl(cand) || chatLedgerImageUrl(usePath);
    const sid = (chatSrcShortName(cand).match(/^([0-9a-f]{6,})\.[a-z0-9]{1,6}$/i) || [])[1] || '';
    return {
      url: (!alive && qqUrl) ? qqUrl : chatLocalRawUrl(usePath),
      fb: alive ? (qqUrl || chatStickerImgUrl(sid, chatLedgerDirOf(usePath))) : '',
      kind: lk,
      name: chatSrcShortName(cand),
    };
  }
  // 附件行/URL 归属类型: 行内**显式类型标签**优先, 其次文件名/URL fname 扩展名, 最后行标签与上下文
  // ⚠️ 2026-09-10 根因修复(主人实测: "视频还是附件形式, 图片也变成附件了"):
  //   QQ 群聊里图片/视频的 content_type 实测可能是 `'file'`(不是 image/jpeg) —— 官方取值表:
  //   voice / image/jpeg|png|gif / video/mp4 / file(=群文件)。端上(media-kind.ts)已按
  //   MIME→扩展名→宽高→URL 特征(appid/orgfmt) 推断真实类型, 并以 `- Image: 名 → url` 注入 Layer 4。
  //   这里必须认这些**显式前缀**, 否则 `- File:` 会把图片/视频判成 📎 附件(图片不显示、视频不能播)。
  function chatAttachmentKind(line, hasVoiceCtx, defaultKind) {
    const l = String(line || '');
    // ① 显式类型标签(我方注入格式, 最权威)
    if (/^-\s*(?:Image|图片)\s*:/i.test(l) || /^\[(?:Image|图片)\s*:/i.test(l)) return 'image';
    if (/^-\s*(?:Video|视频)\s*:/i.test(l) || /^\[(?:Video|视频)\s*:/i.test(l)) return 'video';
    if (/^-\s*(?:Voice|语音|音频)\s*:/i.test(l) || /^\[(?:Voice|语音|音频)\s*:/i.test(l)) return 'voice';
    if (/^-\s*(?:File|文件)\s*:/i.test(l) || /^\[(?:File|文件)\s*:/i.test(l)) return 'file';
    // 从行内或 URL fname 参数取文件名
    let name = '';
    const fm = l.match(/fname=([^&\s]+)/);
    if (fm) { try { name = decodeURIComponent(fm[1]); } catch { name = fm[1]; } }
    const am = l.match(/\[Attachment:\s*([^\s\]]+)/i);
    if (am) name = am[1];
    const extM = name.match(/\.([a-z0-9]{2,5})$/i);
    const ext = extM ? extM[1].toLowerCase() : '';
    if (/^(ogg|amr|silk|mp3|wav|opus|m4a|aac)$/.test(ext) || /\[语音|\[音频|\[Voice message\]/i.test(l)) return 'voice';
    if (/^(jpe?g|png|gif|webp|bmp)$/.test(ext)) return 'image';
    if (/^(mp4|webm|mov|m4v)$/.test(ext)) return 'video';
    if (/^(zip|rar|7z|tar|gz|pdf|doc|docx|xls|xlsx|ppt|pptx|txt|csv|apk|exe|iso|json|md|html?|js|py|ts|xml)$/.test(ext)) return 'file';
    if (/\[文件:|\[File:|\[附件:|- File:|\bFile:/i.test(l)) return 'file';
    if (hasVoiceCtx) return 'voice';
    return defaultKind || 'image';
  }
  // 文件显示名: URL fname 参数解码优先, 否则路径尾名
  function chatFileDisplayName(u) {
    try { const q = new URL(u).searchParams.get('fname'); if (q) return decodeURIComponent(q); } catch { /* 继续 */ }
    return chatSrcShortName(u) || '文件';
  }
  function chatSplitMedia(text) {
    const images = [];
    const lines = String(text || '').split('\n');
    const out = [];
    // 语音消息上下文: 该条消息含 ASR/Voice message/语音标记 → 附件 URL 按音频渲染(可播放)
    const hasVoiceCtx = /- ASR:|\[Voice message\]|\[语音|\[音频|voice/i.test(String(text || ''));
    for (const line of lines) {
      const raw = line.trim();
      if (!raw) { out.push(''); continue; }
      // QQ 语音转文字: "- ASR: 内容" → 当消息正文保留
      if (/^- ASR:/i.test(raw)) { out.push(raw.replace(/^- ASR:\s*/i, '').trim()); continue; }
      // "[Voice message] 内容" → 剥壳当正文(与 ASR 重复时可留, dock 不丢文字)
      if (/^\[Voice message\]/i.test(raw)) { const vt = raw.replace(/^\[Voice message\]\s*/i, '').trim(); if (vt) out.push(vt); continue; }
      // 面板代发媒体标记(用户代发上下文格式): [MEDIA:图片|D:\…] / [MEDIA:图片|http…]
      const md = raw.match(/^\[MEDIA:([^\]|]+)\|([^\]]+)\]$/i);
      if (md) {
        const got = chatMediaSrcToImg(md[1], md[2]);
        const sn = chatSrcShortName(md[2]);
        if (got) {
          images.push({ url: got.url, kind: got.kind === 'image' ? 'image' : got.kind });
          const icon = got.kind === 'voice' ? '🎵' : got.kind === 'video' ? '🎬' : '📷';
          out.push(icon + ' ' + sn);
        } else {
          out.push('📎 ' + sn);
        }
        continue;
      }
      // 整行就是一个本机绝对路径(主人贴 <cwd>\a.jpg / a.mp3 文本) → 按扩展名转可看/可播
      const lp = raw.match(/^([A-Za-z]:[\\/].+)$/);
      if (lp) {
        const lk = chatLocalExtKind(lp[1]);
        if (lk) {
          const rp = chatStickerRealPath(lp[1]) || lp[1];  // 图库搬层也能对上当前路径
          const led = lk === 'image' ? chatLedgerImageUrl(lp[1]) : '';
          images.push({ url: chatLocalRawUrl(rp), kind: lk, fb: led });
          continue;
        }
      }
      // 附件描述行: "- Image: …" / "- Video: …" / "- Voice: …" / "- File: …" / "- Attachment URLs: …"
      //            / "[图片: …]" / "[视频: …]" / "[附件: …]" / "[Attachment: name -> …]" / Layer1 的英文标签行
      if (/^-\s*Attachment URLs:/i.test(raw) || /^-\s*(Image|Video|Voice|File)s?:/i.test(raw) || /^\[(图片|附件|文件|语音|视频|音频):/i.test(raw) || /^\[(Attachment|File|Image|Video):/i.test(raw)) {
        const urls = raw.match(QQ_URL_RE) || [];
        let got = 0;
        for (const u of urls) {
          const k = chatAttachmentKind(raw, hasVoiceCtx, undefined);
          // 图片/音频须是 QQ 媒体域; 文件(ftn.qq.com 等任意域)直接收
          // ⚠️ 图片带兜底: 这条链接以前被收进过图库 → 本地有文件, rkey 过期了也能显示(fb → sticker-img)
          const led = k === 'image' ? chatLedgerOfUrl(u) : null;
          const fb = led ? chatStickerImgUrl(led.id, led.dir) : '';
          if (k === 'file') { images.push({ url: u, kind: 'file', name: chatFileDisplayName(u) }); got++; }
          else if (QQ_MEDIA_RE.test(u)) { images.push({ url: u, kind: k, fb }); got++; }
        }
        if (!got) {
          // ⚠️ 2026-09-13 新增(主人实测: "web 界面出问题了/图片不显示了"): 目标可能是**本机路径**
          //   —— 图片入站改成给本地路径(`- Image: 名 (1086×1448) → D:\…\lib\candidate\x.jpg`)后,
          //   这里原来只认 http(s) URL, 于是图片被当成文本丢掉。现在转成同源直出 URL 正常显示。
          const lt = chatLocalTargetOf(raw, hasVoiceCtx);
          if (lt) {
            if (lt.kind === 'file') images.push({ url: lt.url, kind: 'file', name: lt.name || '文件', fb: lt.fb || '' });
            else images.push({ url: lt.url, kind: lt.kind, fb: lt.fb || '' });
            got += 1;
          }
        }
        if (!got) {
          // Layer 1 的英文描述行(`[Image: 名 800×600]` / `[Video: 名]` / `[File: 名 (1.2MB)]`)不含 URL,
          // 其媒体由 Layer 4 的 `- Image:/- Video:/- File:` 行承载 → 直接丢弃, 避免显示成
          // `📎 [Image: 名 800×600]` 这种丑文本(主人 2026-09-10 实测反馈)。
          if (/^\[(Image|Video|File):/i.test(raw)) continue;
          // 无 URL 的 File/附件描述行(如 "- File: a.zip (3.0MB)")→ 保留可读文本, 不给空占位
          const desc = raw
            .replace(/^-\s*File:\s*/i, '').replace(/^\[File:\s*/i, '')
            .replace(/^\[(图片|附件|文件|语音|视频|音频):\s*/i, '').trim().replace(/\]$/, '').trim();
          if (desc && !/^https?:/i.test(desc) && !/^Attachment\s*:/i.test(desc)) out.push('📎 ' + desc);
        }
        continue;
      }
      // 整行就是一个 QQ 媒体 URL(纯图片/音频消息体) → 当媒体(图片同样带本地兜底)
      const urls = raw.match(QQ_URL_RE) || [];
      if (urls.length === 1 && QQ_MEDIA_RE.test(raw) && raw === urls[0]) {
        const k1 = chatAttachmentKind(raw, hasVoiceCtx, 'image');
        const led1 = k1 === 'image' ? chatLedgerOfUrl(urls[0]) : null;
        images.push({ url: urls[0], kind: k1, fb: led1 ? chatStickerImgUrl(led1.id, led1.dir) : '' });
        continue;
      }
      // 普通行: 行内嵌的 QQ 媒体长 URL 抽走(防撑爆气泡), 其余保留
      if (urls.length) {
        let rest = raw;
        for (const u of urls) {
          if (QQ_MEDIA_RE.test(u)) {
            const k2 = chatAttachmentKind(raw, hasVoiceCtx, 'image');
            const led2 = k2 === 'image' ? chatLedgerOfUrl(u) : null;
            images.push({ url: u, kind: k2, fb: led2 ? chatStickerImgUrl(led2.id, led2.dir) : '' });
            rest = rest.split(u).join('');
          }
        }
        rest = rest.trim();
        if (rest) out.push(rest);
        continue;
      }
      out.push(raw);
    }
    // 去重保序
    // 去重: 同一 URL 在多行出现(描述行/标签行/Attachment 行)时保留最精确的类型
    // 权重: voice/video(扩展名实锤)=3 > image(图片扩展名)/file(标签/扩展名)=2 > 默认 image=1
    const kindW = (x) => {
      const k = typeof x === 'string' ? 'image' : ((x && x.kind) || 'image');
      if (k === 'voice' || k === 'video') return 3;
      if (k === 'file') return 2;
      return 2; // image(含默认)
    };
    const byUrl = new Map();
    for (const x of images) {
      const key = typeof x === 'string' ? x : (x && x.url);
      if (!key) continue;
      const prev = byUrl.get(key);
      if (!prev || kindW(x) >= kindW(prev)) byUrl.set(key, x);
    }
    const uniq = [...byUrl.values()];
    // 正文行去重(ASR 与 [Voice message] 常同文, 不重复显示)
    const rawLines = out.join('\n').split('\n');
    const textOut = rawLines.filter((l, i) => rawLines.indexOf(l) === i).join('\n').trim();
    return { text: textOut, images: uniq };
  }
  // 群延迟/冷却历史打包的分行器: [Chat history begins]…[Chat history ends] + [Current message]
  // 每行 "[昵称 (openid)] 内容" 开新气泡, 后续行并入该气泡; 系统提示段起截断(后面是给 LLM 的注入)
  function chatSplitHistoryBlock(body) {
    const out = [];
    let cur = null;
    // ⚠️ 2026-09-10 修复(主人实测: 当前消息的语音被挂到了上一条历史消息上):
    //   Layer 4 的媒体元数据行(`- Attachment URLs:` / `- File:` …)排在 `[Current message]` 之后、
    //   带昵称的当前消息之前 —— 原逻辑"无昵称行并入上一个气泡"会把它算到上一条历史消息头上。
    //   改为: 这类 `- ` 开头的元数据行先暂存(pendingMeta), 等下一个带昵称的消息出现时归属它
    //   (即"元数据行属于它下面那条消息"), 找不到归属时才丢弃。
    let pendingMeta = [];
    const flush = () => {
      if (cur) {
        const t = cur.lines.join('\n').trim();
        out.push({ sender: cur.sender, text: t });
      }
      cur = null;
    };
    for (const line of String(body || '').split('\n')) {
      const s = line.trim();
      if (!s) continue;
      if (RE_HIST_BEGIN_LINE.test(s) || RE_HIST_END_LINE.test(s) || RE_CURRENT_LINE.test(s) || isTimeHeadLine(s)) continue;
      if (/^\[系统提示\]/.test(s)) { flush(); return out; } // 系统注入段, 之后都不属于群聊内容
      // 媒体元数据行: 暂存, 等归属给下面那条带昵称的消息
      // (Layer 4 现输出 `- Image:/- Video:/- Voice:/- File:` 单数前缀, 此处一并覆盖)
      if (/^-\s*(Attachment URLs|Files?|Images?|ASR|Voices?|Videos?)\s*[:：]/i.test(s)) { pendingMeta.push(s); continue; }
      // 2026-09-12 适配(token 瘦身后历史行变成 "[昵称]"): id 段设为**可选**, 老格式 "[昵称 (openid)]" 仍认;
      // 同时排除含冒号的方括号(如 "[图片: url]"), 免得把附件标记当成发送者。
      const m = s.match(/^\[([^\]\n:]*?)(?:\s*\([A-Za-z0-9_-]{6,}\))?\](.*)$/);
      if (m) { flush(); cur = { sender: m[1].trim(), lines: [m[2].trim(), ...pendingMeta].filter(Boolean) }; pendingMeta = []; }
      else { if (cur) cur.lines.push(...pendingMeta, s); else { flush(); cur = { sender: '', lines: [...pendingMeta, s] }; } pendingMeta = []; }
    }
    flush();
    return out;
  }
  // 单条/子条通用清洗: 去 [Current message] 标记、引用块折叠、提取昵称标签、剥 [系统提示]、
  // 去提及/@you、抽离 QQ 媒体 URL。返回 { sender, mm:{text,images} }
  function chatPolishOne(body, fallbackSender, nameByMid) {
    let sender = fallbackSender;
    let b = String(body || '');
    b = b.replace(RE_CURRENT_ANY, '');
    b = b.replace(new RegExp(`${RE_QUOTE_BEGIN.source}\\s*[\\s\\S]*?${RE_QUOTE_END.source}\\s*`, 'g'), '[引用]');
    // 2026-09-12 适配: 同上 —— "[昵称]" 与 "[昵称 (openid)]" 都认; 排除含冒号的方括号(附件标记)
    const tagM = b.match(/\[([^\]\n:]*?)(?:\s*\([A-Za-z0-9_-]{6,}\))?\]/);
    if (tagM) { if (tagM[1].trim()) sender = tagM[1].trim(); b = b.replace(tagM[0], ''); }
    const sysIdx = b.indexOf('[系统提示]');
    if (sysIdx >= 0) b = b.slice(0, sysIdx).replace(/\s*$/, '');
    const mm = chatSplitMedia(chatDisplayClean(b, nameByMid));
    return { sender, mm };
  }
  // 🔍 临时诊断(2026-09-10): 把含媒体标记的入站原文落盘到 ~/.dsh/qqbot-chat-raw.jsonl ——
  //    用于核对 Layer1/Layer4 实际注入格式与 dock 解析结果(主人验收通过后删除本函数与调用)。
  function chatRawDiag(raw0) {
    try {
      const s = String(raw0 || '');
      if (!/(Image|Video|Voice|File|Attachment|图片|视频|语音|文件|附件)|multimedia\.nt\.qq\.com|qpic\.cn/i.test(s)) return;
      appendFileSync(join(homedir(), '.dsh', 'qqbot-chat-raw.jsonl'), JSON.stringify({ t: Date.now(), body: s.slice(0, 5000) }) + '\n');
    } catch { /* 诊断失败不影响主流程 */ }
  }
  // 解码一条会话事件为聊天条目(群打包会展开成多条); 非聊天事件/噪声返回 null
  function chatDecodeEvent(ev, scope, nameByMid, fallbackSender) {
    if (!ev || typeof ev.type !== 'string') return null;
    const data = ev.data && typeof ev.data === 'object' ? ev.data : {};
    const time = typeof ev.time === 'number' ? ev.time : 0;
    if (ev.type === 'user/message') {
      const src = data.source && typeof data.source === 'object' ? data.source : {};
      if (src.kind === 'plugin') return null; // runtime context / 系统注入等, 非真人对话
      const raw0 = chatTextOf(data.content);
      if (!raw0) return null;
      chatRawDiag(raw0);
      const raw = chatPeelTimeHead(raw0);
      const isRelay = /^用户代你发送: /.test(raw);
      // 后台任务/面板大文件完成通知([系统] 后台任务…)→ 显示为 bot 侧气泡并打来源标; 其余系统注入滤掉
      const isBg = /^\[系统\]\s*后台任务/.test(raw0);
      // 伪造/系统注入(无时间头且非 web 直聊): 入群申请/定时 → 滤(QQ 里并没有这句话)
      if (!isTimeHeadLine(raw0) && !src.rpcId) {
        if (/^\[(入群申请|定时|到点)/.test(raw0)) return null;
        if (/^\[系统\]/.test(raw0) && !isBg) return null;
      }
      const isWeb = !!src.rpcId; // web 直聊(同一会话, 主人手打)
      let sender = fallbackSender;
      let body = raw;
      if (isRelay) body = body.replace(/^用户代你发送:\s*/, '');
      if (isBg) body = body.replace(/^\[系统\]\s*/, '');
      // 群延迟/冷却历史打包: [历史]…[/历史] + [当前]（老标记 [Chat history begins]…[ends] + [Current message]）
      // 历史段里每条都是真实发生过的群消息 → 逐条拆成独立气泡(不裁不丢), 返回多条
      if (hasHistoryBlock(body)) {
        const parts = chatSplitHistoryBlock(body);
        const out = [];
        for (const p of parts) {
          const polished = chatPolishOne(p.text, p.sender || fallbackSender, nameByMid);
          if (!polished.mm.text && polished.mm.images.length === 0) continue;
          out.push({ seq: ev.seq, time, dir: 'in', sender: polished.sender || '', text: polished.mm.text, images: polished.mm.images, tag: '' });
        }
        return out.length ? out : null;
      }
      // 普通单条(去标记/剥昵称壳/剥系统提示/抽媒体)
      const polished = chatPolishOne(body, sender, nameByMid);
      sender = polished.sender;
      const mm = polished.mm;
      if (!mm.text && mm.images.length === 0) return null;
      // 面板代发/后台任务完成 = bot 侧事实 → 右气泡 + 来源标(面板代发 / 后台任务)
      return {
        seq: ev.seq, time,
        dir: (isRelay || isBg) ? 'out' : 'in',
        sender: isBg ? '' : (sender || ''),
        text: mm.text,
        images: mm.images,
        tag: isBg ? '后台任务' : (isRelay ? '面板代发' : (isWeb ? 'Web' : '')),
      };
    }
    if (ev.type === 'assistant/message') {
      const msg = data.message && typeof data.message === 'object' ? data.message : null;
      if (!msg) return null;
      const text0 = chatTextOf(msg.content);
      if (!text0) return null; // 纯思考/纯工具步(没对群友说话)跳过
      const text = chatDisplayClean(text0, nameByMid);
      const mm = chatSplitMedia(text);
      if (!mm.text && mm.images.length === 0) return null;
      return { seq: ev.seq, time, dir: 'out', sender: '', text: mm.text, images: mm.images, tag: '' };
    }
    return null;
  }
  // GET /chat/history?ns&scope&peerId&beforeSeq&limit —— 聊天视图数据源
  route(ctx, 'GET', '/api/qqbot-settings/chat/history', async (req, res) => {
    try {
      const u = new URL(req.url ?? '/', 'http://x');
      const ns = String(u.searchParams.get('ns') || '').trim() || undefined;
      const scope = String(u.searchParams.get('scope') || '').trim();
      const peerId = String(u.searchParams.get('peerId') || '').trim();
      if (scope !== 'group' && scope !== 'c2c') return writeJson(res, 400, { error: 'scope 必须为 group|c2c' });
      if (!peerId) return writeJson(res, 400, { error: 'peerId 必填' });
      const limit = Math.max(1, Math.min(200, Math.round(Number(u.searchParams.get('limit'))) || 50));
      const bRaw = Number(u.searchParams.get('beforeSeq'));
      const beforeSeq = Number.isFinite(bRaw) && bRaw > 0 ? Math.floor(bRaw) : undefined;
      const bot = nsBot(ns);
      if (!bot) return writeJson(res, 400, { error: '找不到该账号实例(请先在账号页配置 appId/appSecret)' });
      const reg = await import('./dist/features/session-registry.js');
      const rec = typeof reg.findRecordByPeerWeb === 'function'
        ? reg.findRecordByPeerWeb(String(ns || 'im-qqbot'), scope, peerId) : undefined;
      if (!rec || !rec.agent) {
        return writeJson(res, 200, { ok: true, code: 'no-session', items: [], hasMore: false, msg: '该目标暂无活跃会话' });
      }
      const agent = rec.agent;
      const sess = agent && (agent.session || (agent.ctx && agent.ctx.session));
      if (!sess || typeof sess.seq !== 'number') {
        return writeJson(res, 200, { ok: true, code: 'no-session', items: [], hasMore: false, msg: '会话未就绪' });
      }
      const snap = typeof sess.snapshotEvents === 'function' ? sess.snapshotEvents.bind(sess) : undefined;
      // 名字映射: c2c 用台账兜底 sender; group 读群成员表把 <@openid> 换成昵称
      const dataDir = join(bot.cwd, '表情包');
      const ledger = chatLedgerNames(dataDir);
      const nameByMid = new Map();
      if (scope === 'group') {
        try {
          const lm = await import('./dist/features/chat-ledger.js');
          const mems = (lm.readGroupMembers && lm.readGroupMembers(dataDir, peerId)) || [];
          for (const m of mems) if (m && m.mid && m.name) nameByMid.set(m.mid, m.name);
        } catch { /* 无成员表不阻断 */ }
      }
      const fallbackSender = scope === 'c2c' ? ((ledger.get('c2c:' + peerId) || {}).name || '') : '';
      // 尾部倒扫: 默认从最新一条事件 seq 往前; beforeSeq=加载更早(beforeSeq 之前的)
      const items = [];
      let high = beforeSeq !== undefined ? Math.max(0, beforeSeq - 1) : Math.max(0, sess.seq - 1);
      let reachedEnd = false;
      const STEP = 500;
      while (high >= 0 && items.length < limit) {
        const low = Math.max(0, high - STEP + 1);
        let evs = [];
        if (snap) { try { evs = snap(low, high + 1) || []; } catch { evs = []; } }
        if (!evs.length) { const all = sess.events; if (Array.isArray(all) && all.length && all.length > low) evs = all.slice(low, high + 1); }
        for (let i = evs.length - 1; i >= 0; i--) {
          const got = chatDecodeEvent(evs[i], scope, nameByMid, fallbackSender);
          if (got) {
            if (Array.isArray(got)) { for (const g of got) items.push(g); } // 群打包历史 → 多条
            else items.push(got);
          }
          if (items.length >= limit) { reachedEnd = !(i > 0 || low > 0); break; }
        }
        if (items.length >= limit) break;
        if (low === 0) { reachedEnd = true; break; }
        high = low - 1;
      }
      // ⚠️ 2026-09-10 修复(主人实测"同一批次的历史消息会倒序"):
      //   原为 items.reverse() —— 倒扫时同一打包块([Chat history begins]…[Chat history ends])
      //   拆出的多条共用同一个 ev.seq, 块内本就是旧→新; 整体 reverse 会把"块内顺序"也翻反,
      //   表现为"整批之间顺序对、批内倒序"。
      //   改为: 按 seq 分块 → 块间倒序(旧→新), 块内保持原顺序。
      {
        const blocks = [];
        for (const it of items) {
          const last = blocks[blocks.length - 1];
          if (last && last.seq === it.seq) last.arr.push(it);
          else blocks.push({ seq: it.seq, arr: [it] });
        }
        blocks.reverse();
        items.length = 0;
        for (const b of blocks) for (const one of b.arr) items.push(one);
      }
      // QQ 媒体域的语音 URL → 经 /chat/voice-play 转 mp3 播放(浏览器解不了 SILK)
      for (const it of items) {
        if (!Array.isArray(it.images)) continue;
        for (const m of it.images) {
          if (m && typeof m === 'object' && m.kind === 'voice' && typeof m.url === 'string'
            && /^https?:/i.test(m.url) && QQ_MEDIA_RE.test(m.url)) {
            m.url = '/api/qqbot-settings/chat/voice-play?u=' + encodeURIComponent(m.url);
          }
        }
      }
      // 群图片/附件消息不带昵称壳 → 用之前最近一条有名字的群友文本消息推断发送者(只影响展示)
      {
        let prev = '';
        for (const it of items) {
          if (it.dir === 'in') {
            if (!it.sender && it.tag !== 'Web') it.sender = prev;
            if (it.text && it.tag !== 'Web') prev = it.sender;
          }
        }
      }
      writeJson(res, 200, { ok: true, items, hasMore: !reachedEnd, tailSeq: sess.seq });
    } catch (e) { writeJson(res, 500, { error: String((e && e.message) || e) }); }
  });

  // 面板富媒体发送: dock 聊天输入框 bbcode [MEDIA:kind|src] → 以机器人身份向群/私聊发富媒体。
  // src = http(s) 网络图/文件, 或本机绝对路径(D:\xxx\a.jpg)。复用 agentCtx 的
  // qqChannel.sender.sendMedia(与通道 send_media 工具同一咽喉, 含表情包闸门/撤回记账)。
  let hostBgSeq = 0; // dock 面板大文件后台任务序号(与通道工具后台任务同款语义)
  route(ctx, 'POST', '/api/qqbot-settings/chat/media', async (req, res) => {
    const body = await readJsonBody(req);
    if (!body || typeof body !== 'object') return writeJson(res, 400, { error: 'bad body' });
    const scope = String(body.scope || '');
    const peerId = String(body.peerId || '').trim();
    const kind = String(body.kind || '');
    const url = String(body.url || '').trim();
    const localPath = String(body.localPath || '').trim();
    if (scope !== 'group' && scope !== 'c2c') return writeJson(res, 400, { error: 'scope 必须为 group|c2c' });
    if (!peerId) return writeJson(res, 400, { error: 'peerId 必填' });
    if (!['image', 'video', 'voice', 'file'].includes(kind)) return writeJson(res, 400, { error: 'kind 必须为 image|video|voice|file' });
    const isUrl = /^https?:\/\//i.test(url);
    if (!isUrl && !localPath) return writeJson(res, 400, { error: 'url(http 链接) 或 localPath(本机路径) 至少给一个' });
    if (localPath) {
      // 本机直读: 面板和宿主同机, 文件存在才发(防手误/路径注入)
      try {
        const st = statSync(localPath);
        if (!st.isFile()) return writeJson(res, 200, { ok: false, msg: '本地文件不存在或不是文件: ' + localPath });
        if (st.size <= 0) return writeJson(res, 200, { ok: false, msg: '本地文件为空(0 字节)' });
      } catch {
        return writeJson(res, 200, { ok: false, msg: '读不到本地文件: ' + localPath + '(确认路径存在)' });
      }
    }
    const ns = String(body.ns || 'im-qqbot').trim();
    const kindLbl = kind === 'image' ? '图片' : kind === 'video' ? '视频' : kind === 'voice' ? '语音' : '文件';
    try {
      const reg = await import('./dist/features/session-registry.js');
      const rec = typeof reg.findRecordByPeerWeb === 'function' ? reg.findRecordByPeerWeb(ns, scope, peerId) : undefined;
      if (!rec || !rec.agent) return writeJson(res, 200, { ok: false, msg: '该目标暂无活跃会话(让机器人先聊过几句)' });
      const aCtx = rec.agent && (rec.agent.ctx || (rec.agent).agentCtx);
      const ch = aCtx && typeof aCtx.get === 'function' ? aCtx.get('qqChannel') : undefined;
      const sm = ch && ch.sender && typeof ch.sender.sendMedia === 'function' ? ch.sender : undefined;
      if (!sm) return writeJson(res, 200, { ok: false, msg: '机器人通道未就绪(给该目标发条消息后再试)' });
      const srcDesc = localPath ? localPath : url.slice(0, 120);
      // 本地大文件(≥5MB): 后台异步发送(分片耗时), 立即返回; 完成/失败往会话写 [系统] 后台任务通知(dock 可见+来源标)
      let localSize = 0;
      if (localPath) { try { localSize = statSync(localPath).size; } catch { localSize = 0; } }
      const FILE_ASYNC_MIN = 5 * 1024 * 1024;
      if (localPath && localSize >= FILE_ASYNC_MIN) {
        const seq = ++hostBgSeq;
        const fname = localPath.split(/[\\/]/).pop() || 'file';
        const fnameClean = String(fname).split('?')[0];
        const doSend = () => sm.sendMedia({ scope, targetId: peerId }, kind, { localPath });
        void (async () => {
          let okNote = '成功';
          try {
            await doSend();
            if (body.insertContext === true) {
              try {
                const relayText = String(body.relayText || '').slice(0, 500) || localPath;
                await appendUserRelayToPeer(ns, scope, peerId, '[MEDIA:' + kindLbl + '|' + relayText + ']');
              } catch { /* 上下文写入失败不影响发送结果提示 */ }
            }
          } catch (e) {
            okNote = '失败: ' + String((e && e.message) || e).slice(0, 120);
            const bot2 = nsBot(ns || undefined);
            if (bot2 && bot2.cwd) audit(bot2.cwd, { ev: 'chat.media.bg', ns, scope, peerId, kind, src: srcDesc, ok: false, error: okNote });
          }
          await appendNoticeToPeer(ns, scope, peerId, '[系统] 后台任务 #' + seq + ' ' + (okNote === '成功' ? ('完成: 已发送 ' + fnameClean + '(' + Math.round(localSize / 1048576 * 10) / 10 + 'MB)。') : ('失败: ' + okNote)));
        })();
        const bot0 = nsBot(ns || undefined);
        if (bot0 && bot0.cwd) audit(bot0.cwd, { ev: 'chat.media.bg-start', ns, scope, peerId, kind, src: srcDesc, size: localSize });
        return writeJson(res, 200, { ok: true, msg: '📤 大文件已提交后台任务 #' + seq + '(' + Math.round(localSize / 1048576 * 10) / 10 + 'MB), 分片上传中… 完成后会有通知', id: undefined });
      }
      const r = await sm.sendMedia({ scope, targetId: peerId }, kind, localPath ? { localPath } : { url });
      const bot = nsBot(ns || undefined);
      if (bot && bot.cwd) audit(bot.cwd, { ev: 'chat.media', ns, scope, peerId, kind, src: srcDesc, ok: true });
      // 与文本发送一致: insertContext=true → 往该会话写「用户代你发送: …」模拟消息(web 流/dock 可见, 不唤醒不开回合)
      // 文本用 [MEDIA:类型|来源] 结构化 → dock 能渲染本地上传图, bot 上下文也知道发了哪个来源
      let ctxNote = '';
      if (body.insertContext === true) {
        const relayText = String(body.relayText || '').slice(0, 500);
        const inner = relayText || srcDesc || kindLbl;
        const why = await appendUserRelayToPeer(ns, scope, peerId, '[MEDIA:' + kindLbl + '|' + inner + ']').catch(() => 'failed');
        if (why) { if (bot && bot.cwd) audit(bot.cwd, { ev: 'chat.media.relay-skip', ns, reason: why }); ctxNote = ' (' + (WHY_MAP[why] || why) + ')'; }
        else ctxNote = ' (已记入上下文)';
      }
      writeJson(res, 200, { ok: true, msg: '已发送' + kindLbl + ' ✓' + ctxNote, id: r && r.id });
    } catch (e) {
      const msg = String((e && e.message) || e);
      const bot = nsBot(ns || undefined);
      if (bot && bot.cwd) audit(bot.cwd, { ev: 'chat.media', ns, scope, peerId, kind, src: localPath || url.slice(0, 120), ok: false, error: msg });
      writeJson(res, 200, { ok: false, msg: '发送失败: ' + msg });
    }
  });

  // 面板文件选择器后端(小文件 base64 版): dock 旧客户端/小文件用, 落 dock-uploads。
  route(ctx, 'POST', '/api/qqbot-settings/chat/upload', async (req, res) => {
    const body = await readJsonBody(req);
    if (!body || typeof body !== 'object') return writeJson(res, 400, { error: 'bad body' });
    const bot = nsBot(String(body.ns || '').trim() || undefined);
    if (!bot || !bot.cwd) return writeJson(res, 400, { error: '找不到该账号实例(请先在账号页配置 appId/appSecret)' });
    const data = String(body.data || '');
    const m = data.match(/^data:([^;]+);base64,(.*)$/s) || data.match(/^base64:(.*)$/s);
    const b64 = m ? (m[2] || '') : data;
    if (!b64) return writeJson(res, 400, { error: 'data(base64) 必填' });
    let ext = String(body.ext || '').replace(/[^a-z0-9]/gi, '').toLowerCase();
    if (!ext) ext = 'bin';
    if (ext.length > 6) return writeJson(res, 400, { error: '扩展名不合法' });
    try {
      const buf = Buffer.from(b64, 'base64');
      if (buf.length <= 0) return writeJson(res, 200, { ok: false, msg: '空文件' });
      const dir = join(bot.cwd, '.qqbot', 'dock-uploads');
      mkdirSync(dir, { recursive: true });
      const name = 'up' + Date.now() + '-' + Math.floor(Math.random() * 1e6) + '.' + ext;
      const target = join(dir, name);
      writeFileSync(target, buf);
      writeJson(res, 200, { ok: true, path: target });
    } catch (e) {
      writeJson(res, 500, { error: String((e && e.message) || e) });
    }
  });

  // 面板文件选择器后端(大文件流式版): dock 📎 选中的任意大小文件直接以 octet-stream body 上传,
  // 流式写盘(不占内存上限 readJsonBody 的 8MB), 落 cwd/.qqbot/dock-uploads → client 插 [MEDIA:kind|path]。
  // 参数走 query: ns(账号实例), ext(扩展名); body = 原始文件字节。
  route(ctx, 'POST', '/api/qqbot-settings/chat/upload-raw', async (req, res) => {
    try {
      const u = new URL(req.url ?? '/', 'http://x');
      const bot = nsBot(String(u.searchParams.get('ns') || '').trim() || undefined);
      if (!bot || !bot.cwd) return writeJson(res, 400, { error: '找不到该账号实例(请先在账号页配置 appId/appSecret)' });
      let ext = String(u.searchParams.get('ext') || '').replace(/[^a-z0-9]/gi, '').toLowerCase().slice(0, 6);
      if (!ext) ext = 'bin';
      const dir = join(bot.cwd, '.qqbot', 'dock-uploads');
      mkdirSync(dir, { recursive: true });
      const name = 'up' + Date.now() + '-' + Math.floor(Math.random() * 1e6) + '.' + ext;
      const target = join(dir, name);
      const ws = createWriteStream(target);
      const MAX = 300 * 1024 * 1024;
      let size = 0;
      let failed = null;
      try {
        for await (const chunk of req) {
          size += chunk.length;
          if (size > MAX) { failed = 'too large(>300MB)'; break; }
          if (!ws.write(chunk)) await new Promise((r) => ws.once('drain', r));
        }
      } catch (e) {
        failed = String((e && e.message) || e);
      }
      await new Promise((r) => ws.end(r));
      if (failed || size <= 0) {
        try { rmSync(target, { force: true }); } catch { /* 忽略 */ }
        return writeJson(res, failed ? 413 : 400, { error: failed || '空文件' });
      }
      writeJson(res, 200, { ok: true, path: target, size });
    } catch (e) {
      writeJson(res, 500, { error: String((e && e.message) || e) });
    }
  });

  // dock 本地图片直出(渲染用户代发/本地上传图): 读本机文件回 bytes。
  // 仅本机同源可访问(route fence); <img> 不能跨域读取内容, 只作图片预览用。
  route(ctx, 'GET', '/api/qqbot-settings/chat/raw-media', async (req, res) => {
    try {
      const u = new URL(req.url ?? '/', 'http://x');
      const p = String(u.searchParams.get('p') || '').trim();
      if (!p) return writeJson(res, 400, { error: 'p 必填' });
      const st = statSync(p);
      if (!st.isFile()) return writeJson(res, 404, { error: 'file not found' });
      if (st.size > 200 * 1024 * 1024) return writeJson(res, 413, { error: 'too large(>200MB)' });
      const ext = extname(p).slice(1).toLowerCase();
      const AUDIO = { ogg: 'audio/ogg', opus: 'audio/ogg', mp3: 'audio/mpeg', wav: 'audio/wav', m4a: 'audio/mp4', aac: 'audio/aac', amr: 'audio/amr', silk: 'audio/silk', webm: 'audio/webm' };
      const VIDEO = { mp4: 'video/mp4', webm: 'video/webm', mov: 'video/quicktime', m4v: 'video/mp4' };
      const type = MIME[ext] || AUDIO[ext] || VIDEO[ext] || 'application/octet-stream';
      // 支持 Range(视频/音频拖动播放需要): bytes=a-b
      let start = 0;
      let end = st.size - 1;
      let status = 200;
      const range = req.headers && req.headers.range;
      if (range) {
        const m = /bytes=(\d*)-(\d*)/.exec(String(range));
        if (m) {
          const s1 = m[1] === '' ? undefined : parseInt(m[1], 10);
          const e1 = m[2] === '' ? undefined : parseInt(m[2], 10);
          if (s1 !== undefined && s1 < st.size) start = s1;
          if (e1 !== undefined && e1 < st.size) end = e1;
          if (end < start) end = Math.min(start + 1024 * 1024, st.size - 1);
          status = 206;
        }
      }
      const len = end - start + 1;
      const fd = openSync(p, 'r');
      const buf = Buffer.alloc(len);
      try { readSync(fd, buf, 0, len, start); } finally { closeSync(fd); }
      const headers = {
        'content-type': type,
        'content-length': len,
        'cache-control': 'no-store',
        'accept-ranges': 'bytes',
      };
      if (status === 206) headers['content-range'] = 'bytes ' + start + '-' + end + '/' + st.size;
      res.writeHead(status, headers);
      res.end(buf);
    } catch (e) {
      writeJson(res, 404, { error: String((e && e.message) || e) });
    }
  });

  // dock QQ 语音播放: 下载 SILK → 纯 JS(silk-wasm + lamejs-fixed)转 mp3 → 返回(带磁盘缓存)。
  // 零系统依赖(不依赖 ffmpeg/外部工具), 通用插件可直接打包; 浏览器播放 mp3 兼容性最好。
  route(ctx, 'GET', '/api/qqbot-settings/chat/voice-play', async (req, res) => {
    try {
      const u = new URL(req.url ?? '/', 'http://x');
      const src = String(u.searchParams.get('u') || '').trim();
      if (!/^https?:\/\//i.test(src) || !QQ_MEDIA_RE.test(src)) return writeJson(res, 400, { error: 'u 必须为 QQ 媒体 URL' });
      const bot = nsBot(undefined);
      const cacheDir = join((bot && bot.cwd) || homedir(), '.qqbot', 'voice-cache');
      mkdirSync(cacheDir, { recursive: true });
      const key = createHash('sha256').update(src).digest('hex');
      const cf = join(cacheDir, key + '.mp3');
      if (!existsSync(cf)) {
        const resp = await fetch(src, { headers: { 'user-agent': 'Mozilla/5.0' } });
        if (!resp.ok) return writeJson(res, 502, { error: '语音下载失败(HTTP ' + resp.status + ')' });
        const buf = Buffer.from(await resp.arrayBuffer());
        const mod = await import('./voice-convert.mjs');
        if (!mod.isSilk(buf)) return writeJson(res, 415, { error: '该语音非 SILK 格式(QQ 语音均为 SILK)' });
        const { mp3 } = await mod.silkToMp3(buf);
        try { writeFileSync(cf, mp3); } catch { /* 缓存失败不影响播放 */ }
      }
      const mp3 = readFileSync(cf);
      res.writeHead(200, { 'content-type': 'audio/mpeg', 'content-length': mp3.length, 'cache-control': 'public, max-age=86400' });
      res.end(mp3);
    } catch (e) {
      writeJson(res, 500, { error: String((e && e.message) || e) });
    }
  });

const WHY_MAP = { busy: '目标会话回合活跃,已等待至回合结束仍超时(跳过注入)', 'no-session': '未找到该群/私聊的活跃会话', 'no-msg': '构造消息失败', failed: '写入失败' };

  // 安全闸(兜底用): 目标会话 LLM 回合活跃(turn/start 已开、turn/end 未闭合——覆盖思考中/流式输出/工具执行)
  // 时禁止外部往该会话插入任何消息(含模拟用户消息), 防止把正在生成的回合流搞乱(曾因此写坏会话)。
  // 与 QQ 插件入站逻辑(debounce.ts 的 turnActive 排队)一致: 活跃时【等待回合结束】再插入, 而非跳过。
  // ⚠️ 只作 waitTurnIdle 的兜底轮询: 它回看最近 3000 条事件找 turn/start..turn/end(曾用 400 太小,
  // 长回合流式/tool 事件一多就漏判"空闲"导致插进 tool_calls↔tool_result 中间, INVALID_REQUEST)。
  // 查不到则放行(append 自身有 reenter 兜底)。
  function sessionTurnActive(sess) {
    try {
      const seq = typeof sess?.seq === 'number' ? sess.seq : -1;
      if (seq <= 0 || typeof sess.snapshotEvents !== 'function') return false;
      const tail = sess.snapshotEvents(Math.max(0, seq - 3000), seq);
      let lastStart = -1;
      let lastEnd = -1;
      for (const ev of tail) {
        if (ev.type === 'turn/start') lastStart = ev.seq;
        else if (ev.type === 'turn/end') lastEnd = ev.seq;
      }
      return lastStart > lastEnd;
    } catch { return false; }
  }

  /**
   * 等目标会话 LLM 回合结束再返回。
   * 主路径: 宿主 agent.whenIdle()(权威: 空闲立即返回、回合活跃时等 turn/end —— 与入群通知
   * safeAppendUserMessage 同款)。⚠️ 不能先用 sessionTurnActive 当第一判断: 它只回看 400 条事件,
   * 长回合(流式/tool 事件多)时窗口内查不到 turn/start 会误判"空闲", 正是历史事故的漏网点。
   * 超时(60s, 防 turn/end 丢失卡死)或宿主无 whenIdle → 回落 800ms 轮询, 仍超时返回 false。
   */
  const TURN_WAIT_MS = 60_000;
  async function waitTurnIdle(agent, sess) {
    // ① 权威: whenIdle —— 回合空闲立即 resolve; 活跃时等 turn/end 后再 resolve
    if (agent && typeof agent.whenIdle === 'function') {
      let idle = false;
      try {
        await Promise.race([
          agent.whenIdle().then(() => { idle = true; }),
          new Promise((r) => setTimeout(r, TURN_WAIT_MS)),
        ]);
      } catch { /* whenIdle 异常按未空闲处理 */ }
      if (idle) return true;
    }
    // ② 兜底轮询: 与 QQ 入站 debounce 排队同款(800ms 重查, 等 turn/end), 超 60s 放弃
    if (sess && typeof sess.snapshotEvents === 'function') {
      const t0 = Date.now();
      for (;;) {
        if (!sessionTurnActive(sess)) return true;
        if (Date.now() - t0 >= TURN_WAIT_MS) return false;
        await new Promise((r) => setTimeout(r, 800));
      }
    }
    return true; // 无检测能力 → 放行(append 自身有 reenter 兜底)
  }

  // ── 线B(用户代发/后台通知 → 插入上下文)异步队列(2026-09-09) ──
  // 与 QQ 入站 debounce 排队同款语义: **先收下消息立即返回, 不阻塞任何 HTTP 请求/事件**,
  // 回合活跃时攒在 per-peer 队列里, 回合结束后(whenIdle/turnActive=false)再逐条 append。
  // 避免把 dock 发送请求挂在 waitTurnIdle 上 60s+(曾导致"第二条消息发不出去")。
  //
  // 性能护栏:
  //  - 队列按 peer 分 key, 单 peer 上限 RELAY_QUEUE_MAX(超限丢最老), 防止内存无限膨胀;
  //  - 队列空即删 key(不残留); drain 有 in-flight 去重, 同 key 不并发重复消费;
  //  - 等待靠 whenIdle 事件驱动(回合结束才 resolve, 不空转); 兜底 800ms 轮询只在无 whenIdle 时用;
  //  - waitTurnIdle 自身 60s 超时防 turn/end 丢失卡死, 超时该条放弃(不硬塞坏记录)。
  const RELAY_QUEUE_MAX = 200;
  const relayQueues = new Map(); // key = ns|scope|peerId → [{ ns, scope, peerId, kind:'relay'|'notice', text }]
  const relayDraining = new Set(); // 正在 drain 的 key(防同 key 并发重复消费)

  function relayQueueKey(ns, scope, peerId) { return ns + '|' + scope + '|' + peerId; }

  /** 入队一条待写上下文的消息(立即返回; 后台 drain 回合结束后落盘) */
  function enqueueRelayWrite(ns, scope, peerId, kind, text) {
    const key = relayQueueKey(ns, scope, peerId);
    let q = relayQueues.get(key);
    if (!q) { q = []; relayQueues.set(key, q); }
    if (q.length >= RELAY_QUEUE_MAX) q.shift(); // 防内存膨胀: 超限丢最老
    q.push({ ns, scope, peerId, kind, text });
    void drainRelayQueue(key);
  }

  /** 后台串行消费某 peer 的待写队列。
   *  - 单条 busy(回合卡死/超时): 保留队列并 break, 等下次入队再触发 drain 重试 —— 防整个队列
   *    逐条各等 60s 超时空挂; 回合只是暂时活跃(正常结束)时下条入队即重试成功。
   *  - 单条 fail(no-session / no-msg / append 异常): 丢弃该条, 继续下一条。 */
  async function drainRelayQueue(key) {
    if (relayDraining.has(key)) return;
    relayDraining.add(key);
    try {
      for (;;) {
        const q = relayQueues.get(key);
        const item = q && q[0];
        if (!item) { relayQueues.delete(key); break; } // 队列空 → 删 key, 不残留
        let st = 'fail';
        try {
          st = await appendOneRelayItem(item);
        } catch { st = 'fail'; }
        if (st === 'busy') break; // 回合长时间卡死: 保留剩余队列, 下条入队再重试(不空挂)
        q.shift();
        if (st === 'fail') {
          // 写失败(no-session / no-msg / append 异常): 不阻塞队列, 丢弃并继续
          try {
            const { bots } = parsePatch();
            const bot = bots.find((b) => b.id === item.ns);
            if (bot && bot.cwd) audit(bot.cwd, { ev: 'relay.drain-skip', ns: item.ns, scope: item.scope, peerId: item.peerId, kind: item.kind, reason: 'drain-failed' });
          } catch { /* audit 失败不阻断 */ }
        }
      }
    } finally {
      relayDraining.delete(key);
    }
  }

  /** 等回合结束 + 把单条消息 append 进会话(不唤醒、不开回合)。返回 'ok' | 'busy' | 'fail' */
  async function appendOneRelayItem({ ns, scope, peerId, kind, text }) {
    const reg = await import('./dist/features/session-registry.js');
    let rec = typeof reg.findRecordByPeerWeb === 'function' ? reg.findRecordByPeerWeb(ns, scope, peerId) : undefined;
    // 活跃表 miss(会话被 idle 回收/未建立)→ 与入群申请通知/定时任务同款: getOrCreate 恢复/重建会话(不开回合),
    // 保证 log 存在能 append(否则 findRecordByPeerWeb 永远 no-session, QQ 发出但 web 流无痕)。
    if (!rec && typeof reg.getOrCreateByPeerWeb === 'function') {
      try { rec = await reg.getOrCreateByPeerWeb(ns, scope, peerId, 'master'); } catch { /* 恢复失败按 no-session 走 */ }
    }
    if (!rec || !rec.agent) return 'fail';
    const agent = rec.agent;
    const sess = agent && (agent.session || (agent.ctx && agent.ctx.session));
    const appendFn = sess && typeof sess.append === 'function' ? sess.append.bind(sess) : undefined;
    if (!appendFn) return 'fail';
    // 🔒 等 LLM 回合结束(与 QQ 入站排队同款; 超时=busy 由 drain 保留重试)
    if (!(await waitTurnIdle(agent, sess))) return 'busy';
    if (kind === 'relay') {
      // 用户代发: 文本以「用户代你发送: 」开头(只进 web 流, QQ 收到干净原文); 主人下次真人消息
      // 开回合时该 user/message 作为历史被 deriveMessages 组装进上下文 → bot 自然看到"主人代我发了这句"。
      const llm = await import('@deepseek-ai/dsh-llm');
      const relayText = `用户代你发送: ${text}`;
      const msg = llm.createUserMessage
        ? llm.createUserMessage({ content: [{ type: 'text', text: relayText }], source: { kind: 'user' } })
        : undefined;
      if (!msg) return 'fail';
      // 与 agent-loop turn()/入群申请通知同款: user/message 的 data 就是消息体本身(不包 message 层)。
      appendFn('user/message', msg, { surfaceOp: 'append' });
    } else {
      // 后台任务结果通知(与通道工具 bgSend notifySession 同款形状: source kind user, 文本 [系统] 后台任务…)
      appendFn('user/message', {
        id: 'bg-' + Date.now().toString(36) + '-' + Math.floor(Math.random() * 1e9).toString(36),
        role: 'user',
        content: [{ type: 'text', text: String(text || '') }],
        source: { kind: 'user' },
      }, { surfaceOp: 'append' });
    }
    return 'ok';
  }

  // 线B 入口: 用户代发→插入上下文(入队即返回, 不阻塞请求)
  async function appendUserRelayToPeer(ns, scope, peerId, text) {
    enqueueRelayWrite(ns, scope, peerId, 'relay', text);
    return null; // 已入队; 实际写入由后台 drain 在回合结束后完成
  }

  // 后台任务结果通知写回会话(入队即返回, 不阻塞请求)
  async function appendNoticeToPeer(ns, scope, peerId, text) {
    enqueueRelayWrite(ns, scope, peerId, 'notice', text);
    return true;
  }

  // 入群申请红点汇总(悬浮球 dock 用): 遍历所有已配置实例, 返回各实例待审申请数(计数不上报明细)
  route(ctx, 'GET', '/api/qqbot-settings/group/join-summary', async (_req, res) => {
    try {
      const { bots } = parsePatch();
      const out = [];
      for (const bot of bots) {
        if (bot.disabled || !bot.cfg?.appId || !bot.cfg?.appSecret) continue;
        try {
          const ns = bot.id;
          const gc = await groupClientOf(ns);
          if (!gc) continue;
          const reg = readGroupsJson(bot.cwd);
          let pending = 0;
          for (const gid of Object.keys(reg)) {
            if (!gid) continue;
            try {
              const r = await gc.client.listJoinRequests(gid);
              if (r.ok && Array.isArray(r.data?.list)) pending += r.data.list.length;
            } catch { /* 单群失败不阻断 */ }
          }
          out.push({ ns, pending });
        } catch { /* 实例失败跳过 */ }
      }
      writeJson(res, 200, { ok: true, items: out });
    } catch (e) { writeJson(res, 500, { error: String((e && e.message) || e) }); }
  });

  // 绑定/登记群 {ns?, gid, name?}
  route(ctx, 'POST', '/api/qqbot-settings/group/bind', async (req, res) => {
    const body = await readJsonBody(req);
    if (!body || typeof body !== 'object') return writeJson(res, 400, { error: 'bad body' });
    const gid = String(body.gid || '').trim();
    if (!gid) return writeJson(res, 400, { error: 'gid 必填' });
    try {
      const bot = nsBot(String(body.ns || ''));
      if (!bot) return writeJson(res, 400, { error: '找不到该账号实例(请先在账号页配置 appId/appSecret)' });
      const reg = readGroupsJson(bot.cwd);
      reg[gid] = { name: String(body.name || '').trim(), lastAt: Date.now() };
      writeGroupsJson(bot.cwd, reg);
      audit(bot.cwd, { ev: 'group.bind', ns: bot.id, gid });
      writeJson(res, 200, { ok: true });
    } catch (e) { writeJson(res, 500, { error: String((e && e.message) || e) }); }
  });

  // ── 审批双通道: Web 浮层同源路由(读待办 / 点按钮结算) ──
  // 数据来自各实例 QqApprovalController(经 registerApprovalController 注册表),
  // 与 QQ 按钮卡片/文本码共用同一 pending —— 先到先得, 两端天然同步。
  route(ctx, 'GET', '/api/qqbot-settings/approval/pending', async (_req, res) => {
    try {
      const mod = await import('./dist/features/qq-approval.js');
      const list = typeof mod.listAllPendingWeb === 'function' ? mod.listAllPendingWeb() : [];
      writeJson(res, 200, { ok: true, pending: list });
    } catch (e) { writeJson(res, 500, { error: String((e && e.message) || e) }); }
  });
  // {code, act:'allow'|'deny'}
  route(ctx, 'POST', '/api/qqbot-settings/approval/decide', async (req, res) => {
    const body = await readJsonBody(req);
    if (!body || typeof body !== 'object') return writeJson(res, 400, { error: 'bad body' });
    const code = String(body.code || '').toUpperCase();
    const act = String(body.act || '');
    if (!code || (act !== 'allow' && act !== 'deny')) return writeJson(res, 400, { error: 'code 与 act(allow|deny) 必填' });
    try {
      const mod = await import('./dist/features/qq-approval.js');
      const r = typeof mod.decideByWebAny === 'function' ? mod.decideByWebAny(code, act) : { ok: false, msg: '审批模块不可用' };
      writeJson(res, r.ok ? 200 : 404, r);
    } catch (e) { writeJson(res, 500, { error: String((e && e.message) || e) }); }
  });

  // ── 提问双通道: Web 浮层同源路由(读待办问题 / 点选项结算) ──
  route(ctx, 'GET', '/api/qqbot-settings/questions/pending', async (_req, res) => {
    try {
      const mod = await import('./dist/features/qq-user-questions.js');
      const list = typeof mod.listAllPendingQuestionsWeb === 'function' ? mod.listAllPendingQuestionsWeb() : [];
      writeJson(res, 200, { ok: true, pending: list });
    } catch (e) { writeJson(res, 500, { error: String((e && e.message) || e) }); }
  });
  // {key, optIdx}
  route(ctx, 'POST', '/api/qqbot-settings/questions/decide', async (req, res) => {
    const body = await readJsonBody(req);
    if (!body || typeof body !== 'object') return writeJson(res, 400, { error: 'bad body' });
    const key = String(body.key || '');
    const optIdx = Number(body.optIdx);
    if (!key || !Number.isInteger(optIdx) || optIdx < 0) return writeJson(res, 400, { error: 'key 与 optIdx 必填' });
    try {
      const mod = await import('./dist/features/qq-user-questions.js');
      const r = typeof mod.decideQuestionByWebAny === 'function' ? mod.decideQuestionByWebAny(key, optIdx) : { ok: false, msg: '提问模块不可用' };
      writeJson(res, r.ok ? 200 : 404, r);
    } catch (e) { writeJson(res, 500, { error: String((e && e.message) || e) }); }
  });

  // ── 🚀 群发任务「后台自动推进」(2026-09-10 修: 原设计靠 client 每次 list 驱动, 页面不动就永久卡 queued) ──
  // 每隔 BC_TICK_MS 扫全部实例, 有 queued/sending 任务就推进一步(串行 → 天然限频); 单实例失败不影响其他实例。
  // 节流依据(**官方文档已核对**, 群发走的是"主动消息"):
  //   · 群聊: Bot 维度(发送方) 企业认证 60/qpm、未认证 30/qpm；单关系(同一个群) 20/qpm；每群每天最多接收 1000 条；接口 100 QPS
  //   · 单聊: Bot 维度 认证 10/qps、未认证 5/qps 且 30/qpm；单关系 20/qpm
  //   1500ms/条 ≈ 40 条/分钟 —— 跑满认证额度的 2/3, 给"被动回复/定时推送/其它主动消息"留余量。
  //   (原为 5000ms ≈ 12 条/分钟, 仅用掉 1/5 额度, 主人实测嫌慢)
  try {
    const BC_TICK_MS = 1500;
    let bcTickRunning = false; // 定时器自身防重入: 上一轮未跑完不叠加(2026-09-10)
    const bcTick = async () => {
      if (bcTickRunning) return;
      bcTickRunning = true;
      try {
      let bots = [];
      try { bots = parsePatch().bots || []; } catch { return; }
      for (const b of bots) {
        try {
          if (b.disabled) continue;
          const bot = nsBot(b.id);
          if (!bot || !bot.cwd) continue;
          const bm = await broadcastMod();
          const tasks = bm.listTasks(bot.cwd);
          const active = tasks.find((t) => t.state === 'queued' || t.state === 'sending');
          if (!active) continue;
          const gc = await groupClientOf(b.id);
          if (!gc) continue;
          await bm.advanceTask(bot.cwd, active.task_id, gc.client);
          audit(bot.cwd, { ev: 'group.broadcast.auto-advance', ns: b.id, task_id: active.task_id });
        } catch (e) {
          try {
            const bot2 = nsBot(b.id);
            if (bot2 && bot2.cwd) audit(bot2.cwd, { ev: 'group.broadcast.auto-advance-failed', ns: b.id, error: String((e && e.message) || e) });
          } catch { /* ignore */ }
        }
      }
      } finally { bcTickRunning = false; }
    };
    ctx.effect(() => {
      const timer = setInterval(() => { bcTick().catch(() => {}); }, BC_TICK_MS);
      timer.unref?.();
      return () => { try { clearInterval(timer); } catch { /* ignore */ } };
    }, 'qqbot-settings: 群发任务后台自动推进');
  } catch { /* 定时器失败不影响插件 */ }

}
